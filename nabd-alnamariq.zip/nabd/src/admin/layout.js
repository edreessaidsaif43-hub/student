'use strict';
// قالب لوحة التحكم
const db = require('../db');
const { html, raw, esc } = require('../core/util');
const { icon } = require('../core/icons');
const { TYPES } = require('../content-types');

const MENU = [
  { group: 'عام', items: [
    { href: '/admin', label: 'لوحة المعلومات', icon: 'home', perm: 'dashboard.view' },
    { href: '/', label: 'عرض الموقع', icon: 'external', target: '_blank' },
  ] },
  { group: 'المحتوى', items: Object.entries(TYPES).map(([k, t]) => ({ href: '/admin/content?type=' + k, label: t.label, icon: t.icon, perm: ['content.create', 'content.edit_own', 'content.edit_all'], match: 'type=' + k })) },
  { group: 'الوسائط والبيانات', items: [
    { href: '/admin/media', label: 'مكتبة الوسائط', icon: 'folder', perm: ['media.upload', 'media.manage'] },
    { href: '/admin/r/gallery', label: 'المعرض الإعلامي', icon: 'image', perm: 'gallery.manage' },
    { href: '/admin/r/schedules', label: 'الجداول المدرسية', icon: 'table', perm: 'schedules.manage' },
    { href: '/admin/r/calendar', label: 'التقويم المدرسي', icon: 'calendar', perm: 'calendar.manage' },
    { href: '/admin/r/staff', label: 'الإدارة المدرسية', icon: 'users', perm: 'staff.manage' },
    { href: '/admin/r/stats', label: 'الإحصائيات', icon: 'chart', perm: 'stats.manage' },
  ] },
  { group: 'التواصل', items: [
    { href: '/admin/r/alerts', label: 'الإشعارات العاجلة', icon: 'bell', perm: 'alerts.manage' },
    { href: '/admin/r/surveys', label: 'الاستبانات', icon: 'poll', perm: 'surveys.manage' },
    { href: '/admin/r/messages', label: 'رسائل التواصل', icon: 'inbox', perm: 'inbox.manage', badge: 'messages' },
    { href: '/admin/r/suggestions', label: 'مقترحات أولياء الأمور', icon: 'lightbulb', perm: 'inbox.manage', badge: 'suggestions' },
  ] },
  { group: 'الإدارة', items: [
    { href: '/admin/r/years', label: 'الأعوام الدراسية', icon: 'archive', perm: 'years.manage' },
    { href: '/admin/r/users', label: 'المستخدمون', icon: 'users', perm: 'users.manage' },
    { href: '/admin/r/roles', label: 'الأدوار والصلاحيات', icon: 'shield', perm: 'roles.manage' },
    { href: '/admin/settings', label: 'إعدادات الموقع', icon: 'settings', perm: 'settings.manage' },
    { href: '/admin/logs', label: 'سجل العمليات', icon: 'log', perm: 'logs.view' },
  ] },
];

const can = (user, perm) => !perm || [].concat(perm).some((p) => user.can(p));

function readFlash(req, res) {
  const f = req.cookies.nabd_flash;
  if (!f) return null;
  res.setCookie('nabd_flash', '', { maxAge: 0 });
  try { return JSON.parse(f); } catch { return null; }
}

async function adminShell(req, { title, body, actions = '' }) {
  const u = req.user;
  const res = req.res;
  const flash = res ? readFlash(req, res) : null;
  const s = await db.settings();
  let counts = {};
  if (u && u.can('inbox.manage')) {
    counts.messages = (await db.get("SELECT COUNT(*) n FROM messages WHERE status = 'new'")).n;
    counts.suggestions = (await db.get("SELECT COUNT(*) n FROM suggestions WHERE status = 'new'")).n;
  }
  const full = req.path + (req.search || '');
  const isAct = (it) => (!it.href.startsWith('/admin') ? false : it.match ? full.includes(it.match) && req.path.startsWith('/admin/content') : it.href === '/admin' ? req.path === '/admin' : req.path.startsWith(it.href));
  return '<!DOCTYPE html>' + html`<html lang="ar" dir="rtl"><head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><meta name="robots" content="noindex,nofollow">
<title>${title} | لوحة التحكم — ${s.site_name}</title>
<link rel="icon" href="${s.logo || '/img/logo.svg'}">
<link rel="preconnect" href="https://fonts.googleapis.com"><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;600;700;800&family=Tajawal:wght@400;500;700&display=swap">
<link rel="stylesheet" href="/css/admin.css?v=2">
<script src="/js/admin.js?v=2" defer></script>
</head><body class="admin">
${u ? html`<aside class="sidebar" id="sidebar">
  <a class="sb-brand" href="/admin"><img src="${s.logo || '/img/logo.svg'}" alt="" width="40" height="40"><span><b>${s.site_name}</b><small>لوحة التحكم</small></span></a>
  <nav aria-label="قائمة لوحة التحكم">${MENU.map((g) => {
    const items = g.items.filter((it) => can(u, it.perm));
    return items.length ? html`<div class="sb-group"><h3>${g.group}</h3>${items.map((it) => html`<a href="${it.href}" class="${isAct(it) ? 'on' : ''}" ${it.target ? raw('target="_blank" rel="noopener"') : ''}>${raw(icon(it.icon, 'sm'))}<span>${it.label}</span>${it.badge && counts[it.badge] ? html`<em>${counts[it.badge]}</em>` : ''}</a>`)}</div>` : '';
  })}</nav>
</aside>` : ''}
<div class="main">
  ${u ? html`<header class="topbar">
    <button type="button" class="icon-btn" id="sb-toggle" aria-label="القائمة">${raw(icon('menu'))}</button>
    <h1>${title}</h1>
    <div class="tb-actions">${raw(String(actions))}</div>
    <div class="user-menu"><span class="avatar">${(u.name || '?').trim().charAt(0)}</span><span class="un"><b>${u.name}</b><small>${u.roleLabel}</small></span>
      <a class="icon-btn" href="/admin/password" title="تغيير كلمة المرور" aria-label="تغيير كلمة المرور">${raw(icon('shield', 'sm'))}</a>
      <form method="post" action="/admin/logout"><input type="hidden" name="_csrf" value="${req.session.csrf}"><button class="icon-btn" title="تسجيل الخروج" aria-label="تسجيل الخروج">${raw(icon('logout', 'sm'))}</button></form>
    </div>
  </header>` : ''}
  <div class="content">
    ${flash ? html`<div class="flash ${flash.type || 'ok'}" role="status">${raw(icon(flash.type === 'err' ? 'alert' : 'check', 'sm'))} ${flash.msg}</div>` : ''}
    ${raw(String(body))}
  </div>
</div>
${u ? html`<div class="modal" id="picker" hidden role="dialog" aria-modal="true" aria-label="مكتبة الوسائط"><div class="modal-box">
  <div class="modal-head"><b>اختر من مكتبة الوسائط</b><input type="search" class="picker-q" placeholder="بحث…"><label class="btn btn-teal sm">${raw(icon('plus', 'sm'))} رفع ملف<input type="file" class="picker-up" hidden></label><button type="button" class="icon-btn" data-close-modal aria-label="إغلاق">${raw(icon('x'))}</button></div>
  <div class="picker-grid"></div></div></div>
<meta name="csrf" content="${req.session.csrf}">` : ''}
</body></html>`;
}

function flash(res, msg, type = 'ok') {
  res.setCookie('nabd_flash', JSON.stringify({ msg, type }), { maxAge: 60 });
}

module.exports = { adminShell, flash, MENU, can };
