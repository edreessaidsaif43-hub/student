'use strict';
// تعريف الموارد العامة في لوحة التحكم (قائمة + نموذج + صلاحية)
const { html, raw, fmtDate, fmtUtcDT, safeJson, isEmail, youtubeEmbed } = require('../core/util');
const { CALENDAR_KINDS, SCHEDULE_KINDS, GRADES } = require('../content-types');

const statusPub = [['published', 'منشور'], ['draft', 'مسودة']];
const badge = (t, c = '') => html`<span class="pill ${c}">${t}</span>`;
const demo = (r) => (r.is_demo ? badge('تجريبي', 'demo') : '');

const RESOURCES = {
  gallery: {
    table: 'gallery', label: 'المعرض الإعلامي', single: 'عنصر وسائط', perm: 'gallery.manage', icon: 'image', order: 'sort, id DESC', search: ['title', 'album'],
    filters: [{ name: 'kind', label: 'النوع', options: [['image', 'صورة'], ['video', 'فيديو']] }],
    columns: [
      { label: '', render: (r) => (r.kind === 'image' && r.file ? html`<img class="thumb" src="${r.file}" alt="">` : html`<span class="thumb ph">▶</span>`) },
      { label: 'العنوان', render: (r) => html`<b>${r.title}</b> ${demo(r)}` }, { label: 'الألبوم', key: 'album' },
      { label: 'النوع', render: (r) => (r.kind === 'video' ? 'فيديو' : 'صورة') }, { label: 'الحالة', render: (r) => badge(r.status === 'published' ? 'منشور' : 'مسودة', r.status === 'published' ? 'green' : 'gray') },
    ],
    fields: [
      { name: 'title', label: 'العنوان', required: true },
      { name: 'kind', label: 'النوع', type: 'select', options: [['image', 'صورة'], ['video', 'فيديو']], empty: false, required: true },
      { name: 'album', label: 'الألبوم', help: 'مثل: الأنشطة، المناسبات الوطنية، المرافق' },
      { name: 'academic_year_id', label: 'العام الدراسي', type: 'year' },
      { name: 'file', label: 'الملف (صورة أو فيديو MP4)', type: 'file', kinds: ['image', 'video'], wide: true },
      { name: 'video_url', label: 'رابط فيديو يوتيوب (بديل عن رفع الملف)', dir: 'ltr', wide: true, validate: (v) => (v && !youtubeEmbed(v) ? 'رابط يوتيوب غير صالح' : null) },
      { name: 'description', label: 'الوصف', type: 'textarea', rows: 3, wide: true },
      { name: 'sort', label: 'الترتيب', type: 'number', default: 0 },
      { name: 'status', label: 'الحالة', type: 'select', options: statusPub, empty: false },
    ],
    validate: (d) => (d.kind === 'image' && !d.file ? 'يرجى رفع الصورة أو اختيارها من المكتبة' : d.kind === 'video' && !d.file && !d.video_url ? 'يرجى رفع فيديو أو إضافة رابط يوتيوب' : null),
  },
  schedules: {
    table: 'schedules', label: 'الجداول المدرسية', single: 'جدول', perm: 'schedules.manage', icon: 'table', order: 'sort, id DESC', search: ['title', 'grade'],
    filters: [{ name: 'kind', label: 'النوع', options: Object.entries(SCHEDULE_KINDS) }],
    columns: [{ label: 'العنوان', render: (r) => html`<b>${r.title}</b> ${demo(r)}` }, { label: 'النوع', render: (r) => SCHEDULE_KINDS[r.kind] }, { label: 'الصف', key: 'grade' },
      { label: 'الحالة', render: (r) => badge(r.status === 'published' ? 'منشور' : 'مسودة', r.status === 'published' ? 'green' : 'gray') }],
    fields: [
      { name: 'title', label: 'عنوان الجدول', required: true },
      { name: 'kind', label: 'النوع', type: 'select', options: Object.entries(SCHEDULE_KINDS), empty: false },
      { name: 'grade', label: 'الصف', type: 'select', options: GRADES },
      { name: 'section', label: 'الشعبة', max: 20 },
      { name: 'academic_year_id', label: 'العام الدراسي', type: 'year' },
      { name: 'grid', label: 'محتوى الجدول', type: 'grid', help: 'الأعمدة: الحصص (أو الصفوف في جداول الاختبارات)، والصفوف: الأيام. يمكن تعديل العناوين مباشرة.' },
      { name: 'attachment', label: 'ملف مرفق (PDF/صورة) — اختياري', type: 'file', kinds: ['document', 'image'] },
      { name: 'notes', label: 'ملاحظات', type: 'textarea', rows: 2 },
      { name: 'sort', label: 'الترتيب', type: 'number', default: 0 },
      { name: 'status', label: 'الحالة', type: 'select', options: statusPub, empty: false },
    ],
  },
  calendar: {
    table: 'calendar_items', label: 'التقويم المدرسي', single: 'موعد', perm: 'calendar.manage', icon: 'calendar', order: 'starts_on DESC', search: ['title'],
    filters: [{ name: 'kind', label: 'النوع', options: Object.entries(CALENDAR_KINDS).map(([k, v]) => [k, v.label]) }],
    columns: [{ label: 'العنوان', render: (r) => html`<b>${r.title}</b> ${demo(r)}` }, { label: 'النوع', render: (r) => badge(CALENDAR_KINDS[r.kind]?.label || r.kind, 'k-' + (CALENDAR_KINDS[r.kind]?.color || '')) },
      { label: 'التاريخ', render: (r) => fmtDate(r.starts_on, { dateStyle: 'medium' }) + (r.ends_on ? ' – ' + fmtDate(r.ends_on, { dateStyle: 'medium' }) : '') }],
    fields: [
      { name: 'title', label: 'العنوان', required: true },
      { name: 'kind', label: 'النوع', type: 'select', options: Object.entries(CALENDAR_KINDS).map(([k, v]) => [k, v.label]), empty: false },
      { name: 'starts_on', label: 'تاريخ البداية', type: 'date', required: true },
      { name: 'ends_on', label: 'تاريخ النهاية (اختياري)', type: 'date' },
      { name: 'academic_year_id', label: 'العام الدراسي', type: 'year' },
      { name: 'description', label: 'الوصف', type: 'textarea', rows: 3, wide: true },
      { name: 'status', label: 'الحالة', type: 'select', options: statusPub, empty: false },
    ],
    validate: (d) => (d.ends_on && d.ends_on < d.starts_on ? 'تاريخ النهاية يجب أن يكون بعد البداية' : null),
  },
  staff: {
    table: 'staff', label: 'الإدارة المدرسية', single: 'عضو', perm: 'staff.manage', icon: 'users', order: 'sort, id', search: ['name', 'position'],
    columns: [{ label: '', render: (r) => (r.photo ? html`<img class="thumb round" src="${r.photo}" alt="">` : '') }, { label: 'الاسم', render: (r) => html`<b>${r.name}</b> ${demo(r)}` }, { label: 'المنصب', key: 'position' }, { label: 'القسم', key: 'department' }],
    fields: [
      { name: 'name', label: 'الاسم', required: true }, { name: 'position', label: 'المنصب', required: true }, { name: 'department', label: 'القسم' },
      { name: 'photo', label: 'الصورة', type: 'image' }, { name: 'bio', label: 'نبذة مختصرة', type: 'textarea', rows: 3, wide: true },
      { name: 'sort', label: 'الترتيب', type: 'number', default: 0 }, { name: 'status', label: 'الحالة', type: 'select', options: statusPub, empty: false },
    ],
  },
  stats: {
    table: 'stats', label: 'الإحصائيات', single: 'إحصائية', perm: 'stats.manage', icon: 'chart', order: 'sort, id',
    columns: [{ label: 'الوصف', render: (r) => html`<b>${r.label}</b> ${demo(r)}` }, { label: 'القيمة', render: (r) => (r.suffix || '') + r.value }],
    fields: [
      { name: 'label', label: 'الوصف', required: true }, { name: 'value', label: 'القيمة', type: 'number', required: true, min: 0 }, { name: 'suffix', label: 'لاحقة (مثل +)', max: 5 },
      { name: 'icon', label: 'الأيقونة', type: 'select', options: [['users', 'طلبة'], ['teacher', 'معلمون'], ['spark', 'أنشطة'], ['trophy', 'جوائز'], ['book', 'كتب'], ['star', 'نجمة'], ['heart', 'قلب'], ['flag', 'علم']], empty: false },
      { name: 'sort', label: 'الترتيب', type: 'number', default: 0 },
    ],
  },
  alerts: {
    table: 'alerts', label: 'الإشعارات العاجلة', single: 'إشعار', perm: 'alerts.manage', icon: 'bell', order: 'id DESC',
    intro: 'تظهر الإشعارات النشطة شريطًا بارزًا أعلى كل صفحات الموقع ضمن الفترة المحددة، ويمكن للزائر إخفاؤها.',
    columns: [{ label: 'النص', render: (r) => html`${r.message} ${demo(r)}` }, { label: 'المستوى', render: (r) => badge({ info: 'معلومة', warning: 'تنبيه', success: 'تهنئة' }[r.level], { info: 'navy', warning: 'amber', success: 'green' }[r.level]) },
      { label: 'الحالة', render: (r) => badge(r.active ? 'نشط' : 'متوقف', r.active ? 'green' : 'gray') }],
    fields: [
      { name: 'message', label: 'نص الإشعار', type: 'textarea', rows: 2, max: 300, required: true, wide: true },
      { name: 'link', label: 'رابط (اختياري)', dir: 'ltr', placeholder: '/news أو https://…', validate: (v) => (v && !/^(\/|https:\/\/)/.test(v) ? 'الرابط يجب أن يبدأ بـ / أو https://' : null) },
      { name: 'level', label: 'المستوى', type: 'select', options: [['info', 'معلومة'], ['warning', 'تنبيه'], ['success', 'تهنئة']], empty: false },
      { name: 'starts_at', label: 'يبدأ في (اختياري)', type: 'datetime_utc' }, { name: 'ends_at', label: 'ينتهي في (اختياري)', type: 'datetime_utc' },
      { name: 'active', label: 'نشط', type: 'checkbox', default: 1 },
    ],
  },
  surveys: {
    table: 'surveys', label: 'الاستبانات', single: 'استبانة', perm: 'surveys.manage', icon: 'poll', order: 'id DESC', search: ['title'],
    columns: [{ label: 'العنوان', render: (r) => html`<b>${r.title}</b> ${demo(r)}` }, { label: 'الحالة', render: (r) => badge({ draft: 'مسودة', open: 'مفتوحة', closed: 'مغلقة' }[r.status], { draft: 'gray', open: 'green', closed: 'navy' }[r.status]) },
      { label: 'الردود', render: (r) => html`<a href="/admin/surveys/${r.id}/results">${r.responses ?? 0} رد — النتائج</a>` }],
    listSql: 'SELECT s.*, (SELECT COUNT(*) FROM survey_responses r WHERE r.survey_id = s.id) responses FROM surveys s',
    fields: [
      { name: 'title', label: 'عنوان الاستبانة', required: true, wide: true },
      { name: 'description', label: 'الوصف', type: 'textarea', rows: 2, wide: true },
      { name: 'status', label: 'الحالة', type: 'select', options: [['draft', 'مسودة'], ['open', 'مفتوحة'], ['closed', 'مغلقة']], empty: false },
      { name: 'academic_year_id', label: 'العام الدراسي', type: 'year' },
      { name: 'starts_on', label: 'تبدأ في', type: 'date' }, { name: 'ends_on', label: 'تنتهي في', type: 'date' },
      { name: 'questions', label: 'الأسئلة', type: 'questions' },
    ],
  },
  messages: {
    table: 'messages', label: 'رسائل التواصل', single: 'رسالة', perm: 'inbox.manage', icon: 'inbox', order: "CASE status WHEN 'new' THEN 0 ELSE 1 END, id DESC", search: ['name', 'subject', 'message', 'email'], noCreate: true,
    filters: [{ name: 'status', label: 'الحالة', options: [['new', 'جديدة'], ['read', 'مقروءة'], ['replied', 'تم الرد'], ['archived', 'مؤرشفة']] }],
    columns: [{ label: 'المرسل', render: (r) => html`<b>${r.name}</b><br><small dir="ltr">${r.email || r.phone || ''}</small>` }, { label: 'الموضوع', key: 'subject' },
      { label: 'التاريخ', render: (r) => fmtUtcDT(r.created_at) }, { label: 'الحالة', render: (r) => badge({ new: 'جديدة', read: 'مقروءة', replied: 'تم الرد', archived: 'مؤرشفة' }[r.status], r.status === 'new' ? 'amber' : 'gray') }],
    fields: [
      { name: 'name', label: 'المرسل', type: 'readonly' }, { name: 'email', label: 'البريد', type: 'readonly', render: (v) => (v ? `<a href="mailto:${v}" dir="ltr">${v}</a>` : '—') },
      { name: 'phone', label: 'الهاتف', type: 'readonly', render: (v) => (v ? `<a href="tel:${v}" dir="ltr">${v}</a>` : '—') }, { name: 'subject', label: 'الموضوع', type: 'readonly' },
      { name: 'created_at', label: 'التاريخ', type: 'readonly', render: (v) => fmtUtcDT(v) },
      { name: 'message', label: 'الرسالة', type: 'readonly', wide: true, render: (v) => String(v || '').replace(/[&<>"']/g, (c) => `&#${c.charCodeAt(0)};`).replace(/\n/g, '<br>') },
      { name: 'status', label: 'الحالة', type: 'select', options: [['new', 'جديدة'], ['read', 'مقروءة'], ['replied', 'تم الرد'], ['archived', 'مؤرشفة']], empty: false },
      { name: 'admin_note', label: 'ملاحظة داخلية', type: 'textarea', rows: 3, wide: true },
    ],
    onOpen: { field: 'status', from: 'new', to: 'read' },
  },
  suggestions: {
    table: 'suggestions', label: 'مقترحات أولياء الأمور', single: 'مقترح', perm: 'inbox.manage', icon: 'lightbulb', order: "CASE status WHEN 'new' THEN 0 ELSE 1 END, id DESC", search: ['name', 'message'], noCreate: true,
    filters: [{ name: 'status', label: 'الحالة', options: [['new', 'جديد'], ['reviewing', 'قيد الدراسة'], ['done', 'تم التنفيذ'], ['archived', 'مؤرشف']] }, { name: 'category', label: 'النوع', options: ['اقتراح', 'ملاحظة', 'شكر وتقدير', 'شكوى'] }],
    columns: [{ label: 'المقترح', render: (r) => html`${String(r.message).slice(0, 90)}…` }, { label: 'النوع', render: (r) => badge(r.category, r.category === 'شكوى' ? 'red' : 'navy') }, { label: 'المرسل', render: (r) => r.name || 'بدون اسم' },
      { label: 'التاريخ', render: (r) => fmtUtcDT(r.created_at) }, { label: 'الحالة', render: (r) => badge({ new: 'جديد', reviewing: 'قيد الدراسة', done: 'تم التنفيذ', archived: 'مؤرشف' }[r.status], r.status === 'new' ? 'amber' : 'gray') }],
    fields: [
      { name: 'name', label: 'المرسل', type: 'readonly', render: (v) => v || 'بدون اسم' }, { name: 'phone', label: 'الهاتف', type: 'readonly', render: (v) => v || '—' },
      { name: 'student_grade', label: 'صف الطالب', type: 'readonly', render: (v) => v || '—' }, { name: 'category', label: 'النوع', type: 'readonly' },
      { name: 'message', label: 'النص', type: 'readonly', wide: true, render: (v) => String(v || '').replace(/[&<>"']/g, (c) => `&#${c.charCodeAt(0)};`).replace(/\n/g, '<br>') },
      { name: 'status', label: 'الحالة', type: 'select', options: [['new', 'جديد'], ['reviewing', 'قيد الدراسة'], ['done', 'تم التنفيذ'], ['archived', 'مؤرشف']], empty: false },
      { name: 'admin_note', label: 'ملاحظة داخلية', type: 'textarea', rows: 3, wide: true },
    ],
  },
  years: {
    table: 'academic_years', label: 'الأعوام الدراسية', single: 'عام دراسي', perm: 'years.manage', icon: 'archive', order: 'name DESC', noTimestamps: true,
    intro: 'يُستخدم العام الدراسي لأرشفة المحتوى وتصفيته. العام المحدد «حاليًا» يُختار تلقائيًا للمحتوى الجديد.',
    columns: [{ label: 'العام', render: (r) => html`<b>${r.name}</b> ${r.is_current ? badge('الحالي', 'green') : ''}` }, { label: 'من', render: (r) => fmtDate(r.starts_on, { dateStyle: 'medium' }) }, { label: 'إلى', render: (r) => fmtDate(r.ends_on, { dateStyle: 'medium' }) }],
    fields: [
      { name: 'name', label: 'اسم العام', required: true, placeholder: '2027/2028', validate: (v) => (!/^\d{4}\/\d{4}$/.test(v || '') ? 'الصيغة المطلوبة: 2027/2028' : null) },
      { name: 'starts_on', label: 'بداية العام', type: 'date' }, { name: 'ends_on', label: 'نهاية العام', type: 'date' },
      { name: 'is_current', label: 'العام الدراسي الحالي', type: 'checkbox' },
    ],
  },
  users: {
    table: 'users', label: 'المستخدمون', single: 'مستخدم', perm: 'users.manage', icon: 'users', order: 'id', search: ['name', 'email'],
    listSql: 'SELECT u.*, r.label role_label FROM users u JOIN roles r ON r.id = u.role_id',
    columns: [{ label: 'الاسم', render: (r) => html`<b>${r.name}</b>` }, { label: 'البريد', render: (r) => html`<span dir="ltr">${r.email}</span>` }, { label: 'الدور', render: (r) => badge(r.role_label, 'navy') },
      { label: 'الحالة', render: (r) => badge(r.active ? 'نشط' : 'معطّل', r.active ? 'green' : 'gray') }, { label: 'آخر دخول', render: (r) => (r.last_login_at ? fmtUtcDT(r.last_login_at) : '—') }],
    fields: [
      { name: 'name', label: 'الاسم', required: true }, { name: 'email', label: 'البريد الإلكتروني', inputType: 'email', dir: 'ltr', required: true, validate: (v) => (!isEmail(v) ? 'البريد الإلكتروني غير صحيح' : null) },
      { name: 'role_id', label: 'الدور', type: 'select', options: [], empty: false, dynamic: 'roles' },
      { name: 'active', label: 'الحساب نشط', type: 'checkbox', default: 1 },
      { name: 'password', label: 'كلمة المرور', type: 'password', help: 'عند التعديل: اتركها فارغة للإبقاء على الحالية. 10 أحرف على الأقل تتضمن حروفًا وأرقامًا.' },
      { name: 'must_change_password', label: 'إلزام المستخدم بتغيير كلمة المرور عند الدخول', type: 'checkbox' },
    ],
  },
  roles: {
    table: 'roles', label: 'الأدوار والصلاحيات', single: 'دور', perm: 'roles.manage', icon: 'shield', order: 'id', noTimestamps: true,
    intro: 'دور «مدير النظام» يملك كل الصلاحيات دائمًا. يمكن تعديل صلاحيات بقية الأدوار أو إنشاء أدوار جديدة.',
    listSql: 'SELECT r.*, (SELECT COUNT(*) FROM users u WHERE u.role_id = r.id) users FROM roles r',
    columns: [{ label: 'الدور', render: (r) => html`<b>${r.label}</b> <small dir="ltr" class="muted">${r.name}</small>` }, { label: 'الصلاحيات', render: (r) => safeJson(r.permissions, []).length + ' صلاحية' }, { label: 'المستخدمون', key: 'users' }],
    fields: [
      { name: 'label', label: 'اسم الدور', required: true },
      { name: 'name', label: 'المعرّف (إنجليزي)', dir: 'ltr', required: true, validate: (v) => (!/^[a-z][a-z0-9_]{2,30}$/.test(v || '') ? 'المعرّف: حروف إنجليزية صغيرة وأرقام و _' : null) },
      { name: 'permissions', label: 'الصلاحيات', type: 'permissions' },
    ],
  },
};

module.exports = { RESOURCES };
