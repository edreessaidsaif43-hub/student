'use strict';
// مولّد حقول النماذج في لوحة التحكم وقراءة قيمها
const db = require('../db');
const uploads = require('../core/uploads');
const { html, raw, utcToLocalInput, localToUtc, clampStr, toInt, safeJson } = require('../core/util');
const { icon } = require('../core/icons');
const { HttpError } = require('../core/http');
const { DAYS } = require('../content-types');

const yearsCache = { at: 0, rows: [] };
async function yearOptions() {
  if (Date.now() - yearsCache.at > 5000) { yearsCache.rows = await db.all('SELECT id, name, is_current FROM academic_years ORDER BY name DESC'); yearsCache.at = Date.now(); }
  return yearsCache.rows;
}

const SAFE_PATH = /^(\/uploads\/[\w.-]+|\/img\/[\w./-]+|\/files\/[\w./-]+|https:\/\/[^\s"'<>]+)$/;

async function renderField(f, value, ctx = {}) {
  const id = 'f_' + f.name;
  const req = f.required ? raw('required') : '';
  const help = f.help ? html`<small class="help">${f.help}</small>` : '';
  const lbl = html`<span class="lbl">${f.label}${f.required ? html` <i class="req">*</i>` : ''}</span>`;
  const v = value == null ? (f.default ?? '') : value;
  switch (f.type) {
    case 'textarea':
      return html`<label class="fld ${f.wide ? 'wide' : ''}" for="${id}">${lbl}<textarea id="${id}" name="${f.name}" rows="${f.rows || 4}" maxlength="${f.max || 5000}" ${req}>${v}</textarea>${help}</label>`;
    case 'markdown':
      return html`<div class="fld wide md-field">${lbl}
        <div class="md-toolbar" role="toolbar" aria-label="أدوات التنسيق">
          <button type="button" data-md="h2" title="عنوان">ع</button><button type="button" data-md="bold" title="عريض"><b>B</b></button>
          <button type="button" data-md="ul" title="قائمة نقطية">•</button><button type="button" data-md="ol" title="قائمة مرقمة">1.</button>
          <button type="button" data-md="quote" title="اقتباس">❝</button><button type="button" data-md="link" title="رابط">${raw(icon('link', 'sm'))}</button>
          <button type="button" data-md="image" title="صورة من المكتبة">${raw(icon('image', 'sm'))}</button>
          <span class="sp"></span><button type="button" class="md-tab on" data-tab="edit">تحرير</button><button type="button" class="md-tab" data-tab="preview">معاينة</button>
        </div>
        <textarea id="${id}" name="${f.name}" rows="${f.rows || 14}" class="md-input" ${req}>${v}</textarea>
        <div class="md-preview prose" hidden></div>
        <small class="help">التنسيق: ## عنوان، **عريض**، - قائمة، 1. قائمة مرقمة، [نص](رابط)، > اقتباس</small></div>`;
    case 'select':
      return html`<label class="fld" for="${id}">${lbl}<select id="${id}" name="${f.name}" ${req}>${f.empty !== false ? html`<option value="">${f.empty || '—'}</option>` : ''}${(f.options || []).map((o) => {
        const [ov, ol] = Array.isArray(o) ? o : [o, o];
        return html`<option value="${ov}" ${String(v) === String(ov) ? raw('selected') : ''}>${ol}</option>`;
      })}</select>${help}</label>`;
    case 'year': {
      const ys = await yearOptions();
      const cur = v || (ctx.isNew ? (ys.find((y) => y.is_current) || {}).id : '');
      return html`<label class="fld" for="${id}">${lbl}<select id="${id}" name="${f.name}"><option value="">—</option>${ys.map((y) => html`<option value="${y.id}" ${String(cur) === String(y.id) ? raw('selected') : ''}>${y.name}${y.is_current ? ' (الحالي)' : ''}</option>`)}</select>${help}</label>`;
    }
    case 'checkbox':
      return html`<label class="fld check"><input type="checkbox" name="${f.name}" value="1" ${v && v !== '0' ? raw('checked') : ''}> <span>${f.label}</span>${help}</label>`;
    case 'number':
      return html`<label class="fld" for="${id}">${lbl}<input id="${id}" type="number" name="${f.name}" value="${v}" ${req} ${f.min != null ? raw(`min="${f.min}"`) : ''}>${help}</label>`;
    case 'date':
      return html`<label class="fld" for="${id}">${lbl}<input id="${id}" type="date" name="${f.name}" value="${String(v).slice(0, 10)}" ${req}>${help}</label>`;
    case 'datetime': // وقت محلي (مسقط) يُخزَّن كنص
      return html`<label class="fld" for="${id}">${lbl}<input id="${id}" type="datetime-local" name="${f.name}" value="${String(v).replace(' ', 'T').slice(0, 16)}" ${req}>${help}</label>`;
    case 'datetime_utc':
      return html`<label class="fld" for="${id}">${lbl}<input id="${id}" type="datetime-local" name="${f.name}" value="${utcToLocalInput(v)}" ${req}>${help}</label>`;
    case 'image':
    case 'file':
      return html`<div class="fld file-field ${f.wide ? 'wide' : ''}" data-kind="${f.type === 'image' ? 'image' : ''}">${lbl}
        <div class="ff-row">
          <div class="ff-preview">${v ? (f.type === 'image' || /\.(png|jpe?g|webp|gif|svg)$/i.test(v) ? html`<img src="${v}" alt="">` : html`${raw(icon('file'))}<span>${String(v).split('/').pop()}</span>`) : html`<span class="muted">لا يوجد ملف</span>`}</div>
          <div class="ff-actions">
            <input type="hidden" name="${f.name}" value="${v}" class="ff-value">
            <label class="btn btn-ghost sm">${raw(icon('plus', 'sm'))} رفع ملف<input type="file" name="${f.name}__upload" class="ff-upload" ${f.type === 'image' ? raw('accept="image/jpeg,image/png,image/webp,image/gif"') : ''} hidden></label>
            <button type="button" class="btn btn-ghost sm" data-pick="${f.type === 'image' ? 'image' : ''}">${raw(icon('folder', 'sm'))} من المكتبة</button>
            <button type="button" class="btn btn-ghost sm danger" data-clear>${raw(icon('x', 'sm'))} إزالة</button>
          </div>
        </div>${help}</div>`;
    case 'grid': {
      const g = safeJson(v, null) || { periods: Array.from({ length: 8 }, (_, i) => ''), cells: DAYS.map(() => Array(8).fill('')) };
      const rows = g.cells.length || 5, cols = g.periods.length || 8;
      return html`<div class="fld wide">${lbl}
        <div class="grid-editor" data-name="${f.name}">
          <div class="ge-tools"><button type="button" class="btn btn-ghost sm" data-ge="addcol">+ عمود</button><button type="button" class="btn btn-ghost sm" data-ge="delcol">− عمود</button><button type="button" class="btn btn-ghost sm" data-ge="addrow">+ صف</button><button type="button" class="btn btn-ghost sm" data-ge="delrow">− صف</button></div>
          <div class="table-wrap"><table><thead><tr><th>الصف/العمود</th>${g.periods.map((p) => html`<th><input class="ge-period" value="${p}" placeholder="الوقت / العنوان"></th>`)}</tr></thead>
          <tbody>${g.cells.map((row, d) => html`<tr><th><input class="ge-day" value="${(g.dayLabels && g.dayLabels[d]) || DAYS[d] || ''}"></th>${Array.from({ length: cols }, (_, c) => html`<td><input class="ge-cell" value="${row[c] || ''}"></td>`)}</tr>`)}</tbody></table></div>
          <input type="hidden" name="${f.name}" class="ge-value" value="${JSON.stringify(g)}">
        </div>${help}</div>`;
    }
    case 'questions': {
      const qs = ctx.questions || [];
      return html`<div class="fld wide">${lbl}<div class="q-editor">
        <div class="q-list">${qs.map((q) => qRow(q))}</div>
        <template id="q-tpl">${qRow({ id: '', text: '', qtype: 'rating', options: '', required: 1 })}</template>
        <button type="button" class="btn btn-ghost sm" data-q="add">${raw(icon('plus', 'sm'))} إضافة سؤال</button>
        ${ctx.hasResponses ? html`<small class="help warn">تنبيه: توجد ردود على هذه الاستبانة؛ حذف سؤال يحذف إجاباته من النتائج.</small>` : ''}
      </div></div>`;
    }
    case 'permissions': {
      const { PERMISSIONS } = require('../content-types');
      const set = new Set(safeJson(v, []));
      return html`<div class="fld wide">${lbl}<div class="perm-grid">${Object.entries(PERMISSIONS).map(([k, l]) => html`<label class="check"><input type="checkbox" name="${f.name}" value="${k}" ${set.has(k) ? raw('checked') : ''} ${ctx.locked ? raw('disabled') : ''}> <span>${l}<small dir="ltr">${k}</small></span></label>`)}</div>${help}</div>`;
    }
    case 'password':
      return html`<label class="fld" for="${id}">${lbl}<input id="${id}" type="password" name="${f.name}" autocomplete="new-password" minlength="10" ${req}>${help}</label>`;
    case 'readonly':
      return html`<div class="fld ${f.wide ? 'wide' : ''}">${lbl}<div class="ro">${f.render ? raw(f.render(v, ctx)) : v}</div></div>`;
    default:
      return html`<label class="fld ${f.wide ? 'wide' : ''}" for="${id}">${lbl}<input id="${id}" type="${f.inputType || 'text'}" name="${f.name}" value="${v}" maxlength="${f.max || 300}" ${req} ${f.dir ? raw(`dir="${f.dir}"`) : ''} ${f.placeholder ? raw(`placeholder="${f.placeholder}"`) : ''}>${help}</label>`;
  }
}

function qRow(q) {
  const opts = Array.isArray(q.options) ? q.options : safeJson(q.options, []);
  return html`<div class="q-row"><input type="hidden" name="q_id" value="${q.id}">
    <span class="q-handle" aria-hidden="true">⋮⋮</span>
    <input name="q_text" value="${q.text}" placeholder="نص السؤال" class="q-text">
    <select name="q_type">${[['rating', 'تقييم 1–5'], ['single', 'اختيار واحد'], ['multi', 'اختيار متعدد'], ['text', 'إجابة نصية']].map(([k, l]) => html`<option value="${k}" ${q.qtype === k ? raw('selected') : ''}>${l}</option>`)}</select>
    <input name="q_options" value="${opts.join('، ')}" placeholder="الخيارات مفصولة بفاصلة (للاختيار)" class="q-opts">
    <select name="q_required"><option value="1" ${q.required ? raw('selected') : ''}>إلزامي</option><option value="0" ${!q.required ? raw('selected') : ''}>اختياري</option></select>
    <button type="button" class="icon-btn danger" data-q="del" aria-label="حذف السؤال">${raw(icon('trash', 'sm'))}</button></div>`;
}

// قراءة القيم من الطلب وفق تعريف الحقول
async function readFields(fields, req) {
  const out = {};
  for (const f of fields) {
    if (['readonly', 'questions', 'password'].includes(f.type) || f.virtual) continue;
    let v = req.body[f.name];
    if (Array.isArray(v) && f.type !== 'permissions') v = v[v.length - 1];
    switch (f.type) {
      case 'checkbox': out[f.name] = v ? 1 : 0; break;
      case 'number': out[f.name] = v === '' || v == null ? (f.required ? 0 : null) : toInt(v); break;
      case 'year': out[f.name] = v ? toInt(v) : null; break;
      case 'date': out[f.name] = /^\d{4}-\d{2}-\d{2}$/.test(v || '') ? v : null; break;
      case 'datetime': out[f.name] = /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}/.test(v || '') ? v.replace('T', ' ').slice(0, 16) : /^\d{4}-\d{2}-\d{2}$/.test(v || '') ? v : null; break;
      case 'datetime_utc': out[f.name] = localToUtc(v); break;
      case 'select': {
        const allowed = (f.options || []).map((o) => String(Array.isArray(o) ? o[0] : o));
        out[f.name] = v && allowed.includes(String(v)) ? v : (f.required ? allowed[0] : null);
        break;
      }
      case 'image': case 'file': {
        const up = req.files[f.name + '__upload'];
        if (up) out[f.name] = await uploads.save(Array.isArray(up) ? up[0] : up, req.user, { allowKinds: f.type === 'image' ? ['image'] : f.kinds });
        else out[f.name] = v && SAFE_PATH.test(v) ? v : null;
        break;
      }
      case 'grid': {
        const g = safeJson(v, null);
        if (g && Array.isArray(g.periods) && Array.isArray(g.cells)) {
          const clean = { periods: g.periods.slice(0, 15).map((x) => clampStr(x, 40)), cells: g.cells.slice(0, 15).map((r) => (Array.isArray(r) ? r : []).slice(0, 15).map((x) => clampStr(x, 60))) };
          if (Array.isArray(g.dayLabels)) clean.dayLabels = g.dayLabels.slice(0, 15).map((x) => clampStr(x, 40));
          out[f.name] = JSON.stringify(clean);
        } else out[f.name] = null;
        break;
      }
      case 'permissions': out[f.name] = JSON.stringify([].concat(v || []).filter((x) => typeof x === 'string')); break;
      default: out[f.name] = v == null || v === '' ? null : clampStr(v, f.type === 'markdown' ? 60000 : f.max || (f.type === 'textarea' ? 5000 : 300));
    }
    if (f.required && (out[f.name] === null || out[f.name] === '')) throw new HttpError(400, `الحقل «${f.label}» مطلوب`);
    if (f.validate) { const err = f.validate(out[f.name]); if (err) throw new HttpError(400, err); }
  }
  return out;
}

module.exports = { renderField, readFields, yearOptions };
