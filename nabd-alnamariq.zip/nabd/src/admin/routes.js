'use strict';
// مسارات لوحة التحكم
const db = require('../db');
const config = require('../config');
const uploads = require('../core/uploads');
const { html, raw, esc, markdown, fmtUtcDT, fmtUtc, fmtNum, toInt, clampStr, slugify, safeJson, nowSql, excerpt, utcToLocalInput, localToUtc, isEmail } = require('../core/util');
const { icon } = require('../core/icons');
const { HttpError } = require('../core/http');
const S = require('../core/security');
const { TYPES, STATUSES, PERMISSIONS } = require('../content-types');
const { adminShell, flash, can } = require('./layout');
const { renderField, readFields } = require('./forms');
const { RESOURCES } = require('./resources');
const { removeDemo, DEFAULT_SETTINGS } = require('../seed');

const PER = 20;

// ===== وسائط وسيطة =====
function auth(perm) {
  return async (req, res, next) => {
    if (!req.user) throw new HttpError(401, 'يجب تسجيل الدخول');
    if (req.user.mustChange && req.path !== '/admin/password') return res.redirect('/admin/password');
    if (perm) S.requirePerm(req, perm);
    if (req.method === 'POST') S.checkCsrf(req);
    await next();
  };
}
const csrfInput = (req) => html`<input type="hidden" name="_csrf" value="${req.session.csrf}">`;
const statusPill = (s) => html`<span class="pill ${STATUSES[s]?.cls || ''}">${STATUSES[s]?.label || s}</span>`;
const page = async (req, res, title, body, actions) => res.send(await adminShell(req, { title, body, actions }));
const back = (req, fallback) => { const r = String(req.body._back || ''); return r.startsWith('/admin') ? r : fallback; };

module.exports = function register(r) {
  // ===== الدخول والخروج =====
  r.get('/admin/login', async (req, res) => {
    if (req.user) return res.redirect('/admin');
    const s = await db.settings();
    const err = req.query.err;
    const body = html`<div class="login-wrap"><form class="login-card" method="post" action="/admin/login">
      <img src="${s.logo || '/img/logo.svg'}" alt="" width="72" height="72"><h1>${s.site_name}</h1><p class="muted">تسجيل الدخول إلى لوحة التحكم</p>
      ${err ? html`<div class="flash err" role="alert">${err === 'rate' ? 'محاولات كثيرة. انتظر 15 دقيقة ثم حاول مجددًا.' : 'البريد الإلكتروني أو كلمة المرور غير صحيحة.'}</div>` : ''}
      <input type="hidden" name="next" value="${String(req.query.next || '').startsWith('/admin') ? req.query.next : '/admin'}">
      <input type="hidden" name="_ft" value="${S.formToken()}">
      <label class="fld">البريد الإلكتروني<input type="email" name="email" required autocomplete="username" dir="ltr" autofocus></label>
      <label class="fld">كلمة المرور<input type="password" name="password" required autocomplete="current-password" dir="ltr"></label>
      <button class="btn btn-gold block" type="submit">${raw(icon('shield', 'sm'))} دخول</button>
      <a class="muted small" href="/">← العودة إلى الموقع</a>
    </form></div>`;
    res.send(await adminShell(req, { title: 'تسجيل الدخول', body }));
  });

  r.post('/admin/login', async (req, res) => {
    S.checkFormToken(req);
    const email = clampStr(req.body.email, 120).toLowerCase();
    const key = 'login:' + req.ip;
    if (!S.rateLimit(key, 8, 15 * 60e3) || !S.rateLimit('login-email:' + email, 8, 15 * 60e3)) return res.redirect('/admin/login?err=rate');
    const u = await db.get('SELECT * FROM users WHERE email = ? AND active = 1', email);
    if (!u || !S.verifyPassword(req.body.password || '', u.password_hash)) {
      await db.audit(req, 'login_failed', 'user', u ? u.id : null, { email });
      return res.redirect('/admin/login?err=1');
    }
    S.resetRate(key); S.resetRate('login-email:' + email);
    await S.createSession(req, res, u);
    await db.run("UPDATE users SET last_login_at = datetime('now') WHERE id = ?", u.id);
    await db.run("DELETE FROM sessions WHERE expires_at < datetime('now')");
    req.user = { id: u.id, name: u.name };
    await db.audit(req, 'login', 'user', u.id);
    const nxt = String(req.body.next || '/admin');
    res.redirect(nxt.startsWith('/admin') && !nxt.startsWith('//') ? nxt : '/admin');
  });

  r.post('/admin/logout', auth(), async (req, res) => {
    await db.audit(req, 'logout', 'user', req.user.id);
    await S.destroySession(req, res);
    res.redirect('/admin/login');
  });

  r.get('/admin/password', auth(), async (req, res) => {
    const body = html`<form class="panel narrow" method="post" action="/admin/password">${csrfInput(req)}
      ${req.user.mustChange ? html`<div class="flash warn">يجب تغيير كلمة المرور المؤقتة قبل المتابعة.</div>` : ''}
      <label class="fld">كلمة المرور الحالية<input type="password" name="current" required autocomplete="current-password" dir="ltr"></label>
      <label class="fld">كلمة المرور الجديدة<input type="password" name="password" required minlength="10" autocomplete="new-password" dir="ltr"><small class="help">10 أحرف على الأقل، تتضمن حروفًا وأرقامًا.</small></label>
      <label class="fld">تأكيد كلمة المرور<input type="password" name="confirm" required minlength="10" autocomplete="new-password" dir="ltr"></label>
      <button class="btn btn-gold">حفظ كلمة المرور</button></form>`;
    await page(req, res, 'تغيير كلمة المرور', body);
  });
  r.post('/admin/password', auth(), async (req, res) => {
    const u = await db.get('SELECT * FROM users WHERE id = ?', req.user.id);
    if (!S.verifyPassword(req.body.current || '', u.password_hash)) throw new HttpError(400, 'كلمة المرور الحالية غير صحيحة');
    if (req.body.password !== req.body.confirm) throw new HttpError(400, 'كلمتا المرور غير متطابقتين');
    const p = S.passwordProblem(req.body.password); if (p) throw new HttpError(400, p);
    await db.run("UPDATE users SET password_hash = ?, must_change_password = 0, updated_at = datetime('now') WHERE id = ?", S.hashPassword(req.body.password), u.id);
    await db.run('DELETE FROM sessions WHERE user_id = ? AND id != ?', u.id, req.session.id);
    await db.audit(req, 'password_change', 'user', u.id);
    flash(res, 'تم تغيير كلمة المرور بنجاح');
    res.redirect('/admin');
  });

  // ===== لوحة المعلومات =====
  r.get('/admin', auth(), async (req, res) => {
    const u = req.user;
    if (!u.can('dashboard.view')) return res.redirect('/admin/content?type=news');
    const [byStatus, byType, newMsgs, newSug, responses, files, pending, logs, months, top, demoCount] = await Promise.all([
      db.all('SELECT status, COUNT(*) n FROM posts GROUP BY status'),
      db.all("SELECT type, COUNT(*) n FROM posts WHERE status = 'published' GROUP BY type"),
      db.get("SELECT COUNT(*) n FROM messages WHERE status = 'new'"),
      db.get("SELECT COUNT(*) n FROM suggestions WHERE status = 'new'"),
      db.get('SELECT COUNT(*) n FROM survey_responses'),
      db.get('SELECT COUNT(*) n, COALESCE(SUM(size),0) s FROM files'),
      db.all("SELECT p.id, p.title, p.type, p.updated_at, u.name author FROM posts p LEFT JOIN users u ON u.id = p.author_id WHERE p.status = 'review' ORDER BY p.updated_at LIMIT 8"),
      u.can('logs.view') ? db.all('SELECT * FROM audit_log ORDER BY id DESC LIMIT 8') : [],
      db.all("SELECT substr(created_at,1,7) m, COUNT(*) n FROM posts WHERE created_at >= date('now','-11 months','start of month') GROUP BY m"),
      db.all("SELECT id, title, type, views FROM posts WHERE status = 'published' ORDER BY views DESC LIMIT 5"),
      db.get('SELECT (SELECT COUNT(*) FROM posts WHERE is_demo = 1) + (SELECT COUNT(*) FROM gallery WHERE is_demo = 1) + (SELECT COUNT(*) FROM staff WHERE is_demo = 1) n'),
    ]);
    const st = Object.fromEntries(byStatus.map((x) => [x.status, x.n]));
    const ms = [];
    const d = new Date();
    for (let i = 11; i >= 0; i--) { const x = new Date(Date.UTC(d.getUTCFullYear(), d.getUTCMonth() - i, 1)); const k = x.toISOString().slice(0, 7); ms.push({ k, l: new Intl.DateTimeFormat('ar-OM', { month: 'short' }).format(x), n: (months.find((m) => m.m === k) || {}).n || 0 }); }
    const mx = Math.max(1, ...ms.map((m) => m.n));
    const kpi = (ic, n, l, href, cls = '') => html`<a class="kpi ${cls}" href="${href}"><span class="kpi-ic">${raw(icon(ic))}</span><b>${fmtNum(n)}</b><small>${l}</small></a>`;
    const body = html`
    ${demoCount.n ? html`<div class="flash warn demo-box">${raw(icon('info', 'sm'))} يحتوي الموقع على <b>${demoCount.n}</b> عنصرًا تجريبيًا (مُعلَّمة «تجريبي»). ${u.can('settings.manage') ? html`<form method="post" action="/admin/demo/remove" data-confirm="سيتم حذف كل المحتوى التجريبي نهائيًا (الأخبار والصور والجداول…). هل أنت متأكد؟">${csrfInput(req)}<button class="btn btn-danger sm">حذف المحتوى التجريبي</button></form>` : ''}</div>` : ''}
    <div class="kpis">
      ${kpi('check', st.published || 0, 'محتوى منشور', '/admin/content?status=published')}
      ${kpi('edit', st.draft || 0, 'مسودات', '/admin/content?status=draft')}
      ${kpi('eye', st.review || 0, 'بانتظار المراجعة', '/admin/content?status=review', st.review ? 'hot' : '')}
      ${u.can('inbox.manage') ? kpi('inbox', newMsgs.n, 'رسائل جديدة', '/admin/r/messages?status=new', newMsgs.n ? 'hot' : '') : ''}
      ${u.can('inbox.manage') ? kpi('lightbulb', newSug.n, 'مقترحات جديدة', '/admin/r/suggestions?status=new', newSug.n ? 'hot' : '') : ''}
      ${u.can('surveys.manage') ? kpi('poll', responses.n, 'ردود الاستبانات', '/admin/r/surveys') : ''}
      ${kpi('folder', files.n, 'ملفات مرفوعة · ' + uploads.fmtSize(files.s), '/admin/media')}
    </div>
    <div class="dash-grid">
      <section class="panel"><h2>${raw(icon('chart', 'sm'))} المحتوى المُنشأ خلال 12 شهرًا</h2>
        <div class="bars" role="img" aria-label="رسم بياني لعدد المحتوى شهريًا">${ms.map((m) => html`<div class="bar" title="${m.l}: ${m.n}"><span style="height:${Math.round((m.n / mx) * 100)}%"><em>${m.n || ''}</em></span><small>${m.l}</small></div>`)}</div>
      </section>
      <section class="panel"><h2>${raw(icon('news', 'sm'))} المنشور حسب القسم</h2>
        <ul class="type-bars">${Object.entries(TYPES).map(([k, t]) => { const n = (byType.find((b) => b.type === k) || {}).n || 0; const tot = Math.max(1, ...byType.map((b) => b.n)); return html`<li><a href="/admin/content?type=${k}">${t.label}</a><span class="tb"><i style="width:${(n / tot) * 100}%"></i></span><b>${n}</b></li>`; })}</ul>
      </section>
      <section class="panel"><h2>${raw(icon('eye', 'sm'))} بانتظار المراجعة</h2>
        ${pending.length ? html`<ul class="plain">${pending.map((p) => html`<li><a href="/admin/content/${p.id}">${p.title}</a><small>${TYPES[p.type].single} · ${p.author || ''} · ${fmtUtcDT(p.updated_at)}</small></li>`)}</ul>` : html`<p class="muted">لا يوجد محتوى بانتظار المراجعة.</p>`}
      </section>
      <section class="panel"><h2>${raw(icon('star', 'sm'))} الأكثر مشاهدة</h2>
        <ul class="plain">${top.map((p) => html`<li><a href="/admin/content/${p.id}">${p.title}</a><small>${fmtNum(p.views)} مشاهدة</small></li>`)}</ul>
      </section>
      ${u.can('logs.view') ? html`<section class="panel wide"><h2>${raw(icon('log', 'sm'))} آخر العمليات <a class="more" href="/admin/logs">السجل الكامل</a></h2>${logTable(logs)}</section>` : ''}
    </div>`;
    const actions = u.can('content.create') ? html`<a class="btn btn-gold sm" href="/admin/content/new?type=news">${raw(icon('plus', 'sm'))} خبر جديد</a>` : '';
    await page(req, res, 'لوحة المعلومات', body, actions);
  });

  // ===== المحتوى =====
  const contentPerm = ['content.create', 'content.edit_own', 'content.edit_all'];
  const canEdit = (u, p) => u.can('content.edit_all') || (u.can('content.edit_own') && p.author_id === u.id);

  r.get('/admin/content', auth(contentPerm), async (req, res) => {
    const u = req.user;
    const type = TYPES[req.query.type] ? req.query.type : '';
    const status = STATUSES[req.query.status] ? req.query.status : '';
    const where = ['1=1'], args = [];
    if (type) { where.push('p.type = ?'); args.push(type); }
    if (status) { where.push('p.status = ?'); args.push(status); }
    if (req.query.q) { where.push('(p.title LIKE ? OR p.search_text LIKE ?)'); args.push('%' + req.query.q + '%', '%' + req.query.q + '%'); }
    if (req.query.year) { where.push('p.academic_year_id = ?'); args.push(toInt(req.query.year)); }
    if (req.query.mine === '1' || !u.can('content.edit_all')) { where.push('p.author_id = ?'); args.push(u.id); }
    const pg = Math.max(1, toInt(req.query.page, 1));
    const total = (await db.get(`SELECT COUNT(*) n FROM posts p WHERE ${where.join(' AND ')}`, ...args)).n;
    const rows = await db.all(`SELECT p.id, p.type, p.title, p.slug, p.status, p.featured, p.pinned, p.is_demo, p.published_at, p.updated_at, p.views, p.cover, u.name author, y.name year FROM posts p LEFT JOIN users u ON u.id = p.author_id LEFT JOIN academic_years y ON y.id = p.academic_year_id WHERE ${where.join(' AND ')} ORDER BY p.updated_at DESC LIMIT ? OFFSET ?`, ...args, PER, (pg - 1) * PER);
    const years = await db.all('SELECT id, name FROM academic_years ORDER BY name DESC');
    const qs = (o) => '/admin/content?' + new URLSearchParams(Object.fromEntries(Object.entries({ ...req.query, page: '', ...o }).filter(([, v]) => v))).toString();
    const title = type ? TYPES[type].label : 'كل المحتوى';
    const now = nowSql();
    const body = html`
    <div class="toolbar">
      <div class="seg">${[['', 'الكل'], ...Object.entries(STATUSES).map(([k, v]) => [k, v.label])].map(([k, l]) => html`<a class="${status === k ? 'on' : ''}" href="${qs({ status: k })}">${l}</a>`)}</div>
      <form method="get" class="tb-search">${type ? html`<input type="hidden" name="type" value="${type}">` : ''}${status ? html`<input type="hidden" name="status" value="${status}">` : ''}
        <select name="type" aria-label="القسم"><option value="">كل الأقسام</option>${Object.entries(TYPES).map(([k, t]) => html`<option value="${k}" ${type === k ? raw('selected') : ''}>${t.label}</option>`)}</select>
        <select name="year" aria-label="العام"><option value="">كل الأعوام</option>${years.map((y) => html`<option value="${y.id}" ${String(req.query.year) === String(y.id) ? raw('selected') : ''}>${y.name}</option>`)}</select>
        <input type="search" name="q" value="${req.query.q || ''}" placeholder="بحث بالعنوان أو النص…"><button class="btn btn-navy sm">بحث</button></form>
    </div>
    <form method="post" action="/admin/content/bulk" class="panel flush" data-bulk>${csrfInput(req)}<input type="hidden" name="_back" value="${req.path + (req.search || '')}">
      <div class="bulk-bar"><label class="check"><input type="checkbox" data-check-all> تحديد الكل</label>
        <select name="action" aria-label="إجراء جماعي"><option value="">إجراء جماعي…</option>${u.can('content.publish') ? html`<option value="publish">نشر</option><option value="archive">أرشفة</option>` : ''}<option value="draft">تحويل لمسودة</option>${u.can('content.delete') ? html`<option value="delete">حذف</option>` : ''}</select>
        <button class="btn btn-ghost sm" data-confirm="تنفيذ الإجراء على العناصر المحددة؟">تطبيق</button><span class="muted">${fmtNum(total)} عنصر</span></div>
      <div class="table-wrap"><table class="list"><thead><tr><th></th><th></th><th>العنوان</th><th>القسم</th><th>الحالة</th><th>الكاتب</th><th>النشر</th><th>المشاهدات</th></tr></thead><tbody>
      ${rows.length ? rows.map((p) => html`<tr>
        <td><input type="checkbox" name="ids" value="${p.id}" aria-label="تحديد"></td>
        <td>${p.cover ? html`<img class="thumb" src="${p.cover}" alt="">` : ''}</td>
        <td><a class="row-title" href="/admin/content/${p.id}">${p.title}</a> ${p.featured ? html`<span class="pill gold">مميز</span>` : ''}${p.pinned ? html`<span class="pill gold">مثبّت</span>` : ''}${p.is_demo ? html`<span class="pill demo">تجريبي</span>` : ''}
          <div class="row-actions"><a href="/admin/content/${p.id}">تعديل</a>${p.status === 'published' ? html` · <a href="${TYPES[p.type].path}/${encodeURIComponent(p.slug)}" target="_blank" rel="noopener">عرض</a>` : ''}</div></td>
        <td>${TYPES[p.type].single}</td><td>${statusPill(p.status)}${p.status === 'published' && p.published_at > now ? html` <span class="pill amber">مجدول</span>` : ''}</td>
        <td>${p.author || '—'}</td><td>${p.published_at ? fmtUtc(p.published_at, { dateStyle: 'medium' }) : '—'}</td><td>${fmtNum(p.views)}</td></tr>`) : html`<tr><td colspan="8" class="empty-row">لا يوجد محتوى مطابق.</td></tr>`}
      </tbody></table></div>
    </form>
    ${pager(pg, Math.ceil(total / PER), qs)}`;
    const actions = u.can('content.create') ? html`<a class="btn btn-gold sm" href="/admin/content/new?type=${type || 'news'}">${raw(icon('plus', 'sm'))} إضافة ${type ? TYPES[type].single : 'محتوى'}</a>` : '';
    await page(req, res, title, body, actions);
  });

  function postFields(type) {
    const t = TYPES[type];
    const f = [
      { name: 'title', label: 'العنوان', required: true, wide: true, max: 200 },
      { name: 'excerpt', label: 'ملخص قصير', type: 'textarea', rows: 2, max: 400, wide: true, help: 'يظهر في البطاقات ونتائج البحث ومحركات البحث' },
      { name: 'body', label: 'المحتوى', type: 'markdown' },
      { name: 'cover', label: 'صورة الغلاف', type: 'image' },
      { name: 'cover_alt', label: 'وصف الصورة (لسهولة الوصول)', max: 200 },
      { name: 'category', label: 'التصنيف', type: 'select', options: t.categories },
      { name: 'academic_year_id', label: 'العام الدراسي', type: 'year' },
    ];
    if (t.fields.includes('event_start')) f.push({ name: 'event_start', label: type === 'event' ? 'بداية الفعالية' : 'التاريخ', type: 'datetime', required: type === 'event' });
    if (t.fields.includes('event_end')) f.push({ name: 'event_end', label: 'النهاية', type: 'datetime' });
    if (t.fields.includes('location')) f.push({ name: 'location', label: 'المكان' });
    if (t.fields.includes('tags')) f.push({ name: 'tags', label: 'الوسوم', help: 'مفصولة بفاصلة' });
    if (t.fields.includes('attachment')) f.push({ name: 'attachment', label: 'ملف مرفق', type: 'file', kinds: ['document', 'image', 'audio', 'video'] });
    if (t.fields.includes('external_url')) f.push({ name: 'external_url', label: 'رابط خارجي / يوتيوب', dir: 'ltr', validate: (v) => (v && !/^https:\/\//.test(v) ? 'الرابط يجب أن يبدأ بـ https://' : null) });
    f.push({ name: 'slug', label: 'الرابط اللطيف (slug)', dir: 'auto', help: 'يُنشأ تلقائيًا من العنوان إن تُرك فارغًا', max: 90 });
    f.push({ name: 'featured', label: 'محتوى مميز (يظهر في الرئيسية)', type: 'checkbox' });
    f.push({ name: 'pinned', label: 'تثبيت أعلى القائمة', type: 'checkbox' });
    return f;
  }

  async function contentForm(req, res, p, type) {
    const u = req.user;
    const isNew = !p.id;
    const fields = postFields(type);
    const main = fields.filter((f) => ['title', 'excerpt', 'body'].includes(f.name));
    const side = fields.filter((f) => !['title', 'excerpt', 'body'].includes(f.name));
    const revs = isNew ? [] : await db.all('SELECT id, user_name, note, created_at FROM post_revisions WHERE post_id = ? ORDER BY id DESC LIMIT 15', p.id);
    const canPub = u.can('content.publish');
    const body = html`<form class="edit-grid" method="post" action="/admin/content/save" enctype="multipart/form-data" data-dirty>
      ${csrfInput(req)}<input type="hidden" name="id" value="${p.id || ''}"><input type="hidden" name="type" value="${type}">
      <div class="panel">${raw((await Promise.all(main.map((f) => renderField(f, p[f.name], { isNew })))).join(''))}</div>
      <aside>
        <div class="panel publish-box"><h2>${raw(icon('check', 'sm'))} النشر</h2>
          ${!isNew ? html`<p>الحالة: ${statusPill(p.status)} ${p.is_demo ? html`<span class="pill demo">تجريبي</span>` : ''}</p>` : ''}
          ${p.review_note ? html`<div class="flash warn small"><b>ملاحظة المراجع:</b> ${p.review_note}</div>` : ''}
          ${canPub ? raw(await renderField({ name: 'published_at', label: 'تاريخ النشر', type: 'datetime_utc', help: 'اتركه فارغًا للنشر الآن، أو حدّد تاريخًا مستقبليًا للجدولة' }, p.published_at)) : ''}
          ${canPub ? html`<label class="fld">ملاحظة للكاتب (عند الإرجاع)<input name="review_note" maxlength="300" value=""></label>` : ''}
          <div class="pub-actions">
            <button class="btn btn-ghost" name="do" value="draft">${raw(icon('edit', 'sm'))} حفظ كمسودة</button>
            ${canPub ? html`<button class="btn btn-gold" name="do" value="publish">${raw(icon('check', 'sm'))} ${p.status === 'published' ? 'حفظ التحديثات' : 'نشر'}</button>`
              : html`<button class="btn btn-gold" name="do" value="review">${raw(icon('eye', 'sm'))} إرسال للمراجعة</button>`}
            ${canPub && !isNew && p.status === 'review' ? html`<button class="btn btn-ghost" name="do" value="reject">إرجاع للكاتب</button>` : ''}
            ${canPub && !isNew && p.status === 'published' ? html`<button class="btn btn-ghost" name="do" value="archive">${raw(icon('archive', 'sm'))} أرشفة</button>` : ''}
          </div>
          ${!isNew && p.status === 'published' ? html`<a class="small" href="${TYPES[type].path}/${encodeURIComponent(p.slug)}" target="_blank" rel="noopener">${raw(icon('external', 'sm'))} عرض في الموقع</a>` : ''}
        </div>
        <div class="panel">${raw((await Promise.all(side.map((f) => renderField(f, p[f.name], { isNew })))).join(''))}</div>
        ${revs.length ? html`<div class="panel"><h2>${raw(icon('clock', 'sm'))} سجل النسخ</h2><ul class="plain revs">${revs.map((rv) => html`<li><span>${fmtUtcDT(rv.created_at)} · ${rv.user_name || ''}<small>${rv.note || ''}</small></span><button class="btn btn-ghost xs" formaction="/admin/content/${p.id}/restore/${rv.id}" formnovalidate data-confirm="استعادة هذه النسخة؟ ستُحفظ النسخة الحالية في السجل.">استعادة</button></li>`)}</ul></div>` : ''}
        ${!isNew && (u.can('content.delete')) ? html`<div class="panel danger-zone"><button class="btn btn-danger block" formaction="/admin/content/${p.id}/delete" formnovalidate data-confirm="حذف هذا المحتوى نهائيًا؟">${raw(icon('trash', 'sm'))} حذف</button></div>` : ''}
      </aside>
    </form>`;
    await page(req, res, isNew ? `إضافة ${TYPES[type].single}` : `تعديل: ${excerpt(p.title, 50)}`, body, html`<a class="btn btn-ghost sm" href="/admin/content?type=${type}">${raw(icon('arrow', 'sm'))} العودة للقائمة</a>`);
  }

  r.get('/admin/content/new', auth('content.create'), async (req, res) => {
    const type = TYPES[req.query.type] ? req.query.type : 'news';
    await contentForm(req, res, { status: 'draft' }, type);
  });

  r.get('/admin/content/:id', auth(contentPerm), async (req, res, next) => {
    const p = await db.get('SELECT * FROM posts WHERE id = ?', toInt(req.params.id));
    if (!p) return next();
    if (!canEdit(req.user, p)) throw new HttpError(403, 'لا يمكنك تعديل هذا المحتوى');
    await contentForm(req, res, p, p.type);
  });

  function snapshot(p) {
    const keep = ['title', 'excerpt', 'body', 'cover', 'cover_alt', 'category', 'tags', 'event_start', 'event_end', 'location', 'attachment', 'external_url', 'academic_year_id', 'slug', 'featured', 'pinned'];
    return JSON.stringify(Object.fromEntries(keep.map((k) => [k, p[k]])));
  }

  r.post('/admin/content/save', auth(contentPerm), async (req, res) => {
    const u = req.user;
    const id = toInt(req.body.id);
    const existing = id ? await db.get('SELECT * FROM posts WHERE id = ?', id) : null;
    if (id && !existing) throw new HttpError(404, 'المحتوى غير موجود');
    if (existing && !canEdit(u, existing)) throw new HttpError(403, 'لا يمكنك تعديل هذا المحتوى');
    if (!existing && !u.can('content.create')) throw new HttpError(403, 'لا تملك صلاحية الإنشاء');
    const type = existing ? existing.type : req.body.type;
    if (!TYPES[type]) throw new HttpError(400, 'نوع محتوى غير معروف');
    const data = await readFields(postFields(type), req);
    if (type === 'event' && data.event_end && data.event_end < data.event_start) throw new HttpError(400, 'نهاية الفعالية يجب أن تكون بعد بدايتها');

    // الرابط اللطيف الفريد
    let slug = slugify(data.slug || data.title);
    let n = 1;
    while (await db.get('SELECT id FROM posts WHERE type = ? AND slug = ? AND id != ?', type, slug, id || 0)) slug = slugify(data.slug || data.title) + '-' + ++n;
    data.slug = slug;

    // سير العمل: مسودة ← مراجعة ← نشر
    const act = req.body.do;
    const canPub = u.can('content.publish');
    let status = existing ? existing.status : 'draft';
    if (act === 'draft') status = existing && existing.status === 'published' && !canPub ? 'review' : 'draft';
    else if (act === 'review') status = 'review';
    else if (act === 'publish') status = canPub ? 'published' : 'review';
    else if (act === 'reject' && canPub) status = 'draft';
    else if (act === 'archive' && canPub) status = 'archived';
    if (!canPub && existing && existing.status === 'published' && status !== 'published') status = 'review';

    data.status = status;
    if (existing && existing.is_demo) data.is_demo = 0; // المحتوى التجريبي المعدَّل يصبح حقيقيًا ولا يُحذف مع التجريبي
    data.search_text = db.postSearchText(data);
    data.updated_at = nowSql();
    if (canPub) {
      const pa = localToUtc(req.body.published_at);
      if (status === 'published') data.published_at = pa || (existing && existing.published_at) || nowSql();
      else if (pa) data.published_at = pa;
      data.reviewer_id = act === 'publish' || act === 'reject' ? u.id : existing ? existing.reviewer_id : null;
      data.review_note = act === 'reject' ? clampStr(req.body.review_note, 300) || 'يرجى مراجعة المحتوى وتعديله' : act === 'publish' ? null : existing ? existing.review_note : null;
    }

    let pid = id;
    if (existing) {
      await db.insert('post_revisions', { post_id: id, snapshot: snapshot(existing), user_id: u.id, user_name: u.name, note: 'قبل التعديل (' + (STATUSES[existing.status]?.label || '') + ')' });
      await db.update('posts', id, data);
    } else {
      data.type = type; data.author_id = u.id; data.created_at = nowSql();
      pid = await db.insert('posts', data);
    }
    await db.audit(req, existing ? 'update' : 'create', 'post:' + type, pid, { title: data.title, status });
    const msgs = { published: 'تم النشر بنجاح', review: 'تم الإرسال للمراجعة', draft: act === 'reject' ? 'تم إرجاع المحتوى للكاتب' : 'تم الحفظ كمسودة', archived: 'تمت الأرشفة' };
    flash(res, msgs[status] + (status === 'published' && data.published_at > nowSql() ? ' (مجدول للنشر لاحقًا)' : ''));
    res.redirect('/admin/content/' + pid);
  });

  r.post('/admin/content/:id/delete', auth('content.delete'), async (req, res) => {
    const p = await db.get('SELECT id, type, title FROM posts WHERE id = ?', toInt(req.params.id));
    if (!p) throw new HttpError(404, 'غير موجود');
    await db.run('DELETE FROM post_revisions WHERE post_id = ?', p.id);
    await db.run('DELETE FROM posts WHERE id = ?', p.id);
    await db.audit(req, 'delete', 'post:' + p.type, p.id, { title: p.title });
    flash(res, 'تم حذف المحتوى');
    res.redirect('/admin/content?type=' + p.type);
  });

  r.post('/admin/content/:id/restore/:rev', auth(contentPerm), async (req, res) => {
    const p = await db.get('SELECT * FROM posts WHERE id = ?', toInt(req.params.id));
    const rv = p && await db.get('SELECT * FROM post_revisions WHERE id = ? AND post_id = ?', toInt(req.params.rev), p.id);
    if (!rv) throw new HttpError(404, 'النسخة غير موجودة');
    if (!canEdit(req.user, p)) throw new HttpError(403, 'لا يمكنك تعديل هذا المحتوى');
    const snap = safeJson(rv.snapshot, {});
    await db.insert('post_revisions', { post_id: p.id, snapshot: snapshot(p), user_id: req.user.id, user_name: req.user.name, note: 'قبل الاستعادة' });
    const data = { ...snap, updated_at: nowSql() };
    if (await db.get('SELECT id FROM posts WHERE type = ? AND slug = ? AND id != ?', p.type, data.slug, p.id)) delete data.slug;
    data.search_text = db.postSearchText({ ...p, ...data });
    if (!req.user.can('content.publish') && p.status === 'published') data.status = 'review';
    await db.update('posts', p.id, data);
    await db.audit(req, 'restore', 'post:' + p.type, p.id, { revision: rv.id });
    flash(res, 'تمت استعادة النسخة');
    res.redirect('/admin/content/' + p.id);
  });

  r.post('/admin/content/bulk', auth(contentPerm), async (req, res) => {
    const ids = [].concat(req.body.ids || []).map((x) => toInt(x)).filter(Boolean);
    const act = req.body.action;
    if (!ids.length || !act) { flash(res, 'لم يتم تحديد عناصر أو إجراء', 'err'); return res.redirect(back(req, '/admin/content')); }
    const u = req.user;
    let n = 0;
    for (const id of ids) {
      const p = await db.get('SELECT * FROM posts WHERE id = ?', id);
      if (!p || !canEdit(u, p)) continue;
      if (act === 'delete') { if (!u.can('content.delete')) continue; await db.run('DELETE FROM post_revisions WHERE post_id = ?', id); await db.run('DELETE FROM posts WHERE id = ?', id); }
      else if (act === 'publish' || act === 'archive') { if (!u.can('content.publish')) continue; await db.update('posts', id, { status: act === 'publish' ? 'published' : 'archived', published_at: p.published_at || nowSql(), updated_at: nowSql() }); }
      else if (act === 'draft') { if (p.status === 'published' && !u.can('content.publish')) continue; await db.update('posts', id, { status: 'draft', updated_at: nowSql() }); }
      else continue;
      n++;
    }
    await db.audit(req, 'bulk_' + act, 'post', null, { ids, done: n });
    flash(res, `تم تنفيذ الإجراء على ${n} عنصر`);
    res.redirect(back(req, '/admin/content'));
  });

  // ===== مكتبة الوسائط =====
  r.get('/admin/media', auth(['media.upload', 'media.manage']), async (req, res) => {
    const kind = uploads.KIND_LABEL[req.query.kind] ? req.query.kind : '';
    const where = ['1=1'], args = [];
    if (kind) { where.push('kind = ?'); args.push(kind); }
    if (req.query.q) { where.push('original_name LIKE ?'); args.push('%' + req.query.q + '%'); }
    const pg = Math.max(1, toInt(req.query.page, 1));
    const total = (await db.get(`SELECT COUNT(*) n FROM files WHERE ${where.join(' AND ')}`, ...args)).n;
    const rows = await db.all(`SELECT f.*, u.name uploader FROM files f LEFT JOIN users u ON u.id = f.uploaded_by WHERE ${where.join(' AND ')} ORDER BY f.id DESC LIMIT 40 OFFSET ?`, ...args, (pg - 1) * 40);
    const qs = (o) => '/admin/media?' + new URLSearchParams(Object.fromEntries(Object.entries({ ...req.query, page: '', ...o }).filter(([, v]) => v))).toString();
    const body = html`
      <form class="panel upload-box" method="post" action="/admin/media/upload" enctype="multipart/form-data">${csrfInput(req)}
        <label class="drop">${raw(icon('plus'))}<b>اسحب الملفات هنا أو انقر للاختيار</b><small>صور (JPG, PNG, WEBP, GIF)، مستندات (PDF, DOCX, XLSX, PPTX)، فيديو (MP4, WEBM)، صوت (MP3) — حتى ${config.maxUploadMb} م.ب للملف</small><input type="file" name="files" multiple required></label>
        <button class="btn btn-gold">رفع</button></form>
      <div class="toolbar"><div class="seg">${[['', 'الكل'], ...Object.entries(uploads.KIND_LABEL)].map(([k, l]) => html`<a class="${kind === k ? 'on' : ''}" href="${qs({ kind: k })}">${l}</a>`)}</div>
        <form class="tb-search" method="get"><input type="search" name="q" value="${req.query.q || ''}" placeholder="بحث باسم الملف"><button class="btn btn-navy sm">بحث</button></form></div>
      <div class="media-grid">${rows.length ? rows.map((f) => html`<div class="m-item">
        <div class="m-prev">${f.kind === 'image' ? html`<img src="${f.path}" alt="${f.alt || ''}" loading="lazy">` : raw(icon(f.kind === 'video' ? 'video' : 'file'))}</div>
        <div class="m-info"><b title="${f.original_name}">${f.original_name}</b><small>${uploads.fmtSize(f.size)} · ${fmtUtc(f.created_at, { dateStyle: 'medium' })} · ${f.uploader || ''}</small>
          <div class="m-act"><button type="button" class="btn btn-ghost xs" data-copy="${f.path}">نسخ الرابط</button><a class="btn btn-ghost xs" href="${f.path}" target="_blank" rel="noopener">فتح</a>
          ${req.user.can('media.manage') ? html`<form method="post" action="/admin/media/${f.id}/delete" data-confirm="حذف الملف نهائيًا؟ قد يكون مستخدمًا في محتوى منشور.">${csrfInput(req)}<button class="btn btn-ghost xs danger">حذف</button></form>` : ''}</div></div></div>`) : html`<p class="muted">لا توجد ملفات.</p>`}</div>
      ${pager(pg, Math.ceil(total / 40), qs)}`;
    await page(req, res, 'مكتبة الوسائط', body);
  });

  r.post('/admin/media/upload', auth(['media.upload', 'media.manage']), async (req, res) => {
    const files = [].concat(req.files.files || []);
    if (!files.length) throw new HttpError(400, 'لم يتم اختيار ملفات');
    const done = [];
    for (const f of files) done.push(await uploads.save(f, req.user));
    await db.audit(req, 'upload', 'file', null, { count: done.length });
    flash(res, `تم رفع ${done.length} ملف`);
    res.redirect('/admin/media');
  });

  r.post('/admin/media/:id/delete', auth('media.manage'), async (req, res) => {
    const f = await db.get('SELECT * FROM files WHERE id = ?', toInt(req.params.id));
    if (!f) throw new HttpError(404, 'غير موجود');
    await uploads.removeFile(f.path);
    await db.audit(req, 'delete', 'file', f.id, { name: f.original_name });
    flash(res, 'تم حذف الملف');
    res.redirect('/admin/media');
  });

  r.get('/admin/api/files', auth(['media.upload', 'media.manage']), async (req, res) => {
    const where = ['1=1'], args = [];
    if (req.query.kind) { where.push('kind = ?'); args.push(String(req.query.kind)); }
    if (req.query.q) { where.push('original_name LIKE ?'); args.push('%' + req.query.q + '%'); }
    const rows = await db.all(`SELECT id, path, original_name, kind, size FROM files WHERE ${where.join(' AND ')} ORDER BY id DESC LIMIT 60`, ...args);
    const builtIn = req.query.kind === 'image' || !req.query.kind ? ['hero-campus', 'classroom', 'library', 'science-lab', 'robotics', 'sports', 'art', 'national-day', 'environment', 'honoring', 'parents', 'partnership', 'digital', 'math', 'quran-arabic']
      .filter((n) => !req.query.q || n.includes(req.query.q)).map((n) => ({ path: `/img/${n}.svg`, original_name: 'رسم توضيحي: ' + n, kind: 'image' })) : [];
    res.json({ files: rows.concat(builtIn) });
  });

  r.post('/admin/api/upload', auth(['media.upload', 'media.manage']), async (req, res) => {
    const f = [].concat(req.files.file || [])[0];
    if (!f) throw new HttpError(400, 'لم يتم اختيار ملف');
    const p = await uploads.save(f, req.user, { allowKinds: req.body.kind === 'image' ? ['image'] : undefined });
    await db.audit(req, 'upload', 'file', null, { name: f.filename });
    res.json({ path: p, original_name: f.filename });
  });

  // مزامنة أخبار X: تستقبل منشورات مقروءة من صفحة حساب المدرسة (من المتصفح أو مهمة مجدولة)
  r.post('/admin/api/x-import', auth('content.publish'), async (req, res) => {
    const { importXPosts } = require('../imports');
    const result = await importXPosts(req.body.posts);
    await db.audit(req, 'x_sync', 'post', null, { title: `أُضيف ${result.added.length} خبر من X`, count: result.added.length });
    res.json(result);
  });

  r.post('/admin/api/preview', auth(contentPerm), async (req, res) => res.json({ html: markdown(String(req.body.text || '').slice(0, 60000)) }));

  // ===== الموارد العامة =====
  async function resourceFields(key, row) {
    const R = RESOURCES[key];
    const fields = R.fields.map((f) => ({ ...f }));
    if (key === 'users') {
      const roles = await db.all('SELECT id, label FROM roles ORDER BY id');
      fields.find((f) => f.name === 'role_id').options = roles.map((x) => [x.id, x.label]);
      if (!row || !row.id) fields.find((f) => f.name === 'password').required = true;
    }
    return fields;
  }

  r.get('/admin/r/:res', auth(), async (req, res, next) => {
    const key = req.params.res, R = RESOURCES[key];
    if (!R) return next();
    S.requirePerm(req, R.perm);
    const where = ['1=1'], args = [];
    const alias = R.listSql ? R.listSql.match(/FROM \w+ (\w+)/)?.[1] : null;
    const col = (c) => (alias ? alias + '.' + c : c);
    if (req.query.q && R.search) { where.push('(' + R.search.map((c) => col(c) + ' LIKE ?').join(' OR ') + ')'); R.search.forEach(() => args.push('%' + req.query.q + '%')); }
    for (const f of R.filters || []) if (req.query[f.name]) { where.push(col(f.name) + ' = ?'); args.push(String(req.query[f.name])); }
    const pg = Math.max(1, toInt(req.query.page, 1));
    const base = R.listSql || `SELECT * FROM ${R.table}`;
    const total = (await db.get(`SELECT COUNT(*) n FROM (${base} WHERE ${where.join(' AND ')})`, ...args)).n;
    const order = R.order.split(',').map((o) => (alias && !/CASE/.test(o) ? alias + '.' + o.trim() : o.trim())).join(', ');
    const rows = await db.all(`${base} WHERE ${where.join(' AND ')} ORDER BY ${order} LIMIT ? OFFSET ?`, ...args, PER, (pg - 1) * PER);
    const qs = (o) => `/admin/r/${key}?` + new URLSearchParams(Object.fromEntries(Object.entries({ ...req.query, page: '', ...o }).filter(([, v]) => v))).toString();
    const body = html`
      ${R.intro ? html`<p class="intro">${raw(icon('info', 'sm'))} ${R.intro}</p>` : ''}
      ${R.search || R.filters ? html`<form class="toolbar tb-search" method="get">
        ${R.search ? html`<input type="search" name="q" value="${req.query.q || ''}" placeholder="بحث…">` : ''}
        ${(R.filters || []).map((f) => html`<select name="${f.name}" aria-label="${f.label}"><option value="">${f.label}: الكل</option>${f.options.map((o) => { const [v, l] = Array.isArray(o) ? o : [o, o]; return html`<option value="${v}" ${req.query[f.name] === String(v) ? raw('selected') : ''}>${l}</option>`; })}</select>`)}
        <button class="btn btn-navy sm">تصفية</button>${key === 'messages' || key === 'suggestions' ? html`<a class="btn btn-ghost sm" href="/admin/export/${key}.csv">${raw(icon('download', 'sm'))} تصدير CSV</a>` : ''}</form>` : ''}
      <div class="panel flush"><div class="table-wrap"><table class="list"><thead><tr>${R.columns.map((c) => html`<th>${c.label}</th>`)}<th></th></tr></thead><tbody>
        ${rows.length ? rows.map((row) => html`<tr class="${row.status === 'new' ? 'unread' : ''}">${R.columns.map((c) => html`<td>${c.render ? c.render(row) : row[c.key] ?? '—'}</td>`)}
          <td class="nowrap"><a class="btn btn-ghost xs" href="/admin/r/${key}/${row.id}">${R.noCreate ? 'عرض' : 'تعديل'}</a>
          ${key === 'surveys' ? html`<a class="btn btn-ghost xs" href="/admin/surveys/${row.id}/results">النتائج</a>` : ''}
          <form method="post" action="/admin/r/${key}/${row.id}/delete" data-confirm="حذف هذا العنصر نهائيًا؟">${csrfInput(req)}<button class="btn btn-ghost xs danger" aria-label="حذف">${raw(icon('trash', 'sm'))}</button></form></td></tr>`)
          : html`<tr><td colspan="${R.columns.length + 1}" class="empty-row">لا توجد عناصر.</td></tr>`}
      </tbody></table></div></div>${pager(pg, Math.ceil(total / PER), qs)}`;
    const actions = R.noCreate ? '' : html`<a class="btn btn-gold sm" href="/admin/r/${key}/new">${raw(icon('plus', 'sm'))} إضافة ${R.single}</a>`;
    await page(req, res, R.label, body, actions);
  });

  async function resourceForm(req, res, key, row) {
    const R = RESOURCES[key];
    const isNew = !row.id;
    const fields = await resourceFields(key, row);
    const ctx = { isNew };
    if (key === 'surveys') {
      ctx.questions = isNew ? [] : await db.all('SELECT * FROM survey_questions WHERE survey_id = ? ORDER BY sort, id', row.id);
      ctx.hasResponses = !isNew && (await db.get('SELECT COUNT(*) n FROM survey_responses WHERE survey_id = ?', row.id)).n > 0;
    }
    if (key === 'roles' && row.name === 'admin') ctx.locked = true;
    const vals = { ...row };
    if (key === 'users') vals.password = '';
    const multipart = fields.some((f) => f.type === 'image' || f.type === 'file');
    const body = html`<form class="panel form-grid" method="post" action="/admin/r/${key}/save" ${multipart ? raw('enctype="multipart/form-data"') : ''} data-dirty>
      ${csrfInput(req)}<input type="hidden" name="id" value="${row.id || ''}">
      ${row.is_demo ? html`<div class="flash warn wide">هذا عنصر تجريبي. عند تعديله سيُعتبر محتوى حقيقيًا ولن يُحذف مع المحتوى التجريبي.</div>` : ''}
      ${raw((await Promise.all(fields.map((f) => renderField(f, vals[f.name], ctx)))).join(''))}
      <div class="form-actions wide"><button class="btn btn-gold">${raw(icon('check', 'sm'))} حفظ</button><a class="btn btn-ghost" href="/admin/r/${key}">إلغاء</a>
        ${key === 'surveys' && !isNew ? html`<a class="btn btn-ghost" href="/admin/surveys/${row.id}/results">${raw(icon('chart', 'sm'))} النتائج</a><a class="btn btn-ghost" href="/surveys/${row.id}" target="_blank" rel="noopener">${raw(icon('external', 'sm'))} معاينة</a>` : ''}</div>
    </form>`;
    await page(req, res, (isNew ? 'إضافة ' : (R.noCreate ? 'عرض ' : 'تعديل ')) + R.single, body, html`<a class="btn btn-ghost sm" href="/admin/r/${key}">${raw(icon('arrow', 'sm'))} ${R.label}</a>`);
  }

  r.get('/admin/r/:res/new', auth(), async (req, res, next) => {
    const R = RESOURCES[req.params.res];
    if (!R || R.noCreate) return next();
    S.requirePerm(req, R.perm);
    await resourceForm(req, res, req.params.res, {});
  });

  r.get('/admin/r/:res/:id', auth(), async (req, res, next) => {
    const key = req.params.res, R = RESOURCES[key];
    if (!R) return next();
    S.requirePerm(req, R.perm);
    const row = await db.get(`SELECT * FROM ${R.table} WHERE id = ?`, toInt(req.params.id));
    if (!row) return next();
    if (R.onOpen && row[R.onOpen.field] === R.onOpen.from) { await db.run(`UPDATE ${R.table} SET ${R.onOpen.field} = ? WHERE id = ?`, R.onOpen.to, row.id); row[R.onOpen.field] = R.onOpen.to; }
    await resourceForm(req, res, key, row);
  });

  r.post('/admin/r/:res/save', auth(), async (req, res, next) => {
    const key = req.params.res, R = RESOURCES[key];
    if (!R) return next();
    S.requirePerm(req, R.perm);
    const id = toInt(req.body.id);
    const existing = id ? await db.get(`SELECT * FROM ${R.table} WHERE id = ?`, id) : null;
    if (id && !existing) throw new HttpError(404, 'العنصر غير موجود');
    if (!existing && R.noCreate) throw new HttpError(400, 'لا يمكن إنشاء هذا العنصر يدويًا');
    const fields = await resourceFields(key, existing);
    const data = await readFields(fields, req);
    if (R.validate) { const e = R.validate(data); if (e) throw new HttpError(400, e); }

    // قواعد خاصة
    if (key === 'users') {
      data.email = String(data.email).toLowerCase();
      if (await db.get('SELECT id FROM users WHERE email = ? AND id != ?', data.email, id || 0)) throw new HttpError(400, 'البريد الإلكتروني مستخدم مسبقًا');
      if (!(await db.get('SELECT id FROM roles WHERE id = ?', toInt(data.role_id)))) throw new HttpError(400, 'الدور غير صالح');
      data.role_id = toInt(data.role_id);
      if (req.body.password) { const p = S.passwordProblem(req.body.password); if (p) throw new HttpError(400, p); data.password_hash = S.hashPassword(req.body.password); }
      else if (!existing) throw new HttpError(400, 'كلمة المرور مطلوبة');
      if (existing && existing.id === req.user.id && (!data.active || data.role_id !== existing.role_id)) throw new HttpError(400, 'لا يمكنك تعطيل حسابك أو تغيير دورك بنفسك');
      if (existing) {
        const adminRole = await db.get("SELECT id FROM roles WHERE name = 'admin'");
        if (existing.role_id === adminRole.id && (data.role_id !== adminRole.id || !data.active) && (await db.get('SELECT COUNT(*) n FROM users WHERE role_id = ? AND active = 1', adminRole.id)).n <= 1) throw new HttpError(400, 'يجب أن يبقى مدير نظام نشط واحد على الأقل');
      }
    }
    if (key === 'roles') {
      if (existing && existing.name === 'admin') { data.permissions = JSON.stringify(Object.keys(PERMISSIONS)); data.name = 'admin'; }
      if (await db.get('SELECT id FROM roles WHERE name = ? AND id != ?', data.name, id || 0)) throw new HttpError(400, 'المعرّف مستخدم مسبقًا');
      if (existing && existing.is_system) data.name = existing.name;
    }
    if (key === 'years' && await db.get('SELECT id FROM academic_years WHERE name = ? AND id != ?', data.name, id || 0)) throw new HttpError(400, 'هذا العام موجود مسبقًا');

    if (!R.noTimestamps && key !== 'users') data.updated_at = nowSql();
    if (key === 'users') data.updated_at = nowSql();
    if (existing && existing.is_demo !== undefined && existing.is_demo) data.is_demo = 0;

    let rid = id;
    if (existing) await db.update(R.table, id, data);
    else rid = await db.insert(R.table, data);

    if (key === 'years' && data.is_current) await db.run('UPDATE academic_years SET is_current = 0 WHERE id != ?', rid);
    if (key === 'users' && req.body.password && existing) await db.run('DELETE FROM sessions WHERE user_id = ?', rid);
    if (key === 'users' && existing && !data.active) await db.run('DELETE FROM sessions WHERE user_id = ?', rid);
    if (key === 'surveys') await saveQuestions(req, rid);

    await db.audit(req, existing ? 'update' : 'create', key, rid, { title: data.title || data.name || data.label || data.message || undefined });
    flash(res, 'تم الحفظ بنجاح');
    res.redirect(`/admin/r/${key}/${rid}`);
  });

  r.post('/admin/r/:res/:id/delete', auth(), async (req, res, next) => {
    const key = req.params.res, R = RESOURCES[key];
    if (!R) return next();
    S.requirePerm(req, R.perm);
    const row = await db.get(`SELECT * FROM ${R.table} WHERE id = ?`, toInt(req.params.id));
    if (!row) throw new HttpError(404, 'غير موجود');
    if (key === 'users' && row.id === req.user.id) throw new HttpError(400, 'لا يمكنك حذف حسابك');
    if (key === 'users' && (await db.get('SELECT COUNT(*) n FROM posts WHERE author_id = ?', row.id)).n) {
      await db.run('UPDATE posts SET author_id = NULL WHERE author_id = ?', row.id);
    }
    if (key === 'users') { await db.run('DELETE FROM sessions WHERE user_id = ?', row.id); await db.run('UPDATE files SET uploaded_by = NULL WHERE uploaded_by = ?', row.id); }
    if (key === 'roles') {
      if (row.is_system) throw new HttpError(400, 'لا يمكن حذف الأدوار الأساسية');
      if ((await db.get('SELECT COUNT(*) n FROM users WHERE role_id = ?', row.id)).n) throw new HttpError(400, 'لا يمكن حذف دور مرتبط بمستخدمين');
    }
    if (key === 'years' && row.is_current) throw new HttpError(400, 'لا يمكن حذف العام الدراسي الحالي');
    if (key === 'surveys') { await db.run('DELETE FROM survey_responses WHERE survey_id = ?', row.id); await db.run('DELETE FROM survey_questions WHERE survey_id = ?', row.id); }
    await db.run(`DELETE FROM ${R.table} WHERE id = ?`, row.id);
    await db.audit(req, 'delete', key, row.id, { title: row.title || row.name || row.label });
    flash(res, 'تم الحذف');
    res.redirect('/admin/r/' + key);
  });

  async function saveQuestions(req, sid) {
    const ids = [].concat(req.body.q_id ?? []), texts = [].concat(req.body.q_text ?? []), types = [].concat(req.body.q_type ?? []), opts = [].concat(req.body.q_options ?? []), reqs = [].concat(req.body.q_required ?? []);
    const keep = [];
    for (let i = 0; i < texts.length; i++) {
      const text = clampStr(texts[i], 300);
      if (!text) continue;
      const qtype = ['rating', 'single', 'multi', 'text'].includes(types[i]) ? types[i] : 'rating';
      const options = ['single', 'multi'].includes(qtype) ? JSON.stringify(String(opts[i] || '').split(/[،,]/).map((x) => x.trim()).filter(Boolean).slice(0, 12)) : null;
      if (options && JSON.parse(options).length < 2) throw new HttpError(400, `السؤال «${text}» يحتاج خيارين على الأقل`);
      const data = { text, qtype, options, required: reqs[i] === '0' ? 0 : 1, sort: i };
      const qid = toInt(ids[i]);
      if (qid && await db.get('SELECT id FROM survey_questions WHERE id = ? AND survey_id = ?', qid, sid)) { await db.update('survey_questions', qid, data); keep.push(qid); }
      else keep.push(await db.insert('survey_questions', { ...data, survey_id: sid }));
    }
    const existing = await db.all('SELECT id FROM survey_questions WHERE survey_id = ?', sid);
    for (const q of existing) if (!keep.includes(q.id)) await db.run('DELETE FROM survey_questions WHERE id = ?', q.id);
  }

  // ===== نتائج الاستبانات =====
  r.get('/admin/surveys/:id/results', auth('surveys.manage'), async (req, res, next) => {
    const sv = await db.get('SELECT * FROM surveys WHERE id = ?', toInt(req.params.id));
    if (!sv) return next();
    const qs = await db.all('SELECT * FROM survey_questions WHERE survey_id = ? ORDER BY sort, id', sv.id);
    const resp = (await db.all('SELECT answers, created_at FROM survey_responses WHERE survey_id = ? ORDER BY id DESC', sv.id)).map((x) => ({ a: safeJson(x.answers, {}), at: x.created_at }));
    const body = html`<div class="panel"><p>${sv.description || ''}</p><p><b>${fmtNum(resp.length)}</b> رد ${resp.length ? html`· <a href="/admin/surveys/${sv.id}/export.csv">${raw(icon('download', 'sm'))} تصدير CSV</a>` : ''}</p></div>
      ${qs.map((q, i) => {
        const vals = resp.map((x) => x.a[q.id]).filter((v) => v !== undefined && v !== '' && !(Array.isArray(v) && !v.length));
        let inner;
        if (q.qtype === 'text') inner = vals.length ? html`<ul class="answers">${vals.slice(0, 100).map((v) => html`<li>${v}</li>`)}</ul>` : html`<p class="muted">لا توجد إجابات.</p>`;
        else {
          const opts = q.qtype === 'rating' ? ['1', '2', '3', '4', '5'] : safeJson(q.options, []);
          const cnt = Object.fromEntries(opts.map((o) => [o, 0]));
          for (const v of vals) for (const x of [].concat(v)) if (cnt[x] !== undefined) cnt[x]++;
          const mx = Math.max(1, ...Object.values(cnt));
          const avg = q.qtype === 'rating' && vals.length ? (vals.reduce((a, b) => a + Number(b), 0) / vals.length).toFixed(2) : null;
          inner = html`${avg ? html`<p class="avg">المتوسط: <b>${avg}</b> / 5</p>` : ''}<ul class="type-bars">${opts.map((o) => html`<li><span>${q.qtype === 'rating' ? ['', 'ضعيف', 'مقبول', 'جيد', 'جيد جدًا', 'ممتاز'][o] + ' (' + o + ')' : o}</span><span class="tb"><i style="width:${(cnt[o] / mx) * 100}%"></i></span><b>${cnt[o]} ${vals.length ? '(' + Math.round((cnt[o] / vals.length) * 100) + '%)' : ''}</b></li>`)}</ul>`;
        }
        return html`<section class="panel"><h2>${i + 1}. ${q.text}</h2><small class="muted">${vals.length} إجابة</small>${inner}</section>`;
      })}`;
    await page(req, res, 'نتائج: ' + sv.title, body, html`<a class="btn btn-ghost sm" href="/admin/r/surveys/${sv.id}">تعديل الاستبانة</a>`);
  });

  const csv = (rows) => '﻿' + rows.map((r2) => r2.map((c) => '"' + String(c ?? '').replace(/"/g, '""') + '"').join(',')).join('\r\n');
  r.get('/admin/surveys/:id/export.csv', auth('surveys.manage'), async (req, res, next) => {
    const sv = await db.get('SELECT * FROM surveys WHERE id = ?', toInt(req.params.id));
    if (!sv) return next();
    const qs = await db.all('SELECT * FROM survey_questions WHERE survey_id = ? ORDER BY sort, id', sv.id);
    const resp = await db.all('SELECT answers, created_at FROM survey_responses WHERE survey_id = ? ORDER BY id', sv.id);
    const rows = [['التاريخ', ...qs.map((q) => q.text)], ...resp.map((x) => { const a = safeJson(x.answers, {}); return [x.created_at, ...qs.map((q) => [].concat(a[q.id] ?? '').join(' | '))]; })];
    res.setHeader('Content-Disposition', `attachment; filename="survey-${sv.id}.csv"`);
    res.send(csv(rows), 'text/csv; charset=utf-8');
  });
  r.get('/admin/export/:what', auth('inbox.manage'), async (req, res, next) => {
    const what = req.params.what.replace(/\.csv$/, '');
    if (what === 'messages') {
      const rows = await db.all('SELECT * FROM messages ORDER BY id DESC');
      res.setHeader('Content-Disposition', 'attachment; filename="messages.csv"');
      return res.send(csv([['التاريخ', 'الاسم', 'البريد', 'الهاتف', 'الموضوع', 'الرسالة', 'الحالة'], ...rows.map((m) => [m.created_at, m.name, m.email, m.phone, m.subject, m.message, m.status])]), 'text/csv; charset=utf-8');
    }
    if (what === 'suggestions') {
      const rows = await db.all('SELECT * FROM suggestions ORDER BY id DESC');
      res.setHeader('Content-Disposition', 'attachment; filename="suggestions.csv"');
      return res.send(csv([['التاريخ', 'الاسم', 'الهاتف', 'الصف', 'النوع', 'النص', 'الحالة'], ...rows.map((m) => [m.created_at, m.name, m.phone, m.student_grade, m.category, m.message, m.status])]), 'text/csv; charset=utf-8');
    }
    return next();
  });

  // ===== الإعدادات =====
  const SETTINGS_GROUPS = [
    { title: 'الهوية العامة', icon: 'home', fields: [
      { name: 'logo', label: 'شعار المدرسة', type: 'image', help: 'صورة مربعة PNG أو JPG أو WEBP (يُفضّل بخلفية شفافة، 512×512). يظهر في الترويسة والتذييل ولوحة التحكم وأيقونة المتصفح. اضغط «إزالة» للعودة إلى الشعار الافتراضي.' },
      { name: 'site_name', label: 'اسم الموقع', required: true }, { name: 'school_name', label: 'اسم المدرسة', required: true }, { name: 'slogan', label: 'الشعار', required: true },
      { name: 'hero_title', label: 'عنوان الواجهة الرئيسية' }, { name: 'hero_subtitle', label: 'النص التعريفي في الواجهة', type: 'textarea', rows: 2 },
      { name: 'hero_image', label: 'صورة الواجهة الرئيسية', type: 'image' }, { name: 'footer_note', label: 'نص الحقوق في التذييل' },
      { name: 'demo_banner', label: 'إظهار شريط «محتوى تجريبي» أعلى الموقع', type: 'checkbox' },
    ] },
    { title: 'عن المدرسة', icon: 'info', fields: [
      { name: 'vision', label: 'الرؤية', type: 'textarea', rows: 2 }, { name: 'mission', label: 'الرسالة', type: 'textarea', rows: 3 },
      { name: 'goals', label: 'الأهداف (هدف في كل سطر)', type: 'textarea', rows: 6 }, { name: 'values', label: 'القيم (سطر لكل قيمة: الاسم|الوصف)', type: 'textarea', rows: 5 },
      { name: 'history', label: 'نبذة عن المدرسة', type: 'markdown', rows: 6 }, { name: 'principal_name', label: 'صاحب الكلمة (مثل: مدير المدرسة)' },
      { name: 'principal_message', label: 'الكلمة', type: 'textarea', rows: 5, max: 4000 },
    ] },
    { title: 'بيانات التواصل', icon: 'phone', fields: [
      { name: 'contact_phone', label: 'الهاتف', dir: 'ltr' }, { name: 'contact_email', label: 'البريد الإلكتروني', dir: 'ltr', validate: (v) => (v && !isEmail(v) ? 'البريد غير صحيح' : null) },
      { name: 'whatsapp', label: 'رقم واتساب (بالصيغة الدولية مثل 968XXXXXXXX)', dir: 'ltr' }, { name: 'contact_address', label: 'العنوان' }, { name: 'contact_hours', label: 'ساعات العمل' },
      { name: 'map_embed', label: 'رابط تضمين خرائط Google (يبدأ بـ https://www.google.com/maps/embed)', dir: 'ltr', max: 1500, validate: (v) => (v && !/^https:\/\/(www\.)?google\.com\/maps\/embed/.test(v) ? 'رابط التضمين غير صالح' : null) },
      { name: 'social_x', label: 'حساب X', dir: 'ltr' }, { name: 'social_instagram', label: 'إنستغرام', dir: 'ltr' }, { name: 'social_youtube', label: 'يوتيوب', dir: 'ltr' }, { name: 'social_facebook', label: 'فيسبوك', dir: 'ltr' },
    ] },
    { title: 'تحسين محركات البحث', icon: 'search', fields: [
      { name: 'site_description', label: 'وصف الموقع', type: 'textarea', rows: 3, max: 300 }, { name: 'seo_keywords', label: 'الكلمات المفتاحية' },
      { name: 'og_image', label: 'صورة المشاركة الاجتماعية (PNG/JPG 1200×630)', type: 'image' },
    ] },
  ];
  const settingFields = SETTINGS_GROUPS.flatMap((g) => g.fields);
  for (const f of settingFields) if (/^social_/.test(f.name)) f.validate = (v) => (v && !/^https:\/\//.test(v) ? 'يجب أن يبدأ الرابط بـ https://' : null);

  r.get('/admin/settings', auth('settings.manage'), async (req, res) => {
    const s = await db.settings();
    const groups = [];
    for (const g of SETTINGS_GROUPS) groups.push(html`<section class="panel form-grid" id="g-${g.icon}"><h2 class="wide">${raw(icon(g.icon, 'sm'))} ${g.title}</h2>${raw((await Promise.all(g.fields.map((f) => renderField(f, s[f.name])))).join(''))}</section>`);
    const body = html`<form method="post" action="/admin/settings" enctype="multipart/form-data" data-dirty>${csrfInput(req)}
      ${groups}<div class="sticky-save"><button class="btn btn-gold">${raw(icon('check', 'sm'))} حفظ الإعدادات</button></div></form>
      <section class="panel danger-zone"><h2>${raw(icon('alert', 'sm'))} المحتوى التجريبي</h2><p>يحذف كل العناصر المعلَّمة «تجريبي» (الأخبار، الفعاليات، الصور، الجداول، الإدارة المدرسية، الإحصائيات، الاستبانة التجريبية…). المحتوى الذي عدّلته أو أنشأته لن يتأثر.</p>
        <form method="post" action="/admin/demo/remove" data-confirm="حذف كل المحتوى التجريبي نهائيًا؟">${csrfInput(req)}<button class="btn btn-danger">${raw(icon('trash', 'sm'))} حذف المحتوى التجريبي</button></form></section>
      <section class="panel"><h2>${raw(icon('info', 'sm'))} معلومات النظام</h2><dl class="sys"><dt>قاعدة البيانات</dt><dd>${db.engine() === 'turso' ? 'Turso (سحابية)' : 'SQLite محلية'}</dd><dt>الحد الأقصى للرفع</dt><dd>${config.maxUploadMb} م.ب</dd><dt>رابط الموقع</dt><dd dir="ltr">${config.siteUrl}</dd><dt>إصدار Node.js</dt><dd dir="ltr">${process.version}</dd></dl></section>`;
    await page(req, res, 'إعدادات الموقع', body);
  });

  r.post('/admin/settings', auth('settings.manage'), async (req, res) => {
    const data = await readFields(settingFields, req);
    for (const [k, v] of Object.entries(data)) await db.setSetting(k, v == null ? '' : v);
    db.clearSettingsCache();
    await db.audit(req, 'update', 'settings', null, { keys: Object.keys(data).length });
    flash(res, 'تم حفظ الإعدادات');
    res.redirect('/admin/settings');
  });

  r.post('/admin/demo/remove', auth('settings.manage'), async (req, res) => {
    const counts = await removeDemo();
    await db.audit(req, 'remove_demo', 'settings', null, counts);
    flash(res, 'تم حذف المحتوى التجريبي: ' + Object.values(counts).reduce((a, b) => a + b, 0) + ' عنصر');
    res.redirect('/admin');
  });

  // ===== سجل العمليات =====
  r.get('/admin/logs', auth('logs.view'), async (req, res) => {
    const where = ['1=1'], args = [];
    if (req.query.action) { where.push('action = ?'); args.push(String(req.query.action)); }
    if (req.query.user) { where.push('user_id = ?'); args.push(toInt(req.query.user)); }
    if (req.query.q) { where.push('(entity LIKE ? OR details LIKE ?)'); args.push('%' + req.query.q + '%', '%' + req.query.q + '%'); }
    const pg = Math.max(1, toInt(req.query.page, 1));
    const total = (await db.get(`SELECT COUNT(*) n FROM audit_log WHERE ${where.join(' AND ')}`, ...args)).n;
    const rows = await db.all(`SELECT * FROM audit_log WHERE ${where.join(' AND ')} ORDER BY id DESC LIMIT 50 OFFSET ?`, ...args, (pg - 1) * 50);
    const actions = (await db.all('SELECT DISTINCT action FROM audit_log ORDER BY action')).map((a) => a.action);
    const users = await db.all('SELECT id, name FROM users ORDER BY name');
    const qs = (o) => '/admin/logs?' + new URLSearchParams(Object.fromEntries(Object.entries({ ...req.query, page: '', ...o }).filter(([, v]) => v))).toString();
    const body = html`<form class="toolbar tb-search" method="get">
      <select name="action"><option value="">كل العمليات</option>${actions.map((a) => html`<option value="${a}" ${req.query.action === a ? raw('selected') : ''}>${ACTIONS[a] || a}</option>`)}</select>
      <select name="user"><option value="">كل المستخدمين</option>${users.map((u) => html`<option value="${u.id}" ${String(req.query.user) === String(u.id) ? raw('selected') : ''}>${u.name}</option>`)}</select>
      <input type="search" name="q" value="${req.query.q || ''}" placeholder="بحث في التفاصيل"><button class="btn btn-navy sm">تصفية</button></form>
      <div class="panel flush">${logTable(rows)}</div>${pager(pg, Math.ceil(total / 50), qs)}`;
    await page(req, res, 'سجل العمليات', body);
  });
};

const ACTIONS = { login: 'تسجيل دخول', login_failed: 'محاولة دخول فاشلة', logout: 'تسجيل خروج', create: 'إنشاء', update: 'تعديل', delete: 'حذف', restore: 'استعادة نسخة', upload: 'رفع ملف', password_change: 'تغيير كلمة المرور', remove_demo: 'حذف المحتوى التجريبي', bulk_publish: 'نشر جماعي', bulk_draft: 'تحويل جماعي لمسودة', bulk_archive: 'أرشفة جماعية', bulk_delete: 'حذف جماعي' };

function logTable(rows) {
  if (!rows.length) return html`<p class="muted pad">لا توجد عمليات مسجلة.</p>`;
  return html`<div class="table-wrap"><table class="list"><thead><tr><th>الوقت</th><th>المستخدم</th><th>العملية</th><th>العنصر</th><th>التفاصيل</th><th>IP</th></tr></thead><tbody>
    ${rows.map((l) => { const d = safeJson(l.details, {}); return html`<tr class="${l.action === 'login_failed' ? 'warn-row' : ''}"><td class="nowrap">${fmtUtcDT(l.created_at)}</td><td>${l.user_name || '—'}</td><td><span class="pill ${/delete|failed/.test(l.action) ? 'red' : /create|upload/.test(l.action) ? 'green' : 'navy'}">${ACTIONS[l.action] || l.action}</span></td>
      <td>${l.entity || ''}${l.entity_id ? ' #' + l.entity_id : ''}</td><td class="small">${d.title || d.email || d.name || (d.count ? d.count + ' ملف' : '') || (d.status ? d.status : '')}</td><td dir="ltr" class="small muted">${l.ip || ''}</td></tr>`; })}
  </tbody></table></div>`;
}

function pager(pg, pages, qs) {
  if (pages <= 1) return '';
  return html`<nav class="pager" aria-label="الصفحات">${pg > 1 ? html`<a href="${qs({ page: pg - 1 })}">السابق</a>` : ''}<span>صفحة ${pg} من ${pages}</span>${pg < pages ? html`<a href="${qs({ page: pg + 1 })}">التالي</a>` : ''}</nav>`;
}
