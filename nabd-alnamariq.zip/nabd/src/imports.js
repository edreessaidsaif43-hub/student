'use strict';
// استيراد لمرة واحدة لمنشورات حساب المدرسة الرسمي على منصة X (@EduGovNBT2362)
// كل دفعة تُنفَّذ مرة واحدة فقط (مفتاح في جدول الإعدادات)، ثم تصبح أخبارًا عادية قابلة للتعديل من لوحة التحكم.
const db = require('./db');
const { slugify } = require('./core/util');

const X = 'https://x.com/EduGovNBT2362/status/';
const img = (id) => `https://pbs.twimg.com/media/${id}?format=jpg&name=large`;
const vthumb = (p) => `https://pbs.twimg.com/amplify_video_thumb/${p}?format=jpg&name=large`;
const TAGS = 'فعاليات تعليمية شمال الباطنة، تعلم مستدام';

const BATCHES = {
  import_x_2026_11_18: {
    posts: [
      {
        id: '2122890109511229553', at: '2026-11-18 03:10:18', category: 'مجتمعي', featured: 1,
        title: 'معًا نصنع الأثر.. اللقاء التربوي الأول بين أولياء الأمور والهيئة التعليمية',
        excerpt: 'تعزيزًا للشراكة بين الأسرة والمدرسة، نلتقي لنتحاور ونتشارك الأفكار من أجل مستقبل تعليمي أفضل لأبنائنا الطلبة.',
        cover: img('HXYFPX0aQAALzeF'), video: true,
        body: 'معًا نصنع الأثر..\n\nاللقاء التربوي الأول بين أولياء الأمور والهيئة التعليمية.\n\nتعزيزاً للشراكة بين الأسرة والمدرسة، نلتقي لنتحاور ونتشارك الأفكار من أجل مستقبل تعليمي أفضل لأبنائنا الطلبة.',
      },
      {
        id: '2122423061861564478', at: '2026-11-16 20:14:25', category: 'تقني',
        title: 'ورشة تدريبية لمعلمات المدرسة في برنامج Microsoft Viva Engage',
        excerpt: 'ضمن خطة الإنماء المهني، نفذت المعلمة الأولى للمجال الأول الأستاذة هدى السعدي ورشة لإنشاء مجتمعات تعلم مهنية إلكترونية.',
        cover: img('HXRchYRbEAEEPPP'), extra: [img('HXRchYQbEAAbrxm')],
        body: 'ضمن خطة الإنماء لمعلمات المدرسة نفذت المعلمة الأولى للمجال الأول الأستاذة هدى السعدي ورشة تدريبية في برنامج (Microsoft Viva Engage) لإنشاء مجتمعات تعلم مهنية الكترونية.',
      },
      {
        id: '2122384465985163636', at: '2026-11-16 17:41:03', category: 'ثقافي',
        title: 'نوفمبر حكاية فخر وانتماء.. طلبة الصفين الثاني والثالث يجسّدون حب الوطن',
        excerpt: 'جسّد طلبة الصفين الثاني والثالث بإبداع حب الوطن في كلمات ومشاهد تنبض بالفخر والاعتزاز، بإشراف الأستاذة تهاني الصالحي.',
        cover: vthumb('2122384364785037313/img/LfdoJWxtwM8EeQMe'), video: true,
        body: 'نوفمبر حكاية فخرٍ وانتماء، تتجدد فيه مشاعر الحب والولاء للوطن الغالي سلطنة عُمان، جسّد طلبة ثاني ثالث بإبداع حب الوطن في كلمات ومشاهد تنبض بالفخر والاعتزاز، لتبقى عُمان في قلوبنا دائماً وأبداً.\n\n**بإشراف الأستاذة:** تهاني الصالحي',
      },
      {
        id: '1982894339052491178', at: '2025-10-27 19:37:05', category: 'إداري', year: '2025/2026',
        title: 'المجتمع المدرسي شريك في بناء رؤية المدرسة ورسالتها',
        excerpt: 'لتحقيق معيار قيادة التغيير نشارك الجميع في المجتمع المدرسي في بناء وتنفيذ رؤيتنا ورسالتنا.',
        cover: img('G4Sn5FxXoAAPq7a'),
        body: 'لتحقيق معيار قيادة التغيير نشارك الجميع في المجتمع المدرسي في بناء وتنفيذ رؤيتنا ورسالتنا.',
      },
    ],
    // تُضاف فقط إذا كانت الحقول فارغة، حتى لا تُستبدل أي قيمة أدخلها المسؤول
    settings: { social_x: 'https://x.com/EduGovNBT2362', contact_phone: '22495067' },
    settingsReplace: { contact_address: ['سلطنة عُمان', 'السويق، محافظة شمال الباطنة، سلطنة عُمان'] },
  },
};

async function runImports() {
  for (const [key, batch] of Object.entries(BATCHES)) {
    const lock = await db.run("INSERT OR IGNORE INTO settings(key, value) VALUES (?, '1')", key);
    if (!lock.changes) continue;
    const years = await db.all('SELECT id, name FROM academic_years');
    const cur = (await db.currentYear())?.id || null;
    for (const p of batch.posts) {
      const url = X + p.id;
      if (await db.get('SELECT id FROM posts WHERE body LIKE ?', '%' + url + '%')) continue;
      let body = p.body;
      for (const e of p.extra || []) body += `\n\n![صورة من الفعالية](${e})`;
      body += `\n\n---\n\n${p.video ? 'يتضمن المنشور الأصلي مقطع فيديو. ' : ''}المصدر: [منشور المدرسة على منصة X](${url})`;
      let slug = slugify(p.title), n = 1;
      while (await db.get("SELECT id FROM posts WHERE type = 'news' AND slug = ?", slug)) slug = slugify(p.title) + '-' + ++n;
      const row = {
        type: 'news', title: p.title, slug, excerpt: p.excerpt, body, cover: p.cover, cover_alt: p.title, category: p.category, tags: TAGS,
        status: 'published', featured: p.featured || 0, academic_year_id: (p.year && (years.find((y) => y.name === p.year) || {}).id) || cur,
        published_at: p.at, created_at: p.at, updated_at: p.at, is_demo: 0,
      };
      row.search_text = db.postSearchText(row);
      await db.insert('posts', row);
      // صور المنشور في المعرض الإعلامي
      for (const [i, src] of [p.cover, ...(p.extra || [])].entries()) {
        await db.insert('gallery', { kind: 'image', title: p.title + (i ? ` (${i + 1})` : ''), album: 'من حساب المدرسة على X', file: src, academic_year_id: row.academic_year_id, sort: 0 });
      }
    }
    const s = await db.settings();
    for (const [k, v] of Object.entries(batch.settings || {})) if (!s[k]) await db.setSetting(k, v);
    for (const [k, [from, to]] of Object.entries(batch.settingsReplace || {})) if (!s[k] || s[k] === from) await db.setSetting(k, to);
    await db.run("INSERT INTO audit_log(action, entity, details) VALUES ('import', 'x', ?)", JSON.stringify({ batch: key, posts: batch.posts.length }));
  }
}

module.exports = { runImports, BATCHES };
