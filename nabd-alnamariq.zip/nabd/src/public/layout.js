'use strict';
// القالب العام للواجهة الأمامية
const db = require('../db');
const config = require('../config');
const { html, raw, esc, fmtUtc, excerpt } = require('../core/util');
const { icon } = require('../core/icons');
const { TYPES } = require('../content-types');

const NAV = [
  { href: '/', label: 'الرئيسية' },
  { href: '/about', label: 'عن المدرسة' },
  { label: 'المركز الإعلامي', children: [
    { href: '/news', label: 'الأخبار والإعلانات', icon: 'news', desc: 'آخر أخبار المدرسة وإعلاناتها' },
    { href: '/events', label: 'الفعاليات والأنشطة', icon: 'calendar', desc: 'الفعاليات القادمة والسابقة' },
    { href: '/media', label: 'المعرض الإعلامي', icon: 'image', desc: 'صور ومقاطع من حياة المدرسة' },
  ] },
  { label: 'التعلم والتميز', children: [
    { href: '/initiatives', label: 'المبادرات والمشاريع', icon: 'spark', desc: 'مبادرات ومشاريع تعليمية' },
    { href: '/library', label: 'المكتبة التعليمية', icon: 'book', desc: 'أوراق عمل وملخصات ومصادر' },
    { href: '/achievements', label: 'الإنجازات والتكريم', icon: 'trophy', desc: 'إنجازات الطلبة والمعلمين' },
  ] },
  { label: 'الخدمات', children: [
    { href: '/schedules', label: 'الجداول المدرسية', icon: 'table', desc: 'جداول الحصص والاختبارات' },
    { href: '/calendar', label: 'التقويم المدرسي', icon: 'calendar', desc: 'المواعيد والإجازات والاختبارات' },
    { href: '/parents', label: 'ركن ولي الأمر', icon: 'family', desc: 'أدلة واستبانات ومقترحات' },
    { href: '/archive', label: 'الأرشيف', icon: 'archive', desc: 'المحتوى حسب العام الدراسي' },
  ] },
  { href: '/partnerships', label: 'الشراكة المجتمعية' },
  { href: '/contact', label: 'تواصل معنا' },
];

function isActive(req, href) {
  if (href === '/') return req.path === '/';
  return req.path === href || req.path.startsWith(href + '/');
}

function navHtml(req) {
  return NAV.map((item) => {
    if (!item.children) return html`<li><a href="${item.href}" class="${isActive(req, item.href) ? 'active' : ''}" ${isActive(req, item.href) ? raw('aria-current="page"') : ''}>${item.label}</a></li>`;
    const act = item.children.some((c) => isActive(req, c.href));
    return html`<li class="has-menu">
      <button type="button" class="menu-btn ${act ? 'active' : ''}" aria-expanded="false">${item.label} ${raw(icon('chevronDown', 'sm'))}</button>
      <div class="mega" role="menu">${item.children.map((c) => html`<a role="menuitem" href="${c.href}" class="${isActive(req, c.href) ? 'active' : ''}"><span class="mi">${raw(icon(c.icon))}</span><span><b>${c.label}</b><small>${c.desc}</small></span></a>`)}</div>
    </li>`;
  });
}

async function chrome() {
  const s = await db.settings();
  const now = new Date().toISOString().slice(0, 19).replace('T', ' ');
  const alerts = await db.all(`SELECT id, message, link, level FROM alerts WHERE active = 1 AND (starts_at IS NULL OR starts_at <= ?) AND (ends_at IS NULL OR ends_at >= ?) ORDER BY id DESC LIMIT 3`, now, now);
  const notes = await db.all(`SELECT id, type, title, slug, published_at FROM posts WHERE type IN ('announcement','news','event') AND status = 'published' AND published_at <= ? ORDER BY published_at DESC LIMIT 6`, now);
  return { s, alerts, notes };
}

async function layout(req, { title, description, image, body, canonical, jsonld, noindex, bodyClass = '' }) {
  const { s, alerts, notes } = await chrome();
  const siteName = s.site_name || 'نبض النمارق';
  const fullTitle = title ? `${title} | ${siteName}` : `${siteName} — ${s.slogan || ''}`;
  const desc = description || s.site_description || '';
  const url = config.siteUrl + (canonical || req.path);
  const img = (image && !image.endsWith('.svg') ? image : s.og_image || '/img/og-image.png');
  const ogImg = /^https?:/.test(img) ? img : config.siteUrl + img;
  const ld = jsonld || {
    '@context': 'https://schema.org', '@type': 'School', name: s.school_name, alternateName: siteName, url: config.siteUrl,
    logo: config.siteUrl + '/img/logo.svg', slogan: s.slogan, address: { '@type': 'PostalAddress', addressCountry: 'OM', streetAddress: s.contact_address || undefined },
    email: s.contact_email || undefined, telephone: s.contact_phone || undefined,
  };
  const social = [['social_x', 'x_social', 'منصة X'], ['social_instagram', 'instagram', 'إنستغرام'], ['social_youtube', 'youtube', 'يوتيوب'], ['social_facebook', 'facebook', 'فيسبوك']].filter(([k]) => s[k]);

  return '<!DOCTYPE html>' + html`<html lang="ar" dir="rtl">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>${fullTitle}</title>
<meta name="description" content="${excerpt(desc, 300)}">
${s.seo_keywords ? html`<meta name="keywords" content="${s.seo_keywords}">` : ''}
${noindex ? raw('<meta name="robots" content="noindex">') : ''}
<link rel="canonical" href="${url}">
<meta name="theme-color" content="#0B1F3A">
<meta property="og:type" content="website">
<meta property="og:locale" content="ar_OM">
<meta property="og:site_name" content="${siteName}">
<meta property="og:title" content="${title || siteName}">
<meta property="og:description" content="${excerpt(desc, 200)}">
<meta property="og:url" content="${url}">
<meta property="og:image" content="${ogImg}">
<meta name="twitter:card" content="summary_large_image">
<link rel="icon" href="/img/favicon.svg" type="image/svg+xml">
<link rel="manifest" href="/manifest.webmanifest">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;500;600;700;800&family=Tajawal:wght@400;500;700&display=swap">
<link rel="stylesheet" href="/css/site.css?v=${ASSET_V}">
<link rel="alternate" type="application/rss+xml" title="${siteName}" href="/feed.xml">
<script type="application/ld+json">${raw(JSON.stringify(ld).replace(/</g, '\\u003c'))}</script>
<script src="/js/site.js?v=${ASSET_V}" defer></script>
</head>
<body class="${bodyClass}">
<a class="skip" href="#main">تخطَّ إلى المحتوى الرئيسي</a>
${s.demo_banner === '1' ? html`<div class="demo-strip" role="note">${raw(icon('info', 'sm'))} يعرض الموقع حاليًا <b>محتوى تجريبيًا</b> لأغراض العرض، والعناصر التجريبية مُعلَّمة بشارة «تجريبي». يمكن حذفها بنقرة من لوحة التحكم.</div>` : ''}
${alerts.map((a) => html`<div class="alert-bar lvl-${a.level}" data-alert="${a.id}" hidden>
  <div class="wrap">${raw(icon(a.level === 'warning' ? 'alert' : 'bell', 'sm'))}<p>${a.message}${a.link ? html` <a href="${a.link}">التفاصيل</a>` : ''}</p>
  <button type="button" class="alert-close" aria-label="إخفاء التنبيه">${raw(icon('x', 'sm'))}</button></div></div>`)}
<header class="site-header" id="top">
  <div class="wrap hdr">
    <a href="/" class="brand" aria-label="${siteName} — الصفحة الرئيسية">
      <img src="/img/logo.svg" alt="" width="48" height="48">
      <span><b>${siteName}</b><small>${s.school_name}</small></span>
    </a>
    <nav class="main-nav" id="main-nav" aria-label="القائمة الرئيسية"><ul>${navHtml(req)}</ul></nav>
    <div class="hdr-tools">
      <button type="button" class="tool-btn" data-open="search" aria-label="بحث">${raw(icon('search'))}</button>
      <div class="notif">
        <button type="button" class="tool-btn" id="notif-btn" aria-label="الإشعارات" aria-expanded="false" data-latest="${notes[0] ? notes[0].published_at : ''}">${raw(icon('bell'))}<span class="dot" hidden></span></button>
        <div class="notif-panel" id="notif-panel" hidden>
          <div class="np-head"><b>آخر الإشعارات</b><a href="/news?kind=announcement">كل الإعلانات</a></div>
          ${notes.length ? notes.map((n) => html`<a class="np-item" href="${TYPES[n.type].path}/${encodeURIComponent(n.slug)}" data-time="${n.published_at}"><span class="np-ic">${raw(icon(TYPES[n.type].icon, 'sm'))}</span><span><b>${n.title}</b><small>${TYPES[n.type].single} · ${fmtUtc(n.published_at)}</small></span></a>`) : html`<p class="muted pad">لا توجد إشعارات حاليًا.</p>`}
        </div>
      </div>
      <button type="button" class="tool-btn" id="a11y-btn" aria-label="تكبير الخط">${raw(icon('textSize'))}</button>
      <button type="button" class="tool-btn burger" aria-label="فتح القائمة" aria-controls="main-nav" aria-expanded="false">${raw(icon('menu'))}</button>
    </div>
  </div>
</header>
<div class="search-overlay" id="search-overlay" hidden>
  <form class="search-box" action="/search" method="get" role="search">
    <label for="sq" class="sr">ابحث في الموقع</label>
    ${raw(icon('search'))}<input id="sq" name="q" type="search" placeholder="ابحث في الأخبار، الفعاليات، المكتبة، الجداول…" autocomplete="off" required minlength="2">
    <button class="btn btn-gold" type="submit">بحث</button>
    <button type="button" class="tool-btn" data-close="search" aria-label="إغلاق">${raw(icon('x'))}</button>
  </form>
</div>
<main id="main" tabindex="-1">${raw(String(body))}</main>
<footer class="site-footer">
  <div class="ft-pattern" aria-hidden="true"></div>
  <div class="wrap ft-grid">
    <div class="ft-about">
      <a href="/" class="brand light"><img src="/img/logo.svg" alt="" width="52" height="52"><span><b>${siteName}</b><small>${s.school_name}</small></span></a>
      <p class="ft-slogan">«${s.slogan}»</p>
      ${social.length ? html`<div class="social">${social.map(([k, ic, lbl]) => html`<a href="${s[k]}" target="_blank" rel="noopener" aria-label="${lbl}">${raw(icon(ic))}</a>`)}</div>` : ''}
    </div>
    <div><h3>المدرسة</h3><ul><li><a href="/about">عن المدرسة</a></li><li><a href="/news">الأخبار والإعلانات</a></li><li><a href="/events">الفعاليات والأنشطة</a></li><li><a href="/achievements">الإنجازات والتكريم</a></li><li><a href="/media">المعرض الإعلامي</a></li></ul></div>
    <div><h3>خدمات</h3><ul><li><a href="/schedules">الجداول المدرسية</a></li><li><a href="/calendar">التقويم المدرسي</a></li><li><a href="/library">المكتبة التعليمية</a></li><li><a href="/parents">ركن ولي الأمر</a></li><li><a href="/archive">الأرشيف</a></li></ul></div>
    <div><h3>تواصل معنا</h3><ul class="ft-contact">
      ${s.contact_address ? html`<li>${raw(icon('pin', 'sm'))}<span>${s.contact_address}</span></li>` : ''}
      ${s.contact_phone ? html`<li>${raw(icon('phone', 'sm'))}<a href="tel:${s.contact_phone.replace(/\s/g, '')}" dir="ltr">${s.contact_phone}</a></li>` : ''}
      ${s.contact_email ? html`<li>${raw(icon('mail', 'sm'))}<a href="mailto:${s.contact_email}">${s.contact_email}</a></li>` : ''}
      ${s.contact_hours ? html`<li>${raw(icon('clock', 'sm'))}<span>${s.contact_hours}</span></li>` : ''}
      <li>${raw(icon('mail', 'sm'))}<a href="/contact">نموذج التواصل</a></li>
    </ul></div>
  </div>
  <div class="wrap ft-bottom"><span>© ${new Date().getFullYear()} ${s.footer_note}</span><span><a href="/sitemap.xml">خريطة الموقع</a> · <a href="/feed.xml">RSS</a> · <a href="/admin">دخول الإدارة</a></span></div>
</footer>
<button type="button" class="to-top" aria-label="العودة للأعلى" hidden>${raw(icon('chevronDown'))}</button>
<div class="lightbox" id="lightbox" hidden role="dialog" aria-modal="true" aria-label="عارض الصور">
  <button type="button" class="lb-close" aria-label="إغلاق">${raw(icon('x'))}</button>
  <button type="button" class="lb-prev" aria-label="السابق">${raw(icon('chevron'))}</button>
  <figure><div class="lb-media"></div><figcaption></figcaption></figure>
  <button type="button" class="lb-next" aria-label="التالي">${raw(icon('chevron'))}</button>
</div>
</body></html>`;
}

const ASSET_V = '1';

module.exports = { layout, NAV };
