'use strict';
// مكونات واجهة مشتركة
const { html, raw, fmtUtc, fmtDate, toDate } = require('../core/util');
const { icon } = require('../core/icons');
const { TYPES } = require('../content-types');
const config = require('../config');

const demoBadge = (item) => (item && item.is_demo ? html`<span class="badge demo" title="محتوى تجريبي يمكن حذفه من لوحة التحكم">تجريبي</span>` : '');
const postUrl = (p) => `${TYPES[p.type].path}/${encodeURIComponent(p.slug)}`;

function pageHero(title, { sub, crumbs = [], icon: ic } = {}) {
  return html`<section class="page-hero">
    <div class="wrap">
      <nav class="crumbs" aria-label="مسار التنقل"><ol><li><a href="/">الرئيسية</a></li>${crumbs.map((c) => html`<li>${c.href ? html`<a href="${c.href}">${c.label}</a>` : html`<span aria-current="page">${c.label}</span>`}</li>`)}</ol></nav>
      <h1>${ic ? raw(icon(ic, 'h1-ic')) : ''}${title}</h1>
      ${sub ? html`<p>${sub}</p>` : ''}
    </div>
  </section>`;
}

function dateChip(v) {
  const d = toDate(v);
  if (!d) return '';
  const day = new Intl.DateTimeFormat('ar-OM-u-nu-latn', { day: 'numeric', timeZone: 'Asia/Muscat' }).format(d);
  const mon = new Intl.DateTimeFormat('ar-OM', { month: 'short', timeZone: 'Asia/Muscat' }).format(d);
  return html`<span class="date-chip"><b>${day}</b><small>${mon}</small></span>`;
}

function card(p, { size = '' } = {}) {
  const t = TYPES[p.type];
  const isEvent = p.type === 'event';
  return html`<article class="card ${size} reveal">
    <a class="card-media" href="${postUrl(p)}" tabindex="-1" aria-hidden="true">
      ${p.cover ? html`<img src="${p.cover}" alt="" loading="lazy" width="600" height="375">` : html`<span class="ph">${raw(icon(t.icon))}</span>`}
      ${isEvent && p.event_start ? dateChip(p.event_start) : ''}
    </a>
    <div class="card-body">
      <div class="meta">${p.category ? html`<span class="tag">${p.category}</span>` : html`<span class="tag">${t.single}</span>`}${demoBadge(p)}${p.pinned ? html`<span class="badge gold">مثبّت</span>` : ''}</div>
      <h3><a href="${postUrl(p)}">${p.title}</a></h3>
      ${p.excerpt ? html`<p>${p.excerpt}</p>` : ''}
      <div class="card-foot">
        ${isEvent && p.event_start ? html`<span>${raw(icon('calendar', 'sm'))}${fmtDate(p.event_start, { dateStyle: 'medium' })}</span>${p.location ? html`<span>${raw(icon('pin', 'sm'))}${p.location}</span>` : ''}`
          : html`<span>${raw(icon('clock', 'sm'))}${fmtUtc(p.published_at)}</span>`}
        ${p.attachment ? html`<span>${raw(icon('file', 'sm'))}مرفق</span>` : ''}
      </div>
    </div>
  </article>`;
}

function pagination(req, page, pages) {
  if (pages <= 1) return '';
  const q = { ...req.query };
  const link = (n) => { q.page = n; return req.path + '?' + new URLSearchParams(q).toString(); };
  const items = [];
  for (let i = 1; i <= pages; i++) {
    if (i === 1 || i === pages || Math.abs(i - page) <= 1) items.push(i);
    else if (items[items.length - 1] !== '…') items.push('…');
  }
  return html`<nav class="pager" aria-label="ترقيم الصفحات">
    ${page > 1 ? html`<a href="${link(page - 1)}" rel="prev">السابق</a>` : ''}
    ${items.map((i) => (i === '…' ? html`<span>…</span>` : i === page ? html`<span class="cur" aria-current="page">${i}</span>` : html`<a href="${link(i)}">${i}</a>`))}
    ${page < pages ? html`<a href="${link(page + 1)}" rel="next">التالي</a>` : ''}
  </nav>`;
}

function shareBar(title, path) {
  const url = config.siteUrl + path;
  const wa = 'https://wa.me/?text=' + encodeURIComponent(title + '\n' + url);
  return html`<div class="share">
    <span>${raw(icon('share', 'sm'))} شارك:</span>
    <a class="btn btn-wa" href="${wa}" target="_blank" rel="noopener">${raw(icon('whatsapp', 'sm'))} واتساب</a>
    <button type="button" class="btn btn-ghost" data-copy="${url}">${raw(icon('copy', 'sm'))} نسخ الرابط</button>
    <button type="button" class="btn btn-ghost" data-print>${raw(icon('print', 'sm'))} طباعة</button>
  </div>`;
}

function empty(msg = 'لا يوجد محتوى منشور في هذا القسم حاليًا.') {
  return html`<div class="empty">${raw(icon('folder'))}<p>${msg}</p></div>`;
}

function filterBar(req, { categories = [], years = [], extra = '' } = {}) {
  const q = req.query;
  return html`<form class="filters" method="get" action="${req.path}">
    ${Object.entries(q).filter(([k]) => ['kind', 'tab'].includes(k)).map(([k, v]) => html`<input type="hidden" name="${k}" value="${v}">`)}
    <label class="f-search">${raw(icon('search', 'sm'))}<span class="sr">بحث</span><input type="search" name="q" value="${q.q || ''}" placeholder="ابحث في هذا القسم…"></label>
    ${categories.length ? html`<label><span class="sr">التصنيف</span><select name="category"><option value="">كل التصنيفات</option>${categories.map((c) => html`<option ${q.category === c ? raw('selected') : ''}>${c}</option>`)}</select></label>` : ''}
    ${years.length ? html`<label><span class="sr">العام الدراسي</span><select name="year"><option value="">كل الأعوام</option>${years.map((y) => html`<option value="${y.id}" ${String(q.year) === String(y.id) ? raw('selected') : ''}>${y.name}</option>`)}</select></label>` : ''}
    ${raw(extra)}
    <button class="btn btn-navy" type="submit">تصفية</button>
    ${(q.q || q.category || q.year) ? html`<a class="btn btn-ghost" href="${req.path}${q.kind ? '?kind=' + q.kind : q.tab ? '?tab=' + q.tab : ''}">مسح</a>` : ''}
  </form>`;
}

function sectionHead(title, { sub, href, more = 'عرض الكل', ic } = {}) {
  return html`<div class="sec-head reveal"><div><span class="eyebrow">${ic ? raw(icon(ic, 'sm')) : ''}${sub || ''}</span><h2>${title}</h2></div>${href ? html`<a class="more" href="${href}">${more} ${raw(icon('arrow', 'sm'))}</a>` : ''}</div>`;
}

module.exports = { demoBadge, postUrl, pageHero, card, pagination, shareBar, empty, filterBar, sectionHead, dateChip };
