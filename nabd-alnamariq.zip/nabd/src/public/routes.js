'use strict';
// مسارات الواجهة الأمامية
const db = require('../db');
const config = require('../config');
const { html, raw, esc, markdown, fmtDate, fmtDay, fmtUtc, fmtNum, toInt, clampStr, isEmail, normalizeAr, safeJson, youtubeEmbed, toDate, excerpt, lines } = require('../core/util');
const { icon } = require('../core/icons');
const { HttpError } = require('../core/http');
const { formToken, checkFormToken, rateLimit, ipHash } = require('../core/security');
const { TYPES, CALENDAR_KINDS, SCHEDULE_KINDS, GRADES, DAYS } = require('../content-types');
const { layout } = require('./layout');
const C = require('./components');

const PUB = "status = 'published' AND published_at <= datetime('now')";
const PER_PAGE = 9;

const years = () => db.all('SELECT id, name FROM academic_years ORDER BY name DESC');

function formExtras() {
  return html`<input type="hidden" name="_ft" value="${formToken()}"><div class="hp" aria-hidden="true"><label>اترك هذا الحقل فارغًا<input name="website" tabindex="-1" autocomplete="off"></label></div>`;
}

// ===== الاستعلام العام للمحتوى =====
async function listPosts(req, types, { order = 'p.pinned DESC, p.published_at DESC', extraWhere = '', extraArgs = [] } = {}) {
  const where = [`p.type IN (${types.map(() => '?').join(',')})`, PUBP];
  const args = [...types];
  const q = req.query;
  if (q.q) { where.push('p.search_text LIKE ?'); args.push('%' + normalizeAr(q.q) + '%'); }
  if (q.category) { where.push('p.category = ?'); args.push(String(q.category)); }
  if (q.year) { where.push('p.academic_year_id = ?'); args.push(toInt(q.year)); }
  if (extraWhere) { where.push(extraWhere); args.push(...extraArgs); }
  const page = Math.max(1, toInt(q.page, 1));
  const total = (await db.get(`SELECT COUNT(*) n FROM posts p WHERE ${where.join(' AND ')}`, ...args)).n;
  const items = await db.all(`SELECT p.* FROM posts p WHERE ${where.join(' AND ')} ORDER BY ${order} LIMIT ? OFFSET ?`, ...args, PER_PAGE, (page - 1) * PER_PAGE);
  return { items, total, page, pages: Math.ceil(total / PER_PAGE) };
}

const PUBP = "p.status = 'published' AND p.published_at <= datetime('now')";
async function getPost(types, slug) {
  return db.get(`SELECT p.*, y.name year_name, u.name author_name FROM posts p LEFT JOIN academic_years y ON y.id = p.academic_year_id LEFT JOIN users u ON u.id = p.author_id
    WHERE p.type IN (${types.map(() => '?').join(',')}) AND p.slug = ? AND ${PUBP}`, ...types, slug);
}

module.exports = function register(r) {
  // ===== الرئيسية =====
  r.get('/', async (req, res) => {
    const s = await db.settings();
    const [featured, latest, announcements, upcoming, initiatives, achievements, gallery, stats, nextEvent] = await Promise.all([
      db.all(`SELECT * FROM posts WHERE type = 'news' AND featured = 1 AND ${PUB} ORDER BY published_at DESC LIMIT 1`),
      db.all(`SELECT * FROM posts WHERE type = 'news' AND ${PUB} ORDER BY published_at DESC LIMIT 5`),
      db.all(`SELECT * FROM posts WHERE type = 'announcement' AND ${PUB} ORDER BY pinned DESC, published_at DESC LIMIT 4`),
      db.all(`SELECT * FROM posts WHERE type = 'event' AND ${PUB} AND COALESCE(event_end, event_start) >= ? ORDER BY event_start ASC LIMIT 3`, localNow()),
      db.all(`SELECT * FROM posts WHERE type = 'initiative' AND ${PUB} ORDER BY featured DESC, published_at DESC LIMIT 3`),
      db.all(`SELECT * FROM posts WHERE type = 'achievement' AND ${PUB} ORDER BY published_at DESC LIMIT 4`),
      db.all(`SELECT * FROM gallery WHERE status = 'published' AND kind = 'image' ORDER BY sort, id DESC LIMIT 8`),
      db.all('SELECT * FROM stats ORDER BY sort, id'),
      db.get(`SELECT * FROM posts WHERE type = 'event' AND ${PUB} AND event_start >= ? ORDER BY event_start ASC LIMIT 1`, localNow()),
    ]);
    const lead = featured[0] || latest[0];
    const rest = latest.filter((p) => !lead || p.id !== lead.id).slice(0, 3);

    const body = html`
<section class="hero">
  <div class="hero-bg" aria-hidden="true"></div>
  <div class="wrap hero-grid">
    <div class="hero-text">
      <span class="eyebrow light">${s.school_name}</span>
      <h1><span class="pulse-word">${s.hero_title || s.site_name}</span></h1>
      <p class="slogan">${raw(icon('heart', 'sm'))} ${s.slogan}</p>
      <p class="lead">${s.hero_subtitle}</p>
      <form class="hero-search" action="/search" method="get" role="search">
        <label for="hq" class="sr">ابحث في الموقع</label>
        ${raw(icon('search'))}<input id="hq" name="q" type="search" placeholder="ابحث عن خبر، فعالية، جدول، مصدر تعليمي…" minlength="2" required>
        <button class="btn btn-gold" type="submit">بحث</button>
      </form>
      <div class="hero-cta"><a class="btn btn-teal" href="/news">${raw(icon('news', 'sm'))} آخر الأخبار</a><a class="btn btn-outline-light" href="/calendar">${raw(icon('calendar', 'sm'))} التقويم المدرسي</a><a class="btn btn-outline-light" href="/parents">${raw(icon('family', 'sm'))} ركن ولي الأمر</a></div>
    </div>
    <div class="hero-art">
      <div class="hero-frame"><img src="${s.hero_image || '/img/hero-campus.svg'}" alt="رسم توضيحي لمبنى المدرسة وطلبتها" width="1200" height="750" fetchpriority="high"></div>
      ${nextEvent ? html`<a class="countdown-card" href="${C.postUrl(nextEvent)}">
        <span class="cd-label">${raw(icon('calendar', 'sm'))} الفعالية القادمة</span>
        <b>${nextEvent.title}</b>
        <div class="countdown" data-countdown="${toDate(nextEvent.event_start).toISOString()}" aria-live="polite">
          <span><b data-u="d">0</b><small>يوم</small></span><span><b data-u="h">0</b><small>ساعة</small></span><span><b data-u="m">0</b><small>دقيقة</small></span><span><b data-u="s">0</b><small>ثانية</small></span>
        </div></a>` : ''}
    </div>
  </div>
  <div class="hero-wave" aria-hidden="true"><svg viewBox="0 0 1440 80" preserveAspectRatio="none"><path d="M0 40 L300 40 L340 10 L380 70 L420 40 L720 40 L760 0 L800 80 L840 40 L1440 40 L1440 80 L0 80Z" fill="currentColor"/></svg></div>
</section>

${stats.length ? html`<section class="stats-band"><div class="wrap stats-grid">${stats.map((st) => html`<div class="stat reveal">${raw(icon(st.icon || 'star'))}<b data-count="${st.value}">0</b><span class="suf">${st.suffix || ''}</span><small>${st.label}${st.is_demo ? ' (تجريبي)' : ''}</small></div>`)}</div></section>` : ''}

<section class="sec"><div class="wrap">
  ${C.sectionHead('أخبار المدرسة', { sub: 'المركز الإعلامي', href: '/news', ic: 'news' })}
  ${lead ? html`<div class="news-grid">
    <article class="lead-news reveal">
      <a href="${C.postUrl(lead)}" class="ln-media"><img src="${lead.cover || '/img/hero-campus.svg'}" alt="" width="1200" height="750"></a>
      <div class="ln-body"><div class="meta"><span class="tag">${lead.category || 'خبر'}</span>${C.demoBadge(lead)}</div><h3><a href="${C.postUrl(lead)}">${lead.title}</a></h3><p>${lead.excerpt}</p><span class="muted">${raw(icon('clock', 'sm'))} ${fmtUtc(lead.published_at)}</span></div>
    </article>
    <div class="news-side">${rest.map((p) => html`<a class="mini-news reveal" href="${C.postUrl(p)}"><img src="${p.cover || '/img/classroom.svg'}" alt="" loading="lazy" width="160" height="100"><span><b>${p.title}</b><small>${fmtUtc(p.published_at)} ${p.is_demo ? '· تجريبي' : ''}</small></span></a>`)}</div>
  </div>` : C.empty()}
</div></section>

${announcements.length ? html`<section class="sec sec-tint"><div class="wrap two-col">
  <div>${C.sectionHead('الإعلانات المدرسية', { sub: 'لا تفوّتها', href: '/news?kind=announcement', ic: 'megaphone' })}
    <ul class="ann-list">${announcements.map((a) => html`<li class="reveal"><a href="${C.postUrl(a)}"><span class="ann-ic">${raw(icon('megaphone', 'sm'))}</span><span><b>${a.title}</b><small>${fmtUtc(a.published_at)} · ${a.category || 'إعلان'} ${a.pinned ? '· مثبّت' : ''}</small></span>${C.demoBadge(a)}</a></li>`)}</ul></div>
  <div>${C.sectionHead('الفعاليات القادمة', { sub: 'سجّل حضورك', href: '/events', ic: 'calendar' })}
    ${upcoming.length ? html`<ul class="event-list">${upcoming.map((e) => html`<li class="reveal"><a href="${C.postUrl(e)}">${C.dateChip(e.event_start)}<span><b>${e.title}</b><small>${raw(icon('clock', 'sm'))} ${fmtDate(e.event_start, { weekday: 'long', hour: 'numeric', minute: '2-digit' })}${e.location ? ' · ' + e.location : ''}</small></span></a></li>`)}</ul>` : C.empty('لا توجد فعاليات قادمة حاليًا.')}
  </div>
</div></section>` : ''}

${initiatives.length ? html`<section class="sec"><div class="wrap">${C.sectionHead('المبادرات والمشاريع', { sub: 'نصنع الأثر', href: '/initiatives', ic: 'spark' })}
  <div class="grid-3">${initiatives.map((p) => C.card(p))}</div></div></section>` : ''}

${achievements.length ? html`<section class="sec sec-navy"><div class="wrap">${C.sectionHead('الإنجازات والتكريم', { sub: 'فخر النمارق', href: '/achievements', ic: 'trophy' })}
  <div class="ach-grid">${achievements.map((a) => html`<a class="ach reveal" href="${C.postUrl(a)}"><span class="ach-ic">${raw(icon('trophy'))}</span><b>${a.title}</b><small>${a.category || ''}${a.is_demo ? ' · تجريبي' : ''}</small></a>`)}</div></div></section>` : ''}

<section class="sec"><div class="wrap">
  ${C.sectionHead('إحصائيات تفاعلية', { sub: 'أرقام من حياة المدرسة', ic: 'chart' })}
  <div class="chart-card reveal" id="home-chart" data-src="/api/stats">
    <div class="chart-tabs" role="tablist"><button role="tab" aria-selected="true" data-view="types">المحتوى حسب القسم</button><button role="tab" aria-selected="false" data-view="months">النشاط الشهري</button></div>
    <div class="chart-area" aria-live="polite"><p class="muted">جارٍ تحميل الإحصائيات…</p></div>
  </div>
</div></section>

${gallery.length ? html`<section class="sec sec-tint"><div class="wrap">${C.sectionHead('من معرض الصور', { sub: 'لحظات لا تُنسى', href: '/media', ic: 'image' })}
  <div class="gallery-strip">${gallery.map((g, i) => html`<button type="button" class="g-item reveal" data-lb="home" data-src="${g.file}" data-caption="${g.title}${g.is_demo ? ' (صورة تجريبية)' : ''}" data-index="${i}"><img src="${g.file}" alt="${g.title}" loading="lazy" width="400" height="250"><span>${g.title}</span></button>`)}</div></div></section>` : ''}

<section class="sec"><div class="wrap cta-band reveal">
  <div><h2>شاركنا رأيك ومقترحاتك</h2><p>نؤمن بأن الأسرة شريك أساسي في نجاح المدرسة. شارك في الاستبانات أو أرسل مقترحك.</p></div>
  <div class="cta-btns"><a class="btn btn-gold" href="/parents#surveys">${raw(icon('poll', 'sm'))} الاستبانات</a><a class="btn btn-outline-light" href="/parents#suggest">${raw(icon('lightbulb', 'sm'))} أرسل مقترحًا</a></div>
</div></section>`;
    res.send(await layout(req, { body }));
  });

  // ===== عن المدرسة =====
  r.get('/about', async (req, res) => {
    const s = await db.settings();
    const staff = await db.all("SELECT * FROM staff WHERE status = 'published' ORDER BY sort, id");
    const values = lines(s.values).map((l) => l.split('|'));
    const body = html`${C.pageHero('عن المدرسة', { sub: s.school_name + ' — ' + s.slogan, crumbs: [{ label: 'عن المدرسة' }], ic: 'info' })}
<section class="sec"><div class="wrap about-intro">
  <div class="prose reveal">${raw(markdown(s.history))}</div>
  <img class="reveal rounded" src="/img/hero-campus.svg" alt="رسم توضيحي لمبنى المدرسة" width="1200" height="750" loading="lazy">
</div></section>
<section class="sec sec-tint"><div class="wrap vm-grid">
  <div class="vm reveal"><span class="vm-ic">${raw(icon('eye'))}</span><h2>الرؤية</h2><p>${s.vision}</p></div>
  <div class="vm reveal"><span class="vm-ic">${raw(icon('target'))}</span><h2>الرسالة</h2><p>${s.mission}</p></div>
</div></section>
<section class="sec"><div class="wrap">${C.sectionHead('أهدافنا', { sub: 'نسعى إلى', ic: 'flag' })}
  <ol class="goals">${lines(s.goals).map((g, i) => html`<li class="reveal"><span>${i + 1}</span>${g}</li>`)}</ol></div></section>
${values.length ? html`<section class="sec sec-navy"><div class="wrap">${C.sectionHead('قيمنا', { sub: 'ما نؤمن به', ic: 'star' })}
  <div class="values">${values.map(([t, d]) => html`<div class="val reveal"><b>${t}</b><small>${d || ''}</small></div>`)}</div></div></section>` : ''}
<section class="sec"><div class="wrap principal reveal">
  <div class="quote-mark" aria-hidden="true">”</div>
  <div><h2>كلمة ${s.principal_name}</h2><div class="prose">${raw(markdown(s.principal_message))}</div></div>
</div></section>
<section class="sec sec-tint"><div class="wrap">${C.sectionHead('الإدارة المدرسية', { sub: 'فريق العمل', ic: 'users' })}
  ${staff.length ? html`<div class="staff-grid">${staff.map((m) => html`<article class="staff reveal"><img src="${m.photo || '/img/avatar-man.svg'}" alt="" width="160" height="160" loading="lazy"><h3>${m.name}</h3><p class="pos">${m.position}</p>${m.department ? html`<small>${m.department}</small>` : ''}${m.bio ? html`<p class="bio">${m.bio}</p>` : ''}${C.demoBadge(m)}</article>`)}</div>` : C.empty('لم تُضف بيانات الإدارة المدرسية بعد.')}
</div></section>`;
    res.send(await layout(req, { title: 'عن المدرسة', description: s.vision, body }));
  });

  // ===== أقسام المحتوى العامة =====
  const sections = [
    { path: '/news', types: ['news', 'announcement'], title: 'الأخبار والإعلانات', sub: 'تابع آخر أخبار المدرسة وإعلاناتها الرسمية', ic: 'news' },
    { path: '/initiatives', types: ['initiative'], title: 'المبادرات والمشاريع التعليمية', sub: 'مبادرات ومشاريع تصنع أثرًا في الطالب والمجتمع', ic: 'spark' },
    { path: '/events', types: ['event'], title: 'الفعاليات والأنشطة', sub: 'فعاليات المدرسة القادمة والسابقة', ic: 'calendar' },
    { path: '/achievements', types: ['achievement'], title: 'الإنجازات والتكريم', sub: 'نفخر بإنجازات طلبتنا ومعلمينا', ic: 'trophy' },
    { path: '/library', types: ['library'], title: 'المكتبة التعليمية', sub: 'أوراق عمل وملخصات ومصادر تعلم قابلة للتحميل', ic: 'book' },
    { path: '/partnerships', types: ['partnership'], title: 'الشراكة المجتمعية', sub: 'شراكات المدرسة مع الأسرة ومؤسسات المجتمع', ic: 'handshake' },
  ];

  for (const sec of sections) {
    r.get(sec.path, async (req, res) => {
      let types = sec.types, tabs = '', opts = {};
      if (sec.path === '/news') {
        const kind = req.query.kind;
        if (kind === 'news' || kind === 'announcement') types = [kind];
        tabs = html`<div class="tabs" role="tablist">${[['', 'الكل'], ['news', 'الأخبار'], ['announcement', 'الإعلانات']].map(([k, l]) => html`<a role="tab" aria-selected="${(kind || '') === k}" href="/news${k ? '?kind=' + k : ''}" class="${(kind || '') === k ? 'on' : ''}">${l}</a>`)}</div>`;
      }
      if (sec.path === '/events') {
        const tab = req.query.tab || 'upcoming';
        const now = localNow();
        opts = tab === 'past'
          ? { extraWhere: 'COALESCE(p.event_end, p.event_start) < ?', extraArgs: [now], order: 'p.event_start DESC' }
          : tab === 'all' ? { order: 'p.event_start DESC' } : { extraWhere: 'COALESCE(p.event_end, p.event_start) >= ?', extraArgs: [now], order: 'p.event_start ASC' };
        tabs = html`<div class="tabs" role="tablist">${[['upcoming', 'القادمة'], ['past', 'السابقة'], ['all', 'الكل']].map(([k, l]) => html`<a role="tab" aria-selected="${tab === k}" href="/events?tab=${k}" class="${tab === k ? 'on' : ''}">${l}</a>`)}<a href="/calendar" class="tab-link">${raw(icon('calendar', 'sm'))} عرض التقويم</a></div>`;
      }
      const { items, total, page, pages } = await listPosts(req, types, opts);
      const cats = [...new Set(types.flatMap((t) => TYPES[t].categories))];
      const isLib = sec.path === '/library';
      const body = html`${C.pageHero(sec.title, { sub: sec.sub, crumbs: [{ label: sec.title }], ic: sec.ic })}
<section class="sec"><div class="wrap">
  ${tabs}
  ${C.filterBar(req, { categories: cats, years: await years() })}
  <p class="result-count">${fmtNum(total)} عنصر</p>
  ${items.length ? (isLib ? html`<div class="lib-grid">${items.map(libItem)}</div>` : html`<div class="grid-3">${items.map((p) => C.card(p))}</div>`) : C.empty(req.query.q ? 'لا توجد نتائج مطابقة لبحثك.' : undefined)}
  ${C.pagination(req, page, pages)}
</div></section>`;
      res.send(await layout(req, { title: sec.title, description: sec.sub, body }));
    });

    r.get(sec.path + '/:slug', async (req, res, next) => {
      const p = await getPost(sec.types, req.params.slug);
      if (!p) return next();
      await db.run('UPDATE posts SET views = views + 1 WHERE id = ?', p.id);
      const t = TYPES[p.type];
      const related = await db.all(`SELECT * FROM posts WHERE type = ? AND id != ? AND ${PUB} ORDER BY (category = ?) DESC, published_at DESC LIMIT 3`, p.type, p.id, p.category || '');
      const upcomingEvent = p.type === 'event' && p.event_start && toDate(p.event_start) > new Date();
      const yt = youtubeEmbed(p.external_url);
      const body = html`${C.pageHero(p.title, { crumbs: [{ label: sec.title, href: sec.path }, { label: excerpt(p.title, 40) }] })}
<section class="sec"><div class="wrap article-grid">
  <article class="article">
    <div class="meta big">${raw(icon(t.icon, 'sm'))}<span class="tag">${t.single}</span>${p.category ? html`<span class="tag alt">${p.category}</span>` : ''}${C.demoBadge(p)}
      <span>${raw(icon('clock', 'sm'))} ${fmtUtc(p.published_at)}</span><span>${raw(icon('eye', 'sm'))} ${fmtNum(p.views + 1)} مشاهدة</span>${p.year_name ? html`<span>${raw(icon('archive', 'sm'))} ${p.year_name}</span>` : ''}</div>
    ${p.cover ? html`<figure class="cover"><img src="${p.cover}" alt="${p.cover_alt || ''}" width="1200" height="750"></figure>` : ''}
    ${p.excerpt ? html`<p class="lede">${p.excerpt}</p>` : ''}
    <div class="prose">${raw(markdown(p.body))}</div>
    ${yt ? html`<div class="video-embed"><iframe src="${yt}" title="${p.title}" loading="lazy" allow="encrypted-media; picture-in-picture" allowfullscreen></iframe></div>` : ''}
    ${p.attachment ? html`<a class="attach" href="${p.attachment}" download>${raw(icon('download'))}<span><b>تحميل المرفق</b><small>${p.attachment.split('.').pop().toUpperCase()}</small></span></a>` : ''}
    ${p.external_url && !yt ? html`<a class="attach" href="${p.external_url}" target="_blank" rel="noopener">${raw(icon('external'))}<span><b>فتح الرابط</b><small>${p.external_url.replace(/^https?:\/\//, '').slice(0, 50)}</small></span></a>` : ''}
    ${p.tags ? html`<div class="tags">${p.tags.split(/[،,]/).map((x) => x.trim()).filter(Boolean).map((x) => html`<a href="/search?q=${encodeURIComponent(x)}">#${x}</a>`)}</div>` : ''}
    ${C.shareBar(p.title, C.postUrl(p))}
  </article>
  <aside class="side">
    ${p.event_start ? html`<div class="side-card ev-card">
      <h2>${raw(icon('calendar', 'sm'))} تفاصيل الموعد</h2>
      <dl><dt>البداية</dt><dd>${fmtDate(p.event_start, { dateStyle: 'full', timeStyle: p.event_start.length > 10 ? 'short' : undefined })}</dd>
      ${p.event_end ? html`<dt>النهاية</dt><dd>${fmtDate(p.event_end, { dateStyle: 'full', timeStyle: p.event_end.length > 10 ? 'short' : undefined })}</dd>` : ''}
      ${p.location ? html`<dt>المكان</dt><dd>${p.location}</dd>` : ''}</dl>
      ${upcomingEvent ? html`<div class="countdown sm" data-countdown="${toDate(p.event_start).toISOString()}"><span><b data-u="d">0</b><small>يوم</small></span><span><b data-u="h">0</b><small>ساعة</small></span><span><b data-u="m">0</b><small>دقيقة</small></span><span><b data-u="s">0</b><small>ثانية</small></span></div>` : ''}
      ${p.type === 'event' ? html`<a class="btn btn-teal block" href="${C.postUrl(p)}/ics">${raw(icon('calendar', 'sm'))} أضف إلى تقويمك</a>` : ''}
    </div>` : ''}
    ${related.length ? html`<div class="side-card"><h2>ذات صلة</h2>${related.map((x) => html`<a class="mini-news" href="${C.postUrl(x)}"><img src="${x.cover || '/img/classroom.svg'}" alt="" loading="lazy" width="160" height="100"><span><b>${x.title}</b><small>${fmtUtc(x.published_at)}</small></span></a>`)}</div>` : ''}
  </aside>
</div></section>`;
      const jsonld = {
        '@context': 'https://schema.org', '@type': p.type === 'event' ? 'Event' : 'NewsArticle', headline: p.title, name: p.title, description: p.excerpt,
        datePublished: p.published_at && p.published_at.replace(' ', 'T') + 'Z', image: p.cover ? [config.siteUrl + p.cover] : undefined,
        ...(p.type === 'event' ? { startDate: toDate(p.event_start)?.toISOString(), endDate: p.event_end ? toDate(p.event_end)?.toISOString() : undefined, location: { '@type': 'Place', name: p.location || 'مدرسة النمارق' } } : {}),
      };
      res.send(await layout(req, { title: p.title, description: p.excerpt, image: p.cover, body, jsonld }));
    });
  }

  // ملف ICS لإضافة الفعالية للتقويم
  r.get('/events/:slug/ics', async (req, res, next) => {
    const p = await getPost(['event'], req.params.slug);
    if (!p || !p.event_start) return next();
    const f = (d) => d.toISOString().replace(/[-:]/g, '').replace(/\.\d{3}/, '');
    const st = toDate(p.event_start), en = p.event_end ? toDate(p.event_end) : new Date(st.getTime() + 2 * 3600e3);
    const esc2 = (s) => String(s || '').replace(/[\\;,]/g, (m) => '\\' + m).replace(/\n/g, '\\n');
    const ics = ['BEGIN:VCALENDAR', 'VERSION:2.0', 'PRODID:-//Nabd Alnamariq//AR', 'BEGIN:VEVENT', `UID:event-${p.id}@nabd-alnamariq`, `DTSTAMP:${f(new Date())}`,
      `DTSTART:${f(st)}`, `DTEND:${f(en)}`, `SUMMARY:${esc2(p.title)}`, `DESCRIPTION:${esc2(p.excerpt)}`, `LOCATION:${esc2(p.location)}`, `URL:${config.siteUrl}${C.postUrl(p)}`, 'END:VEVENT', 'END:VCALENDAR'].join('\r\n');
    res.setHeader('Content-Disposition', `attachment; filename="event-${p.id}.ics"`);
    res.send(ics, 'text/calendar; charset=utf-8');
  });

  // ===== الجداول المدرسية =====
  r.get('/schedules', async (req, res) => {
    const where = ["status = 'published'"], args = [];
    if (req.query.kind && SCHEDULE_KINDS[req.query.kind]) { where.push('kind = ?'); args.push(req.query.kind); }
    if (req.query.grade) { where.push('grade = ?'); args.push(String(req.query.grade)); }
    if (req.query.year) { where.push('academic_year_id = ?'); args.push(toInt(req.query.year)); }
    if (req.query.q) { where.push('title LIKE ?'); args.push('%' + req.query.q + '%'); }
    const items = await db.all(`SELECT s.*, y.name year_name FROM schedules s LEFT JOIN academic_years y ON y.id = s.academic_year_id WHERE ${where.join(' AND ')} ORDER BY sort, id DESC`, ...args);
    const extra = String(html`<label><span class="sr">نوع الجدول</span><select name="kind"><option value="">كل الأنواع</option>${Object.entries(SCHEDULE_KINDS).map(([k, l]) => html`<option value="${k}" ${req.query.kind === k ? raw('selected') : ''}>${l}</option>`)}</select></label>
      <label><span class="sr">الصف</span><select name="grade"><option value="">كل الصفوف</option>${GRADES.map((g) => html`<option ${req.query.grade === g ? raw('selected') : ''}>${g}</option>`)}</select></label>`);
    const body = html`${C.pageHero('الجداول المدرسية', { sub: 'جداول الحصص والاختبارات والمناوبة', crumbs: [{ label: 'الجداول المدرسية' }], ic: 'table' })}
<section class="sec"><div class="wrap">
  ${C.filterBar(req, { years: await years(), extra })}
  ${items.length ? html`<div class="sched-grid">${items.map((sc) => html`<a class="sched reveal" href="/schedules/${sc.id}"><span class="sc-ic">${raw(icon(sc.kind === 'exam' ? 'file' : 'table'))}</span><span><b>${sc.title}</b><small>${SCHEDULE_KINDS[sc.kind] || ''} · ${sc.grade || ''}${sc.year_name ? ' · ' + sc.year_name : ''}</small></span>${C.demoBadge(sc)}</a>`)}</div>` : C.empty('لا توجد جداول مطابقة.')}
</div></section>`;
    res.send(await layout(req, { title: 'الجداول المدرسية', body }));
  });

  r.get('/schedules/:id', async (req, res, next) => {
    const sc = await db.get("SELECT s.*, y.name year_name FROM schedules s LEFT JOIN academic_years y ON y.id = s.academic_year_id WHERE s.id = ? AND s.status = 'published'", toInt(req.params.id));
    if (!sc) return next();
    const grid = safeJson(sc.grid, null);
    const isExam = sc.kind === 'exam';
    const body = html`${C.pageHero(sc.title, { crumbs: [{ label: 'الجداول المدرسية', href: '/schedules' }, { label: sc.title }] })}
<section class="sec"><div class="wrap">
  <div class="meta big"><span class="tag">${SCHEDULE_KINDS[sc.kind]}</span>${sc.grade ? html`<span class="tag alt">${sc.grade}${sc.section ? ' / ' + sc.section : ''}</span>` : ''}${sc.year_name ? html`<span>${raw(icon('archive', 'sm'))} ${sc.year_name}</span>` : ''}${C.demoBadge(sc)}</div>
  ${grid && grid.cells ? html`<div class="table-wrap"><table class="sched-table">
    <caption class="sr">${sc.title}</caption>
    <thead><tr><th scope="col">${isExam ? 'اليوم' : 'اليوم / الحصة'}</th>${grid.periods.map((p, i) => html`<th scope="col">${isExam ? p : html`الحصة ${i + 1}<small>${p}</small>`}</th>`)}</tr></thead>
    <tbody>${grid.cells.map((row, d) => html`<tr><th scope="row">${(grid.dayLabels && grid.dayLabels[d]) || DAYS[d] || ''}</th>${row.map((c) => html`<td class="${c ? 'subj-' + (Math.abs(hash(c)) % 8) : 'empty'}">${c || '—'}</td>`)}</tr>`)}</tbody>
  </table></div>` : ''}
  ${sc.notes ? html`<p class="note">${raw(icon('info', 'sm'))} ${sc.notes}</p>` : ''}
  <div class="actions">${sc.attachment ? html`<a class="btn btn-teal" href="${sc.attachment}" download>${raw(icon('download', 'sm'))} تحميل الجدول</a>` : ''}<button type="button" class="btn btn-ghost" data-print>${raw(icon('print', 'sm'))} طباعة الجدول</button><a class="btn btn-ghost" href="/schedules">${raw(icon('arrow', 'sm'))} كل الجداول</a></div>
</div></section>`;
    res.send(await layout(req, { title: sc.title, body }));
  });

  // ===== التقويم المدرسي =====
  r.get('/calendar', async (req, res) => {
    const up = await db.all("SELECT * FROM calendar_items WHERE status = 'published' AND COALESCE(ends_on, starts_on) >= date('now') ORDER BY starts_on LIMIT 8");
    const body = html`${C.pageHero('التقويم المدرسي', { sub: 'المواعيد المهمة والاختبارات والإجازات والفعاليات', crumbs: [{ label: 'التقويم المدرسي' }], ic: 'calendar' })}
<section class="sec"><div class="wrap cal-layout">
  <div class="cal reveal" id="calendar" data-src="/api/calendar">
    <div class="cal-head"><button type="button" class="tool-btn" data-cal="prev" aria-label="الشهر السابق">${raw(icon('chevron'))}</button><h2 class="cal-title" aria-live="polite"></h2><button type="button" class="tool-btn flip" data-cal="next" aria-label="الشهر التالي">${raw(icon('chevron'))}</button><button type="button" class="btn btn-ghost sm" data-cal="today">اليوم</button></div>
    <div class="cal-legend">${Object.entries(CALENDAR_KINDS).map(([k, v]) => html`<label><input type="checkbox" checked data-kind="${k}"><i class="k-${v.color}"></i>${v.label}</label>`)}<label><input type="checkbox" checked data-kind="post"><i class="k-teal2"></i>فعاليات المدرسة</label></div>
    <div class="cal-grid" role="grid" aria-label="أيام الشهر"></div>
    <div class="cal-day" aria-live="polite"></div>
  </div>
  <aside class="side"><div class="side-card"><h2>${raw(icon('clock', 'sm'))} المواعيد القادمة</h2>
    ${up.length ? html`<ul class="up-list">${up.map((c) => html`<li><i class="k-${CALENDAR_KINDS[c.kind]?.color || 'teal'}"></i><span><b>${c.title}</b><small>${fmtDate(c.starts_on, { dateStyle: 'medium' })}${c.ends_on ? ' – ' + fmtDate(c.ends_on, { dateStyle: 'medium' }) : ''}${c.is_demo ? ' · تجريبي' : ''}</small></span></li>`)}</ul>` : html`<p class="muted">لا توجد مواعيد قادمة.</p>`}
  </div></aside>
</div></section>`;
    res.send(await layout(req, { title: 'التقويم المدرسي', body }));
  });

  r.get('/api/calendar', async (req, res) => {
    const m = String(req.query.month || '').match(/^(\d{4})-(\d{2})$/);
    const now = new Date();
    const y = m ? +m[1] : now.getFullYear(), mo = m ? +m[2] : now.getMonth() + 1;
    const start = `${y}-${String(mo).padStart(2, '0')}-01`;
    const endD = new Date(Date.UTC(y, mo, 0));
    const end = endD.toISOString().slice(0, 10);
    const items = await db.all("SELECT id, title, kind, starts_on, ends_on, description, is_demo FROM calendar_items WHERE status = 'published' AND starts_on <= ? AND COALESCE(ends_on, starts_on) >= ?", end, start);
    const posts = await db.all(`SELECT id, title, slug, type, event_start, event_end, location, is_demo FROM posts WHERE type = 'event' AND ${PUB} AND substr(event_start,1,10) <= ? AND substr(COALESCE(event_end, event_start),1,10) >= ?`, end, start);
    res.setHeader('Cache-Control', 'public, max-age=60');
    res.json({
      month: `${y}-${String(mo).padStart(2, '0')}`,
      items: items.map((i) => ({ title: i.title, kind: i.kind, label: CALENDAR_KINDS[i.kind]?.label, color: CALENDAR_KINDS[i.kind]?.color, start: i.starts_on, end: i.ends_on || i.starts_on, description: i.description, demo: !!i.is_demo }))
        .concat(posts.map((p) => ({ title: p.title, kind: 'post', label: 'فعالية', color: 'teal2', start: p.event_start.slice(0, 10), end: (p.event_end || p.event_start).slice(0, 10), time: p.event_start.slice(11, 16), location: p.location, url: C.postUrl(p), demo: !!p.is_demo }))),
    });
  });

  // ===== المعرض الإعلامي =====
  r.get('/media', async (req, res) => {
    const where = ["status = 'published'"], args = [];
    const kind = req.query.kind === 'video' ? 'video' : req.query.kind === 'image' ? 'image' : '';
    if (kind) { where.push('kind = ?'); args.push(kind); }
    if (req.query.album) { where.push('album = ?'); args.push(String(req.query.album)); }
    if (req.query.year) { where.push('academic_year_id = ?'); args.push(toInt(req.query.year)); }
    const items = await db.all(`SELECT * FROM gallery WHERE ${where.join(' AND ')} ORDER BY sort, id DESC LIMIT 200`, ...args);
    const albums = (await db.all("SELECT DISTINCT album FROM gallery WHERE status = 'published' AND album IS NOT NULL AND album != '' ORDER BY album")).map((a) => a.album);
    const qs = (o) => '/media?' + new URLSearchParams(Object.fromEntries(Object.entries({ ...req.query, ...o }).filter(([, v]) => v))).toString();
    const body = html`${C.pageHero('المعرض الإعلامي', { sub: 'صور ومقاطع مرئية من حياة المدرسة', crumbs: [{ label: 'المعرض الإعلامي' }], ic: 'image' })}
<section class="sec"><div class="wrap">
  <div class="tabs">${[['', 'الكل'], ['image', 'الصور'], ['video', 'الفيديو']].map(([k, l]) => html`<a href="${qs({ kind: k })}" class="${kind === k ? 'on' : ''}">${l}</a>`)}</div>
  <div class="chips">${albums.length ? html`<a class="chip ${!req.query.album ? 'on' : ''}" href="${qs({ album: '' })}">كل الألبومات</a>${albums.map((a) => html`<a class="chip ${req.query.album === a ? 'on' : ''}" href="${qs({ album: a })}">${a}</a>`)}` : ''}</div>
  ${items.length ? html`<div class="masonry">${items.map((g, i) => g.kind === 'video' ? videoItem(g, i) : html`<button type="button" class="g-item reveal" data-lb="media" data-index="${i}" data-src="${g.file}" data-caption="${g.title}${g.is_demo ? ' (تجريبي)' : ''}"><img src="${g.file}" alt="${g.title}" loading="lazy" width="600" height="375"><span>${g.title}${g.is_demo ? ' · تجريبي' : ''}</span></button>`)}</div>` : C.empty('لا توجد عناصر في المعرض حاليًا.')}
</div></section>`;
    res.send(await layout(req, { title: 'المعرض الإعلامي', body }));
  });

  // ===== ركن ولي الأمر =====
  r.get('/parents', async (req, res) => {
    const guides = await db.all(`SELECT * FROM posts WHERE type = 'guide' AND ${PUB} AND COALESCE(category,'') != 'أسئلة شائعة' ORDER BY pinned DESC, published_at DESC LIMIT 12`);
    const faqs = await db.all(`SELECT * FROM posts WHERE type = 'guide' AND ${PUB} AND category = 'أسئلة شائعة' ORDER BY published_at ASC`);
    const surveys = await db.all("SELECT s.*, (SELECT COUNT(*) FROM survey_responses r WHERE r.survey_id = s.id) n FROM surveys s WHERE status = 'open' AND (starts_on IS NULL OR starts_on <= date('now')) AND (ends_on IS NULL OR ends_on >= date('now')) ORDER BY id DESC");
    const sent = req.query.sent === '1';
    const body = html`${C.pageHero('ركن ولي الأمر', { sub: 'شراكة حقيقية بين المدرسة والأسرة', crumbs: [{ label: 'ركن ولي الأمر' }], ic: 'family' })}
<section class="sec"><div class="wrap">
  <div class="quick-links">${[['/calendar', 'calendar', 'التقويم المدرسي'], ['/schedules', 'table', 'الجداول المدرسية'], ['/news?kind=announcement', 'megaphone', 'الإعلانات'], ['/library', 'book', 'المكتبة التعليمية'], ['/contact', 'mail', 'تواصل مع المدرسة']].map(([h, ic, l]) => html`<a class="ql reveal" href="${h}">${raw(icon(ic))}<b>${l}</b></a>`)}</div>
</div></section>
<section class="sec sec-tint"><div class="wrap">${C.sectionHead('أدلة وإرشادات', { sub: 'لولي الأمر', ic: 'book' })}
  ${guides.length ? html`<div class="grid-3">${guides.map((p) => C.card(p))}</div>` : C.empty()}</div></section>
${faqs.length ? html`<section class="sec"><div class="wrap narrow">${C.sectionHead('الأسئلة الشائعة', { sub: 'إجابات سريعة', ic: 'info' })}
  <div class="faq">${faqs.map((f) => html`<details class="reveal"><summary>${f.title} ${C.demoBadge(f)}</summary><div class="prose">${raw(markdown(f.body))}</div></details>`)}</div></div></section>` : ''}
<section class="sec sec-tint" id="surveys"><div class="wrap">${C.sectionHead('الاستبانات', { sub: 'رأيك يصنع الفرق', ic: 'poll' })}
  ${surveys.length ? html`<div class="grid-3">${surveys.map((sv) => html`<article class="survey-card reveal"><span class="sv-ic">${raw(icon('poll'))}</span><h3>${sv.title}</h3><p>${sv.description || ''}</p><small class="muted">${fmtNum(sv.n)} مشاركة ${sv.ends_on ? '· تنتهي ' + fmtDate(sv.ends_on, { dateStyle: 'medium' }) : ''}</small>${C.demoBadge(sv)}<a class="btn btn-teal" href="/surveys/${sv.id}">شارك الآن</a></article>`)}</div>` : C.empty('لا توجد استبانات مفتوحة حاليًا.')}
</div></section>
<section class="sec" id="suggest"><div class="wrap narrow">${C.sectionHead('صندوق المقترحات', { sub: 'نستمع إليك', ic: 'lightbulb' })}
  ${sent ? html`<div class="flash ok" role="status">${raw(icon('check', 'sm'))} شكرًا لك! وصل مقترحك إلى إدارة المدرسة وسيتم دراسته.</div>` : ''}
  <form class="form card-form" method="post" action="/parents/suggest">
    ${formExtras()}
    <div class="row2"><label>الاسم (اختياري)<input name="name" maxlength="80" autocomplete="name"></label><label>رقم الهاتف (اختياري)<input name="phone" maxlength="20" inputmode="tel" dir="ltr" autocomplete="tel"></label></div>
    <div class="row2"><label>صف الطالب<select name="student_grade"><option value="">—</option>${GRADES.map((g) => html`<option>${g}</option>`)}</select></label><label>نوع الرسالة<select name="category">${['اقتراح', 'ملاحظة', 'شكر وتقدير', 'شكوى'].map((c) => html`<option>${c}</option>`)}</select></label></div>
    <label>نص المقترح <span class="req">*</span><textarea name="message" rows="5" required minlength="10" maxlength="2000"></textarea></label>
    <button class="btn btn-gold" type="submit">${raw(icon('lightbulb', 'sm'))} إرسال المقترح</button>
  </form>
</div></section>`;
    res.send(await layout(req, { title: 'ركن ولي الأمر', description: 'أدلة وإرشادات واستبانات ومقترحات لأولياء الأمور', body }));
  });

  r.get('/parents/:slug', async (req, res, next) => {
    const p = await getPost(['guide'], req.params.slug);
    if (!p) return next();
    await db.run('UPDATE posts SET views = views + 1 WHERE id = ?', p.id);
    const body = html`${C.pageHero(p.title, { crumbs: [{ label: 'ركن ولي الأمر', href: '/parents' }, { label: excerpt(p.title, 40) }] })}
<section class="sec"><div class="wrap narrow"><article class="article">
  <div class="meta big"><span class="tag">${p.category || 'دليل'}</span>${C.demoBadge(p)}<span>${raw(icon('clock', 'sm'))} ${fmtUtc(p.published_at)}</span></div>
  ${p.cover ? html`<figure class="cover"><img src="${p.cover}" alt="" width="1200" height="750"></figure>` : ''}
  <div class="prose">${raw(markdown(p.body))}</div>
  ${p.attachment ? html`<a class="attach" href="${p.attachment}" download>${raw(icon('download'))}<span><b>تحميل المرفق</b></span></a>` : ''}
  ${C.shareBar(p.title, '/parents/' + encodeURIComponent(p.slug))}
</article></div></section>`;
    res.send(await layout(req, { title: p.title, description: p.excerpt, body }));
  });

  r.post('/parents/suggest', async (req, res) => {
    checkFormToken(req);
    if (!rateLimit('sug:' + req.ip, 5, 15 * 60e3)) throw new HttpError(429, 'أرسلت عددًا كبيرًا من الرسائل، حاول لاحقًا');
    const message = clampStr(req.body.message, 2000);
    if (message.length < 10) throw new HttpError(400, 'يرجى كتابة المقترح بشكل أوضح (10 أحرف على الأقل)');
    const cat = ['اقتراح', 'ملاحظة', 'شكر وتقدير', 'شكوى'].includes(req.body.category) ? req.body.category : 'اقتراح';
    await db.insert('suggestions', { name: clampStr(req.body.name, 80) || null, phone: clampStr(req.body.phone, 20) || null, student_grade: clampStr(req.body.student_grade, 40) || null, category: cat, message, ip: req.ip });
    res.redirect('/parents?sent=1#suggest');
  });

  // ===== الاستبانات =====
  r.get('/surveys/:id', async (req, res, next) => {
    const sv = await db.get("SELECT * FROM surveys WHERE id = ? AND status IN ('open','closed')", toInt(req.params.id));
    if (!sv) return next();
    const qs = await db.all('SELECT * FROM survey_questions WHERE survey_id = ? ORDER BY sort, id', sv.id);
    const done = req.query.done === '1';
    const already = await db.get('SELECT id FROM survey_responses WHERE survey_id = ? AND ip_hash = ?', sv.id, ipHash(req.ip + '|' + sv.id));
    const open = sv.status === 'open' && (!sv.ends_on || sv.ends_on >= new Date().toISOString().slice(0, 10));
    const body = html`${C.pageHero(sv.title, { sub: sv.description, crumbs: [{ label: 'ركن ولي الأمر', href: '/parents' }, { label: 'استبانة' }] })}
<section class="sec"><div class="wrap narrow">
  ${C.demoBadge(sv)}
  ${done ? html`<div class="flash ok" role="status">${raw(icon('check', 'sm'))} شكرًا لمشاركتك! تم تسجيل إجاباتك بنجاح.</div>`
    : !open ? html`<div class="flash warn">هذه الاستبانة مغلقة حاليًا.</div>`
    : already ? html`<div class="flash warn">لقد شاركت في هذه الاستبانة من قبل. شكرًا لك!</div>`
    : html`<form class="form card-form survey" method="post" action="/surveys/${sv.id}">
      ${formExtras()}
      ${qs.map((q, i) => html`<fieldset class="q"><legend><span class="qn">${i + 1}</span>${q.text}${q.required ? html` <span class="req">*</span>` : ''}</legend>${questionInput(q)}</fieldset>`)}
      <button class="btn btn-gold" type="submit">${raw(icon('check', 'sm'))} إرسال الإجابات</button>
    </form>`}
</div></section>`;
    res.send(await layout(req, { title: sv.title, description: sv.description, body, noindex: true }));
  });

  r.post('/surveys/:id', async (req, res, next) => {
    checkFormToken(req);
    const sv = await db.get("SELECT * FROM surveys WHERE id = ? AND status = 'open'", toInt(req.params.id));
    if (!sv) return next();
    if (!rateLimit('sv:' + req.ip, 10, 60 * 60e3)) throw new HttpError(429, 'محاولات كثيرة، حاول لاحقًا');
    const h = ipHash(req.ip + '|' + sv.id);
    if (await db.get('SELECT id FROM survey_responses WHERE survey_id = ? AND ip_hash = ?', sv.id, h)) return res.redirect(`/surveys/${sv.id}`);
    const qs = await db.all('SELECT * FROM survey_questions WHERE survey_id = ? ORDER BY sort, id', sv.id);
    const answers = {};
    for (const q of qs) {
      let v = req.body['q' + q.id];
      const opts = safeJson(q.options, []);
      if (q.qtype === 'rating') v = ['1', '2', '3', '4', '5'].includes(v) ? v : '';
      else if (q.qtype === 'single') v = opts.includes(v) ? v : '';
      else if (q.qtype === 'multi') v = [].concat(v || []).filter((x) => opts.includes(x));
      else v = clampStr(v, 1500);
      if (q.required && (!v || (Array.isArray(v) && !v.length))) throw new HttpError(400, `يرجى الإجابة على السؤال: ${q.text}`);
      answers[q.id] = v;
    }
    await db.insert('survey_responses', { survey_id: sv.id, answers: JSON.stringify(answers), ip_hash: h });
    res.redirect(`/surveys/${sv.id}?done=1`);
  });

  // ===== تواصل معنا =====
  r.get('/contact', async (req, res) => {
    const s = await db.settings();
    const sent = req.query.sent === '1';
    const wa = s.whatsapp ? s.whatsapp.replace(/\D/g, '') : '';
    const body = html`${C.pageHero('تواصل معنا', { sub: 'يسعدنا تواصلكم واستفساراتكم', crumbs: [{ label: 'تواصل معنا' }], ic: 'mail' })}
<section class="sec"><div class="wrap contact-grid">
  <div class="contact-info reveal">
    <h2>معلومات التواصل</h2>
    <ul>
      ${s.contact_address ? html`<li>${raw(icon('pin'))}<span><small>العنوان</small><b>${s.contact_address}</b></span></li>` : ''}
      ${s.contact_phone ? html`<li>${raw(icon('phone'))}<span><small>الهاتف</small><a href="tel:${s.contact_phone.replace(/\s/g, '')}" dir="ltr">${s.contact_phone}</a></span></li>` : ''}
      ${s.contact_email ? html`<li>${raw(icon('mail'))}<span><small>البريد الإلكتروني</small><a href="mailto:${s.contact_email}">${s.contact_email}</a></span></li>` : ''}
      ${s.contact_hours ? html`<li>${raw(icon('clock'))}<span><small>ساعات العمل</small><b>${s.contact_hours}</b></span></li>` : ''}
    </ul>
    ${wa ? html`<a class="btn btn-wa block" href="https://wa.me/${wa}" target="_blank" rel="noopener">${raw(icon('whatsapp', 'sm'))} راسلنا عبر واتساب</a>` : ''}
    ${s.map_embed && /^https:\/\/(www\.)?google\.com\/maps\/embed/.test(s.map_embed) ? html`<div class="map"><iframe src="${s.map_embed}" title="موقع المدرسة على الخريطة" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe></div>` : ''}
  </div>
  <div>
    ${sent ? html`<div class="flash ok" role="status">${raw(icon('check', 'sm'))} تم إرسال رسالتك بنجاح، وسنتواصل معك قريبًا بإذن الله.</div>` : ''}
    <form class="form card-form reveal" method="post" action="/contact">
      ${formExtras()}
      <div class="row2"><label>الاسم الكامل <span class="req">*</span><input name="name" required maxlength="80" autocomplete="name"></label>
      <label>رقم الهاتف<input name="phone" maxlength="20" inputmode="tel" dir="ltr" autocomplete="tel"></label></div>
      <div class="row2"><label>البريد الإلكتروني<input name="email" type="email" maxlength="120" dir="ltr" autocomplete="email"></label>
      <label>الموضوع<select name="subject">${['استفسار عام', 'شؤون الطلبة', 'التسجيل والقبول', 'الإبلاغ عن غياب', 'اقتراح', 'أخرى'].map((x) => html`<option>${x}</option>`)}</select></label></div>
      <label>الرسالة <span class="req">*</span><textarea name="message" rows="6" required minlength="10" maxlength="3000"></textarea></label>
      <button class="btn btn-gold" type="submit">${raw(icon('mail', 'sm'))} إرسال الرسالة</button>
    </form>
  </div>
</div></section>`;
    res.send(await layout(req, { title: 'تواصل معنا', body }));
  });

  r.post('/contact', async (req, res) => {
    checkFormToken(req);
    if (!rateLimit('contact:' + req.ip, 5, 15 * 60e3)) throw new HttpError(429, 'أرسلت عددًا كبيرًا من الرسائل، حاول لاحقًا');
    const name = clampStr(req.body.name, 80), message = clampStr(req.body.message, 3000), email = clampStr(req.body.email, 120);
    if (name.length < 2) throw new HttpError(400, 'يرجى كتابة الاسم');
    if (message.length < 10) throw new HttpError(400, 'الرسالة قصيرة جدًا');
    if (email && !isEmail(email)) throw new HttpError(400, 'البريد الإلكتروني غير صحيح');
    await db.insert('messages', { name, email: email || null, phone: clampStr(req.body.phone, 20) || null, subject: clampStr(req.body.subject, 80), message, ip: req.ip });
    res.redirect('/contact?sent=1');
  });

  // ===== البحث الشامل =====
  r.get('/search', async (req, res) => {
    const q = clampStr(req.query.q, 100);
    const type = TYPES[req.query.type] ? req.query.type : '';
    const nq = '%' + normalizeAr(q) + '%';
    let posts = [], others = [], counts = {};
    if (q.length >= 2) {
      const yr = req.query.year ? toInt(req.query.year) : null;
      const rows = await db.all(`SELECT * FROM posts WHERE ${PUB} AND search_text LIKE ? ${yr ? 'AND academic_year_id = ' + yr : ''} ORDER BY published_at DESC LIMIT 200`, nq);
      for (const p of rows) counts[p.type] = (counts[p.type] || 0) + 1;
      posts = type ? rows.filter((p) => p.type === type) : rows;
      if (!type) {
        const like = '%' + q + '%';
        const sc = await db.all("SELECT id, title, kind, grade FROM schedules WHERE status = 'published' AND (title LIKE ? OR grade LIKE ?) LIMIT 10", like, like);
        const ga = await db.all("SELECT id, title, album, file, kind FROM gallery WHERE status = 'published' AND (title LIKE ? OR album LIKE ? OR description LIKE ?) LIMIT 12", like, like, like);
        const ca = await db.all("SELECT id, title, starts_on FROM calendar_items WHERE status = 'published' AND title LIKE ? LIMIT 10", like);
        others = [...sc.map((x) => ({ href: '/schedules/' + x.id, title: x.title, label: 'جدول', ic: 'table' })), ...ca.map((x) => ({ href: '/calendar', title: x.title, label: 'التقويم · ' + fmtDate(x.starts_on, { dateStyle: 'medium' }), ic: 'calendar' })), ...ga.map((x) => ({ href: '/media?album=' + encodeURIComponent(x.album || ''), title: x.title, label: x.kind === 'video' ? 'فيديو' : 'صورة', ic: x.kind === 'video' ? 'video' : 'image' }))];
      }
    }
    const total = Object.values(counts).reduce((a, b) => a + b, 0);
    const mark = (t) => { if (!q) return esc(t); const parts = String(t).split(new RegExp('(' + q.replace(/[.*+?^${}()|[\]\\]/g, '\\$&') + ')', 'gi')); return parts.map((x, i) => (i % 2 ? '<mark>' + esc(x) + '</mark>' : esc(x))).join(''); };
    const body = html`${C.pageHero('البحث الشامل', { sub: q ? `نتائج البحث عن «${q}»` : 'ابحث في كل محتوى الموقع', crumbs: [{ label: 'البحث' }], ic: 'search' })}
<section class="sec"><div class="wrap">
  <form class="filters big" method="get" action="/search" role="search">
    <label class="f-search">${raw(icon('search', 'sm'))}<span class="sr">كلمة البحث</span><input type="search" name="q" value="${q}" placeholder="اكتب كلمة البحث…" minlength="2" required autofocus></label>
    <label><span class="sr">القسم</span><select name="type"><option value="">كل الأقسام</option>${Object.entries(TYPES).map(([k, t]) => html`<option value="${k}" ${type === k ? raw('selected') : ''}>${t.label}</option>`)}</select></label>
    <label><span class="sr">العام</span><select name="year"><option value="">كل الأعوام</option>${(await years()).map((y) => html`<option value="${y.id}" ${String(req.query.year) === String(y.id) ? raw('selected') : ''}>${y.name}</option>`)}</select></label>
    <button class="btn btn-navy">بحث</button>
  </form>
  ${q.length >= 2 ? html`
    ${total ? html`<div class="chips">${Object.entries(counts).map(([k, n]) => html`<a class="chip ${type === k ? 'on' : ''}" href="/search?q=${encodeURIComponent(q)}&type=${k}">${TYPES[k].label} (${n})</a>`)}${type ? html`<a class="chip" href="/search?q=${encodeURIComponent(q)}">الكل</a>` : ''}</div>` : ''}
    <p class="result-count">${fmtNum(posts.length + others.length)} نتيجة</p>
    ${posts.length || others.length ? html`<ul class="search-results">
      ${posts.map((p) => html`<li><a href="${C.postUrl(p)}"><span class="sr-ic">${raw(icon(TYPES[p.type].icon))}</span><span><small>${TYPES[p.type].single}${p.category ? ' · ' + p.category : ''} · ${fmtUtc(p.published_at)}${p.is_demo ? ' · تجريبي' : ''}</small><b>${raw(mark(p.title))}</b><span class="muted">${raw(mark(p.excerpt || ''))}</span></span></a></li>`)}
      ${others.map((o) => html`<li><a href="${o.href}"><span class="sr-ic">${raw(icon(o.ic))}</span><span><small>${o.label}</small><b>${raw(mark(o.title))}</b></span></a></li>`)}
    </ul>` : C.empty('لم نعثر على نتائج. جرّب كلمات أخرى أو أقل تحديدًا.')}` : ''}
</div></section>`;
    res.send(await layout(req, { title: q ? `بحث: ${q}` : 'البحث', body, noindex: true }));
  });

  // ===== الأرشيف حسب العام الدراسي =====
  r.get('/archive', async (req, res) => {
    const ys = await db.all(`SELECT y.*, (SELECT COUNT(*) FROM posts p WHERE p.academic_year_id = y.id AND ${PUBP}) n FROM academic_years y ORDER BY name DESC`);
    const sel = ys.find((y) => String(y.id) === String(req.query.year)) || ys[0];
    let groups = [];
    if (sel) {
      const rows = await db.all(`SELECT type, COUNT(*) n FROM posts WHERE academic_year_id = ? AND ${PUB} GROUP BY type`, sel.id);
      groups = rows.map((r2) => ({ ...r2, t: TYPES[r2.type] })).filter((g) => g.t);
    }
    const latest = sel ? await db.all(`SELECT * FROM posts WHERE academic_year_id = ? AND ${PUB} ORDER BY published_at DESC LIMIT 9`, sel.id) : [];
    const body = html`${C.pageHero('أرشيف المحتوى', { sub: 'تصفّح محتوى الموقع حسب العام الدراسي', crumbs: [{ label: 'الأرشيف' }], ic: 'archive' })}
<section class="sec"><div class="wrap">
  <div class="tabs">${ys.map((y) => html`<a href="/archive?year=${y.id}" class="${sel && sel.id === y.id ? 'on' : ''}">${y.name}${y.is_current ? ' (الحالي)' : ''} <small>${y.n}</small></a>`)}</div>
  ${groups.length ? html`<div class="arch-grid">${groups.map((g) => html`<a class="ql reveal" href="${g.t.path}?year=${sel.id}${g.type === 'announcement' ? '&kind=announcement' : g.type === 'news' ? '&kind=news' : g.type === 'event' ? '&tab=all' : ''}">${raw(icon(g.t.icon))}<b>${g.t.label}</b><small>${fmtNum(g.n)} عنصر</small></a>`)}</div>
  <h2 class="h-sub">أحدث محتوى العام ${sel.name}</h2><div class="grid-3">${latest.map((p) => C.card(p))}</div>` : C.empty('لا يوجد محتوى مؤرشف لهذا العام.')}
</div></section>`;
    res.send(await layout(req, { title: 'الأرشيف', body }));
  });

  // ===== واجهات بيانات =====
  r.get('/api/stats', async (req, res) => {
    const byType = await db.all(`SELECT type, COUNT(*) n FROM posts WHERE ${PUB} GROUP BY type`);
    const byMonth = await db.all(`SELECT substr(published_at,1,7) m, COUNT(*) n FROM posts WHERE ${PUB} AND published_at >= date('now','-11 months','start of month') GROUP BY m ORDER BY m`);
    const gallery = await db.get("SELECT COUNT(*) n FROM gallery WHERE status = 'published'");
    const months = [];
    const d = new Date(); d.setUTCDate(1);
    for (let i = 11; i >= 0; i--) {
      const x = new Date(Date.UTC(d.getUTCFullYear(), d.getUTCMonth() - i, 1));
      const key = x.toISOString().slice(0, 7);
      months.push({ key, label: new Intl.DateTimeFormat('ar-OM', { month: 'short' }).format(x), n: (byMonth.find((m) => m.m === key) || {}).n || 0 });
    }
    res.setHeader('Cache-Control', 'public, max-age=300');
    res.json({
      types: Object.entries(TYPES).map(([k, t]) => ({ key: k, label: t.label, n: (byType.find((b) => b.type === k) || {}).n || 0, href: t.path })).concat([{ key: 'gallery', label: 'المعرض الإعلامي', n: gallery.n, href: '/media' }]),
      months,
    });
  });

  // ===== SEO =====
  r.get('/robots.txt', (req, res) => res.send(`User-agent: *\nAllow: /\nDisallow: /admin\nDisallow: /search\nSitemap: ${config.siteUrl}/sitemap.xml\n`, 'text/plain; charset=utf-8'));
  r.get('/sitemap.xml', async (req, res) => {
    const posts = await db.all(`SELECT type, slug, updated_at FROM posts WHERE ${PUB} ORDER BY published_at DESC LIMIT 5000`);
    const sch = await db.all("SELECT id, updated_at FROM schedules WHERE status = 'published'");
    const staticPaths = ['/', '/about', '/news', '/initiatives', '/events', '/schedules', '/achievements', '/library', '/parents', '/calendar', '/media', '/partnerships', '/contact', '/archive'];
    const u = (loc, lm) => `<url><loc>${esc(config.siteUrl + loc)}</loc>${lm ? `<lastmod>${lm.slice(0, 10)}</lastmod>` : ''}</url>`;
    const xml = `<?xml version="1.0" encoding="UTF-8"?><urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">${staticPaths.map((p) => u(p)).join('')}${posts.map((p) => u(`${TYPES[p.type].path}/${encodeURIComponent(p.slug)}`, p.updated_at)).join('')}${sch.map((x) => u('/schedules/' + x.id, x.updated_at)).join('')}</urlset>`;
    res.send(xml, 'application/xml; charset=utf-8');
  });
  r.get('/feed.xml', async (req, res) => {
    const s = await db.settings();
    const posts = await db.all(`SELECT * FROM posts WHERE type IN ('news','announcement','event') AND ${PUB} ORDER BY published_at DESC LIMIT 30`);
    const xml = `<?xml version="1.0" encoding="UTF-8"?><rss version="2.0"><channel><title>${esc(s.site_name)}</title><link>${config.siteUrl}</link><description>${esc(s.slogan)}</description><language>ar</language>${posts.map((p) => `<item><title>${esc(p.title)}</title><link>${config.siteUrl}${C.postUrl(p)}</link><guid>${config.siteUrl}${C.postUrl(p)}</guid><pubDate>${new Date(p.published_at.replace(' ', 'T') + 'Z').toUTCString()}</pubDate><description>${esc(p.excerpt || '')}</description></item>`).join('')}</channel></rss>`;
    res.send(xml, 'application/rss+xml; charset=utf-8');
  });
  r.get('/manifest.webmanifest', async (req, res) => {
    const s = await db.settings();
    res.send(JSON.stringify({ name: s.site_name, short_name: s.site_name, lang: 'ar', dir: 'rtl', start_url: '/', display: 'standalone', background_color: '#0B1F3A', theme_color: '#0B1F3A', icons: [{ src: s.logo || '/img/logo.svg', sizes: 'any' }] }), 'application/manifest+json');
  });
};

// ===== مساعدات =====
function localNow() {
  const d = new Date(Date.now() + 4 * 3600e3);
  return d.toISOString().slice(0, 16).replace('T', ' ');
}
function hash(s) { let h = 0; for (const c of String(s)) h = (h * 31 + c.charCodeAt(0)) | 0; return h; }

function libItem(p) {
  const ext = p.attachment ? p.attachment.split('.').pop().toUpperCase() : p.external_url ? 'رابط' : '';
  return html`<article class="lib reveal">
    <span class="lib-ic">${raw(icon(p.attachment ? 'file' : p.external_url ? 'link' : 'book'))}<small>${ext}</small></span>
    <div><div class="meta"><span class="tag">${p.category || 'مصدر'}</span>${C.demoBadge(p)}</div>
      <h3><a href="${C.postUrl(p)}">${p.title}</a></h3><p>${p.excerpt || ''}</p>
      <div class="lib-actions">${p.attachment ? html`<a class="btn btn-teal sm" href="${p.attachment}" download>${raw(icon('download', 'sm'))} تحميل</a>` : ''}${p.external_url ? html`<a class="btn btn-ghost sm" href="${p.external_url}" target="_blank" rel="noopener">${raw(icon('external', 'sm'))} فتح</a>` : ''}<a class="btn btn-ghost sm" href="${C.postUrl(p)}">التفاصيل</a></div>
    </div></article>`;
}

function videoItem(g, i) {
  const yt = youtubeEmbed(g.video_url);
  return html`<figure class="v-item reveal">${yt ? html`<div class="video-embed"><iframe src="${yt}" title="${g.title}" loading="lazy" allow="encrypted-media; picture-in-picture" allowfullscreen></iframe></div>`
    : g.file ? html`<video controls preload="metadata" src="${g.file}" playsinline></video>` : ''}<figcaption>${raw(icon('video', 'sm'))} ${g.title}${g.is_demo ? ' · تجريبي' : ''}</figcaption></figure>`;
}

function questionInput(q) {
  const name = 'q' + q.id;
  const opts = safeJson(q.options, []);
  const req = q.required ? raw('required') : '';
  if (q.qtype === 'rating') {
    return html`<div class="rating" role="radiogroup">${[1, 2, 3, 4, 5].map((n) => html`<label><input type="radio" name="${name}" value="${n}" ${req}><span>${n}</span><small>${['', 'ضعيف', 'مقبول', 'جيد', 'جيد جدًا', 'ممتاز'][n]}</small></label>`)}</div>`;
  }
  if (q.qtype === 'single') return html`<div class="opts">${opts.map((o) => html`<label><input type="radio" name="${name}" value="${o}" ${req}> ${o}</label>`)}</div>`;
  if (q.qtype === 'multi') return html`<div class="opts">${opts.map((o) => html`<label><input type="checkbox" name="${name}" value="${o}"> ${o}</label>`)}</div>`;
  return html`<textarea name="${name}" rows="3" maxlength="1500" ${req}></textarea>`;
}
