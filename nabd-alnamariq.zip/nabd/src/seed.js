'use strict';
// البيانات الأساسية + المحتوى التجريبي (مُعلَّم is_demo = 1 ويمكن حذفه بنقرة من لوحة التحكم)
const crypto = require('node:crypto');
const db = require('./db');
const config = require('./config');
const { DEFAULT_ROLES } = require('./content-types');
const { hashPassword } = require('./core/security');
const { slugify } = require('./core/util');

const BASE_VERSION = '1';

const DEFAULT_SETTINGS = {
  logo: '/img/logo.svg',
  site_name: 'نبض النمارق',
  school_name: 'مدرسة النمارق للتعليم الأساسي',
  slogan: 'مدرستنا تنبض بالعلم والإبداع',
  site_description: 'الموقع الرسمي لمدرسة النمارق للتعليم الأساسي في سلطنة عُمان: أخبار المدرسة وفعالياتها ومبادراتها وإنجازاتها، والجداول والتقويم المدرسي، وركن ولي الأمر، والمكتبة التعليمية.',
  seo_keywords: 'مدرسة النمارق، التعليم الأساسي، سلطنة عمان، أخبار المدرسة، الجداول المدرسية، التقويم المدرسي',
  hero_title: 'نبض النمارق',
  hero_subtitle: 'بيئة تعليمية عُمانية أصيلة، تصنع المتعلم المبدع المعتز بهويته، المنفتح على العالم.',
  hero_image: '/img/hero-campus.svg',
  og_image: '/img/og-image.png',
  vision: 'متعلم مبدع، معتز بقيمه وهويته العُمانية، قادر على المنافسة وصناعة المستقبل.',
  mission: 'نلتزم بتقديم تعليم نوعي في بيئة آمنة ومحفزة، توظف التقنية وأساليب التعلم الحديثة، وتشرك الأسرة والمجتمع في بناء شخصية المتعلم علميًا وقيميًا ومهاريًا.',
  goals: 'رفع مستوى التحصيل الدراسي وتحسين نواتج التعلم\nتنمية مهارات التفكير الناقد والإبداعي وحل المشكلات\nتعزيز الهوية الوطنية والقيم الإسلامية والعُمانية الأصيلة\nتوظيف التقنيات الحديثة في التعليم والتعلم\nبناء شراكة فاعلة مع أولياء الأمور ومؤسسات المجتمع\nاكتشاف المواهب ورعايتها وتنميتها',
  values: 'الانتماء|الاعتزاز بالوطن وقيادته وهويته\nالإتقان|جودة في الأداء وحرص على التميز\nالإبداع|أفكار جديدة ومبادرات ملهمة\nالاحترام|تقدير الآخر وحسن التعامل\nالمسؤولية|التزام بالواجب وروح الفريق',
  history: 'مدرسة النمارق للتعليم الأساسي إحدى مدارس سلطنة عُمان، تحتضن طلبتها في بيئة تعليمية تجمع بين الأصالة والمعاصرة، وتسعى عبر برامجها ومبادراتها إلى أن تكون نبضًا حيًا للعلم والإبداع في مجتمعها.\n\n(نص تجريبي — يُحدَّث من لوحة التحكم ← الإعدادات ← عن المدرسة)',
  principal_name: 'إدارة المدرسة',
  principal_message: 'أبناءنا الطلبة، أولياء الأمور الكرام، يسعدنا أن نرحب بكم في «نبض النمارق»، نافذتكم إلى حياة المدرسة اليومية. نؤمن أن التعليم شراكة بين المدرسة والأسرة والمجتمع، وأن كل طالب يحمل بذرة إبداع تنتظر من يرعاها.\n\n(كلمة تجريبية — تُحدَّث من لوحة التحكم)',
  contact_phone: '',
  contact_email: '',
  contact_address: 'سلطنة عُمان',
  contact_hours: 'الأحد – الخميس: 7:00 صباحًا – 2:00 ظهرًا',
  whatsapp: '',
  map_embed: '',
  social_x: '', social_instagram: '', social_youtube: '', social_facebook: '',
  demo_banner: '1',
  footer_note: 'جميع الحقوق محفوظة لمدرسة النمارق للتعليم الأساسي',
};

async function ensureBase() {
  await db.open();
  const s = await db.settings();
  if (s.base_ready === BASE_VERSION) return null;
  for (const [k, v] of Object.entries(DEFAULT_SETTINGS)) if (s[k] === undefined) await db.setSetting(k, v);

  for (const r of DEFAULT_ROLES) {
    const ex = await db.get('SELECT id FROM roles WHERE name = ?', r.name);
    if (!ex) await db.run('INSERT OR IGNORE INTO roles(name, label, permissions, is_system) VALUES (?,?,?,1)', r.name, r.label, JSON.stringify(r.permissions));
  }
  // مدير النظام يحصل دائمًا على كل الصلاحيات (بما فيها أي صلاحيات تُضاف لاحقًا)
  const adminRole = DEFAULT_ROLES.find((r) => r.name === 'admin');
  await db.run('UPDATE roles SET permissions = ? WHERE name = ?', JSON.stringify(adminRole.permissions), 'admin');

  if (!await db.get('SELECT id FROM academic_years')) {
    await db.insert('academic_years', { name: '2025/2026', starts_on: '2025-08-31', ends_on: '2026-06-25', is_current: 0 });
    await db.insert('academic_years', { name: '2026/2027', starts_on: '2026-08-30', ends_on: '2027-06-24', is_current: 1 });
  }

  let generated = null;
  if (!await db.get('SELECT id FROM users')) {
    const pw = config.adminPassword || (generated = crypto.randomBytes(9).toString('base64url') + '7a');
    const roleId = (await db.get("SELECT id FROM roles WHERE name = 'admin'")).id;
    await db.insert('users', { name: 'مدير النظام', email: config.adminEmail, password_hash: hashPassword(pw), role_id: roleId, must_change_password: generated ? 1 : 0 });
  }
  await db.setSetting('base_ready', BASE_VERSION);
  return generated;
}

// ===== المحتوى التجريبي =====
const P = (type, title, o) => ({ type, title, ...o });
function demoPosts(y1, y2) {
  const T = '\n\n> هذا محتوى تجريبي لأغراض العرض، ويمكن تعديله أو حذفه من لوحة التحكم.';
  return [
    P('news', 'انطلاق العام الدراسي 2026/2027 بأجواء من الحماس والتجديد', { category: 'إداري', cover: '/img/hero-campus.svg', featured: 1, published_at: '2026-08-30 05:00:00', y: y2,
      excerpt: 'استقبلت المدرسة طلبتها في يومهم الأول بفعاليات ترحيبية وبرنامج تهيئة للصفوف الأولى.',
      body: 'استقبلت مدرسة النمارق للتعليم الأساسي طلبتها مع انطلاق العام الدراسي الجديد، في أجواء احتفالية أعدّتها الهيئتان الإدارية والتدريسية.\n\n## برنامج اليوم الأول\n- طابور صباحي ترحيبي بمشاركة الطلبة الجدد\n- جولات تعريفية بمرافق المدرسة\n- لقاء مع أولياء أمور الصف الأول\n- توزيع الكتب والجداول الدراسية\n\nوأكدت إدارة المدرسة حرصها على تهيئة بيئة آمنة ومحفزة تُعين الطلبة على بداية موفقة.' + T }),
    P('news', 'طلبتنا يتألقون في مسابقة الروبوت على مستوى المحافظة', { category: 'تقني', cover: '/img/robotics.svg', featured: 1, published_at: '2026-10-21 06:00:00', y: y2,
      excerpt: 'فريق الروبوت بالمدرسة يقدّم مشروعًا مبتكرًا لفرز النفايات آليًا ويحظى بإشادة لجنة التحكيم.',
      body: 'شارك فريق نادي الروبوت بالمدرسة في المسابقة السنوية للروبوت على مستوى المحافظة بمشروع **«المُفرِز الذكي»** الذي يفرز النفايات القابلة لإعادة التدوير باستخدام الحساسات.\n\nوقد عمل الفريق على المشروع طوال شهرين بإشراف معلم تقنية المعلومات، متعلمين البرمجة والتصميم الهندسي والعمل بروح الفريق.' + T }),
    P('news', 'ورشة «القراءة الممتعة» لطلبة الحلقة الأولى', { category: 'ثقافي', cover: '/img/library.svg', published_at: '2026-11-05 06:30:00', y: y2,
      excerpt: 'مركز مصادر التعلم ينظم ورشة لتنمية حب القراءة لدى طلبة الصفوف 1–4.',
      body: 'نظّم مركز مصادر التعلم بالمدرسة ورشة «القراءة الممتعة» لطلبة الحلقة الأولى، تضمنت قراءة القصص التفاعلية وأنشطة الرسم المرتبطة بالقصة.' + T }),
    P('news', 'يوم رياضي مفتوح يعزز الصحة واللياقة', { category: 'رياضي', cover: '/img/sports.svg', published_at: '2026-10-08 07:00:00', y: y2,
      excerpt: 'منافسات رياضية بين الفصول بمشاركة واسعة من الطلبة والمعلمين.',
      body: 'أقامت المدرسة يومًا رياضيًا مفتوحًا تضمن سباقات الجري ومباريات كرة القدم والتتابع، وسط تشجيع من المعلمين وأولياء الأمور.' + T }),
    P('news', 'ختام العام الدراسي 2025/2026 وتكريم المتفوقين', { category: 'أكاديمي', cover: '/img/honoring.svg', published_at: '2026-06-20 06:00:00', y: y1,
      excerpt: 'حفل ختامي كرّمت فيه المدرسة الطلبة المجيدين والمتميزين في الأنشطة.',
      body: 'اختتمت المدرسة عامها الدراسي 2025/2026 بحفل كُرّم فيه الطلبة المتفوقون دراسيًا والمتميزون في الأنشطة المختلفة.' + T }),
    P('announcement', 'موعد اجتماع مجلس أولياء الأمور للفصل الدراسي الأول', { category: 'أولياء الأمور', cover: '/img/parents.svg', pinned: 1, published_at: '2026-11-10 05:00:00', y: y2,
      excerpt: 'ندعو أولياء الأمور الكرام لحضور الاجتماع الدوري لمناقشة مستويات الطلبة.',
      body: 'تدعو إدارة المدرسة أولياء الأمور الكرام لحضور الاجتماع الدوري لمجلس أولياء الأمور، لمناقشة نتائج التقويم المستمر وخطط دعم الطلبة.\n\n**المكان:** قاعة الأنشطة بالمدرسة' + T }),
    P('announcement', 'تعليمات اختبارات منتصف الفصل الدراسي الأول', { category: 'الاختبارات', cover: '/img/math.svg', published_at: '2026-11-12 05:00:00', y: y2,
      excerpt: 'إرشادات مهمة للطلبة وأولياء الأمور قبل فترة الاختبارات.',
      body: '## تعليمات عامة\n1. الحضور قبل بدء الاختبار بعشر دقائق\n2. إحضار الأدوات اللازمة (أقلام، مسطرة، آلة حاسبة عند الحاجة)\n3. الالتزام بالهدوء داخل قاعة الاختبار\n4. مراجعة جدول الاختبارات في قسم الجداول المدرسية' + T }),
    P('initiative', 'مبادرة «مدرستي خضراء»', { category: 'بيئي', cover: '/img/environment.svg', featured: 1, published_at: '2026-09-20 06:00:00', y: y2, event_start: '2026-09-20 08:00', event_end: '2027-04-30 13:00',
      excerpt: 'مبادرة طلابية لزراعة الأشجار المحلية وتدوير المخلفات داخل المدرسة.',
      body: 'تهدف مبادرة «مدرستي خضراء» إلى ترسيخ الوعي البيئي لدى الطلبة من خلال:\n- زراعة أشجار محلية كالغاف والسدر في ساحات المدرسة\n- إنشاء ركن لإعادة التدوير في كل ممر\n- مسابقة «الفصل الأنظف» شهريًا' + T }),
    P('initiative', 'مشروع «قارئ النمارق»', { category: 'قرائي', cover: '/img/quran-arabic.svg', published_at: '2026-09-10 06:00:00', y: y2,
      excerpt: 'برنامج قرائي سنوي يحفز الطلبة على قراءة 20 كتابًا خلال العام.',
      body: 'مشروع قرائي يرافق الطالب طوال العام، يوثّق فيه قراءاته في «جواز القارئ»، ويُكرَّم المتميزون في نهاية كل فصل دراسي.' + T }),
    P('initiative', 'نادي المبتكرين الصغار', { category: 'ابتكار', cover: '/img/science-lab.svg', published_at: '2026-09-25 06:00:00', y: y2,
      excerpt: 'مساحة أسبوعية لتصميم النماذج والتجارب العلمية بإشراف معلمي العلوم.',
      body: 'يجتمع أعضاء النادي أسبوعيًا لتنفيذ تجارب علمية وتصميم نماذج مبتكرة تمهيدًا للمشاركة في المعارض العلمية.' + T }),
    P('initiative', 'مبادرة «صديق التقنية»', { category: 'مبادرة طلابية', cover: '/img/digital.svg', published_at: '2026-10-01 06:00:00', y: y2,
      excerpt: 'طلبة الحلقة الثانية يساعدون زملاءهم الأصغر في استخدام المنصات التعليمية.',
      body: 'يتطوع طلبة الصفوف العليا لمساعدة زملائهم في الصفوف الأولى على استخدام المنصات التعليمية الرقمية بأمان.' + T }),
    P('event', 'احتفال المدرسة بالعيد الوطني المجيد', { category: 'وطنية', cover: '/img/national-day.svg', featured: 1, published_at: '2026-11-01 05:00:00', y: y2, event_start: '2026-11-19 08:00', event_end: '2026-11-19 11:00', location: 'ساحة المدرسة',
      excerpt: 'فقرات وطنية وأوبريت ومعرض للتراث العُماني بمشاركة الطلبة وأولياء الأمور.',
      body: 'تحتفل المدرسة بالعيد الوطني المجيد ببرنامج حافل يشمل:\n- السلام السلطاني وتحية العلم\n- أوبريت وطني يقدمه طلبة المدرسة\n- معرض للحرف والأزياء التراثية العُمانية\n- مسابقات ثقافية عن تاريخ عُمان' + T }),
    P('event', 'المعرض العلمي السنوي', { category: 'علمية', cover: '/img/science-lab.svg', published_at: '2026-11-08 05:00:00', y: y2, event_start: '2026-12-10 09:00', event_end: '2026-12-10 12:30', location: 'قاعة الأنشطة',
      excerpt: 'يعرض الطلبة مشاريعهم العلمية وتجاربهم أمام لجنة تحكيم وزوار المعرض.',
      body: 'يقام المعرض العلمي السنوي لعرض مشاريع الطلبة في مجالات العلوم والرياضيات والتقنية، ويُفتح للزوار من أولياء الأمور.' + T }),
    P('event', 'أسبوع القراءة', { category: 'ثقافية', cover: '/img/library.svg', published_at: '2026-11-10 05:00:00', y: y2, event_start: '2027-01-17 07:30', event_end: '2027-01-21 13:00', location: 'مركز مصادر التعلم',
      excerpt: 'أسبوع حافل بالمسابقات القرائية واستضافة الكتّاب ومعرض الكتاب المدرسي.',
      body: 'برنامج أسبوع القراءة يتضمن معرضًا للكتاب، ومسابقة «تحدي القراءة»، وجلسات قراءة جماعية في الفصول.' + T }),
    P('event', 'معرض الفنون التشكيلية', { category: 'فنية', cover: '/img/art.svg', published_at: '2026-10-12 05:00:00', y: y2, event_start: '2026-10-15 08:00', event_end: '2026-10-15 12:00', location: 'ممر الفنون',
      excerpt: 'لوحات وأعمال فنية من إبداع طلبة المدرسة.',
      body: 'عرضت المدرسة أكثر من خمسين عملًا فنيًا لطلبتها، تنوعت بين الرسم والتشكيل والخط العربي.' + T }),
    P('achievement', 'المركز الأول في مسابقة الروبوت على مستوى المحافظة', { category: 'على مستوى المحافظة', cover: '/img/robotics.svg', featured: 1, published_at: '2026-10-22 06:00:00', y: y2, event_start: '2026-10-20',
      excerpt: 'فريق المدرسة يحصد المركز الأول بمشروع «المُفرِز الذكي».', body: 'حقق فريق نادي الروبوت المركز الأول في المسابقة على مستوى المحافظة.' + T }),
    P('achievement', 'تكريم المدرسة ضمن المدارس المتميزة في الأنشطة البيئية', { category: 'على مستوى السلطنة', cover: '/img/environment.svg', published_at: '2026-05-12 06:00:00', y: y1, event_start: '2026-05-10',
      excerpt: 'إشادة بمبادرات المدرسة البيئية وأثرها في المجتمع المحلي.', body: 'نالت المدرسة تكريمًا تقديرًا لمبادراتها البيئية.' + T }),
    P('achievement', 'طالبة من المدرسة تفوز في مسابقة الخطابة', { category: 'على مستوى المحافظة', cover: '/img/honoring.svg', published_at: '2026-03-03 06:00:00', y: y1, event_start: '2026-03-01',
      excerpt: 'فوز مستحق في مسابقة الخطابة والإلقاء.', body: 'فازت إحدى طالبات الصف التاسع بالمركز الثاني في مسابقة الخطابة والإلقاء.' + T }),
    P('achievement', 'تكريم معلمي المدرسة المجيدين', { category: 'تكريم معلمين', cover: '/img/classroom.svg', published_at: '2026-02-24 06:00:00', y: y1, event_start: '2026-02-24',
      excerpt: 'تكريم المعلمين المجيدين تقديرًا لعطائهم.', body: 'كرمت إدارة المدرسة نخبة من المعلمين المجيدين تقديرًا لجهودهم في تجويد التعليم.' + T }),
    P('library', 'أوراق عمل الرياضيات — الصف الخامس (الوحدة الأولى)', { category: 'أوراق عمل', cover: '/img/math.svg', published_at: '2026-09-15 06:00:00', y: y2, tags: 'الصف الخامس، رياضيات', attachment: '/files/demo/worksheet-math-g5.pdf',
      excerpt: 'تدريبات متدرجة على الأعداد والعمليات الحسابية.', body: 'مجموعة أوراق عمل لتدريب طلبة الصف الخامس على مهارات الوحدة الأولى.' + T }),
    P('library', 'ملخص العلوم — الصف الثامن: الخلية', { category: 'ملخصات', cover: '/img/science-lab.svg', published_at: '2026-10-02 06:00:00', y: y2, tags: 'الصف الثامن، علوم', attachment: '/files/demo/summary-science-g8.pdf',
      excerpt: 'ملخص مركز لدرس الخلية ومكوناتها.', body: 'ملخص يساعد الطالب على مراجعة درس الخلية قبل الاختبار.' + T }),
    P('library', 'قصص قصيرة للحلقة الأولى', { category: 'كتب وقصص', cover: '/img/library.svg', published_at: '2026-10-05 06:00:00', y: y2, tags: 'الحلقة الأولى، قراءة', attachment: '/files/demo/short-stories.pdf',
      excerpt: 'قصص قصيرة هادفة لتنمية مهارات القراءة.', body: 'مجموعة قصص قصيرة مختارة لطلبة الصفوف 1–4.' + T }),
    P('library', 'دليل الاستخدام الآمن للإنترنت', { category: 'عروض تقديمية', cover: '/img/digital.svg', published_at: '2026-10-18 06:00:00', y: y2, tags: 'المواطنة الرقمية', attachment: '/files/demo/internet-safety.pdf',
      excerpt: 'إرشادات للطلبة حول السلامة الرقمية.', body: 'عرض مبسّط يوضح قواعد الاستخدام الآمن للإنترنت.' + T }),
    P('guide', 'كيف تتابع مستوى ابنك الدراسي؟', { category: 'متابعة دراسية', cover: '/img/parents.svg', published_at: '2026-09-05 06:00:00', y: y2,
      excerpt: 'خطوات عملية لمتابعة التحصيل الدراسي بالتعاون مع المدرسة.',
      body: '## خطوات مقترحة\n1. خصص وقتًا يوميًا قصيرًا للحديث مع ابنك عن يومه الدراسي\n2. راجع الواجبات والملاحظات أسبوعيًا\n3. تواصل مع المعلمين عبر قنوات المدرسة الرسمية\n4. احضر اجتماعات مجلس أولياء الأمور\n5. احتفِ بالإنجازات الصغيرة قبل الكبيرة' + T }),
    P('guide', 'ما مواعيد الدوام المدرسي؟', { category: 'أسئلة شائعة', published_at: '2026-09-01 06:00:00', y: y2,
      excerpt: 'يبدأ الدوام المدرسي يوميًا من الأحد إلى الخميس.', body: 'يبدأ الطابور الصباحي الساعة 7:00 صباحًا، وينتهي الدوام الساعة 1:30 ظهرًا (مواعيد تجريبية تُحدَّث من لوحة التحكم).' + T }),
    P('guide', 'كيف أبلغ المدرسة عن غياب ابني؟', { category: 'أسئلة شائعة', published_at: '2026-09-01 06:10:00', y: y2,
      excerpt: 'يمكن الإبلاغ عبر نموذج «تواصل معنا» أو الاتصال بالإدارة.', body: 'يمكنكم إبلاغ المدرسة عبر صفحة «تواصل معنا» مع ذكر اسم الطالب وصفّه وسبب الغياب، وتقديم العذر المكتوب عند العودة.' + T }),
    P('guide', 'نصائح للنوم الصحي والتغذية السليمة', { category: 'صحة ورفاه', cover: '/img/sports.svg', published_at: '2026-10-10 06:00:00', y: y2,
      excerpt: 'عادات بسيطة تصنع فرقًا كبيرًا في تركيز الطالب.', body: '- النوم المبكر بمعدل 9–11 ساعة لطلبة المرحلة الأساسية\n- وجبة إفطار متوازنة قبل المدرسة\n- تقليل استخدام الشاشات قبل النوم\n- شرب الماء بانتظام خلال اليوم' + T }),
    P('partnership', 'شراكة مع مجلس أولياء الأمور لتطوير المرافق', { category: 'مجلس الآباء', cover: '/img/partnership.svg', published_at: '2026-10-25 06:00:00', y: y2, event_start: '2026-10-25',
      excerpt: 'مبادرة مشتركة لتجميل الساحات وتجهيز ركن القراءة الخارجي.', body: 'تعاون مجلس أولياء الأمور مع إدارة المدرسة في تجهيز ركن القراءة الخارجي وتظليل الساحات.' + T }),
    P('partnership', 'برنامج التوعية الصحية بالتعاون مع المركز الصحي', { category: 'مؤسسة حكومية', cover: '/img/parents.svg', published_at: '2026-10-14 06:00:00', y: y2, event_start: '2026-10-14',
      excerpt: 'محاضرات وفحوصات توعوية للطلبة بالتعاون مع المركز الصحي.', body: 'نُفّذ برنامج توعوي صحي يشمل محاضرات عن التغذية والنظافة الشخصية.' + T }),
    P('partnership', 'يوم تطوعي لخدمة المجتمع المحلي', { category: 'تطوع', cover: '/img/environment.svg', published_at: '2026-04-02 06:00:00', y: y1, event_start: '2026-04-02',
      excerpt: 'الطلبة يشاركون في حملة نظافة وتشجير في الحي.', body: 'شارك الطلبة وأولياء الأمور في حملة نظافة وتشجير بالحي المجاور للمدرسة.' + T }),
  ];
}

async function seedDemo() {
  // قفل بسيط يمنع تكرار الإدخال عند تشغيل نسختين معًا
  const lock = await db.run("INSERT OR IGNORE INTO settings(key, value) VALUES ('demo_seeded', '1')");
  if (!lock.changes || await db.get('SELECT id FROM posts LIMIT 1')) return false;
  const y1 = (await db.get("SELECT id FROM academic_years WHERE name = '2025/2026'"))?.id || null;
  const y2 = (await db.currentYear())?.id || null;
  const admin = await db.get('SELECT id FROM users ORDER BY id LIMIT 1');
  await db.tx(async () => {
    for (const p of demoPosts(y1, y2)) {
      const row = {
        type: p.type, title: p.title, slug: slugify(p.title), excerpt: p.excerpt, body: p.body, cover: p.cover || null, cover_alt: p.cover ? p.title : null,
        category: p.category || null, tags: p.tags || null, status: 'published', featured: p.featured || 0, pinned: p.pinned || 0,
        academic_year_id: p.y, event_start: p.event_start || null, event_end: p.event_end || null, location: p.location || null,
        attachment: p.attachment || null, external_url: p.external_url || null, author_id: admin?.id || null, published_at: p.published_at,
        views: Math.floor(Math.random() * 300) + 20, is_demo: 1,
        created_at: p.published_at, updated_at: p.published_at,
      };
      row.search_text = db.postSearchText(row);
      await db.insert('posts', row);
    }

    const gal = [
      ['hero-campus', 'مبنى المدرسة', 'المرافق'], ['classroom', 'حصة رياضيات تفاعلية', 'الحياة الصفية'], ['library', 'مركز مصادر التعلم', 'المرافق'],
      ['science-lab', 'مختبر العلوم', 'المرافق'], ['robotics', 'نادي الروبوت', 'الأنشطة'], ['sports', 'اليوم الرياضي', 'الأنشطة'],
      ['art', 'معرض الفنون', 'الأنشطة'], ['national-day', 'احتفالات العيد الوطني', 'المناسبات الوطنية'], ['environment', 'مبادرة مدرستي خضراء', 'المبادرات'],
      ['honoring', 'حفل التكريم', 'المناسبات'], ['parents', 'مجلس أولياء الأمور', 'المناسبات'], ['digital', 'التعلم الرقمي', 'الحياة الصفية'],
    ];
    for (const [i, [f, t, a]] of gal.entries()) await db.insert('gallery', { kind: 'image', title: t, album: a, file: `/img/${f}.svg`, academic_year_id: y2, sort: i, is_demo: 1 });
    await db.insert('gallery', { kind: 'video', title: 'جولة مصورة في مرافق المدرسة', description: 'مقطع تجريبي قصير', album: 'المرافق', file: '/files/demo/school-tour.mp4', academic_year_id: y2, sort: 20, is_demo: 1 });

    const subjectsG5 = ['تربية إسلامية', 'لغة عربية', 'رياضيات', 'علوم', 'لغة إنجليزية', 'دراسات اجتماعية', 'فنون تشكيلية', 'رياضة مدرسية', 'تقنية المعلومات', 'مهارات موسيقية'];
    const mkGrid = (subs, seed) => ({
      periods: ['7:20 – 8:00', '8:00 – 8:40', '8:40 – 9:20', '9:40 – 10:20', '10:20 – 11:00', '11:00 – 11:40', '11:50 – 12:30', '12:30 – 1:10'],
      cells: Array.from({ length: 5 }, (_, d) => Array.from({ length: 8 }, (_, p) => (p === 7 && d % 2 ? '' : subs[(d * 3 + p * 2 + seed) % subs.length]))),
    });
    await db.insert('schedules', { title: 'جدول حصص الصف الخامس / 1', kind: 'class', grade: 'الصف الخامس', section: '1', academic_year_id: y2, grid: JSON.stringify(mkGrid(subjectsG5, 1)), notes: 'جدول تجريبي', is_demo: 1, sort: 1 });
    await db.insert('schedules', { title: 'جدول حصص الصف التاسع / 2', kind: 'class', grade: 'الصف التاسع', section: '2', academic_year_id: y2, grid: JSON.stringify(mkGrid(['تربية إسلامية', 'لغة عربية', 'رياضيات', 'علوم', 'لغة إنجليزية', 'دراسات اجتماعية', 'رياضة مدرسية', 'تقنية المعلومات', 'المهارات الحياتية'], 4)), notes: 'جدول تجريبي', is_demo: 1, sort: 2 });
    await db.insert('schedules', {
      title: 'جدول اختبارات منتصف الفصل الأول — الحلقة الثانية', kind: 'exam', grade: 'جميع الصفوف', academic_year_id: y2, is_demo: 1, sort: 3, notes: 'تبدأ الاختبارات في الحصة الثانية. جدول تجريبي.',
      grid: JSON.stringify({ periods: ['الصف الخامس', 'الصف السادس', 'الصف السابع', 'الصف الثامن', 'الصف التاسع'], cells: [
        ['رياضيات', 'لغة عربية', 'علوم', 'رياضيات', 'لغة إنجليزية'], ['لغة عربية', 'رياضيات', 'لغة إنجليزية', 'علوم', 'رياضيات'],
        ['علوم', 'لغة إنجليزية', 'رياضيات', 'لغة عربية', 'علوم'], ['لغة إنجليزية', 'علوم', 'لغة عربية', 'لغة إنجليزية', 'لغة عربية'],
        ['دراسات اجتماعية', 'تربية إسلامية', 'دراسات اجتماعية', 'تربية إسلامية', 'دراسات اجتماعية']], dayLabels: ['الأحد 29 نوفمبر', 'الاثنين 30 نوفمبر', 'الثلاثاء 1 ديسمبر', 'الأربعاء 2 ديسمبر', 'الخميس 3 ديسمبر'] }),
    });

    const cal = [
      ['بداية الفصل الدراسي الأول للطلبة', 'term', '2026-08-30', null], ['اختبارات منتصف الفصل الأول', 'exam', '2026-11-29', '2026-12-03'],
      ['إجازة العيد الوطني', 'holiday', '2026-11-22', '2026-11-23'], ['اجتماع مجلس أولياء الأمور', 'meeting', '2026-11-25', null],
      ['اختبارات نهاية الفصل الأول', 'exam', '2027-01-03', '2027-01-14'], ['إجازة منتصف العام', 'holiday', '2027-01-24', '2027-02-04'],
      ['بداية الفصل الدراسي الثاني', 'term', '2027-02-07', null], ['اليوم المفتوح للأسر', 'event', '2026-12-17', null],
    ];
    for (const [t, k, s, e] of cal) await db.insert('calendar_items', { title: t, kind: k, starts_on: s, ends_on: e, description: 'موعد تجريبي — يُحدَّث وفق التقويم الرسمي المعتمد.', academic_year_id: y2, is_demo: 1 });

    const staff = [
      ['أ. سالم بن راشد الحارثي', 'مدير المدرسة', 'الإدارة', 'man'], ['أ. مريم بنت سعيد البلوشية', 'مساعدة المدير', 'الإدارة', 'woman'],
      ['أ. خالد بن حمد العامري', 'مشرف الشؤون الطلابية', 'شؤون الطلبة', 'man'], ['أ. فاطمة بنت علي الكندية', 'أخصائية التوجيه المهني', 'التوجيه والإرشاد', 'woman'],
      ['أ. يوسف بن ناصر الرواحي', 'أخصائي مصادر التعلم', 'مركز مصادر التعلم', 'man'], ['أ. عائشة بنت محمد الهنائية', 'الأخصائية الاجتماعية', 'التوجيه والإرشاد', 'woman'],
    ];
    for (const [i, [n, p, d, g]] of staff.entries()) await db.insert('staff', { name: n + ' (اسم تجريبي)', position: p, department: d, photo: `/img/avatar-${g}.svg`, sort: i, is_demo: 1 });

    for (const [i, [l, v, sfx, ic]] of [['طالب وطالبة', 620, '', 'users'], ['معلم ومعلمة', 48, '', 'teacher'], ['نشاط وفعالية سنويًا', 85, '+', 'spark'], ['جائزة وتكريم', 32, '+', 'trophy']].entries())
      await db.insert('stats', { label: l, value: v, suffix: sfx, icon: ic, sort: i, is_demo: 1 });

    await db.insert('alerts', { message: 'اختبارات منتصف الفصل الدراسي الأول تبدأ يوم الأحد 29 نوفمبر — راجعوا جدول الاختبارات (تنبيه تجريبي)', link: '/schedules', level: 'warning', active: 1, is_demo: 1 });

    const sid = await db.insert('surveys', { title: 'استبانة رضا أولياء الأمور — الفصل الأول', description: 'رأيكم يهمنا لتطوير خدمات المدرسة. تستغرق الاستبانة دقيقتين فقط. (استبانة تجريبية)', status: 'open', academic_year_id: y2, is_demo: 1 });
    const qs = [
      ['ما مدى رضاك عن التواصل بين المدرسة والأسرة؟', 'rating', null], ['ما مدى رضاك عن مستوى الأنشطة المدرسية؟', 'rating', null],
      ['ما أكثر قناة تفضل أن تصلك عبرها أخبار المدرسة؟', 'single', ['الموقع الإلكتروني', 'واتساب', 'الرسائل النصية', 'الاجتماعات المباشرة']],
      ['ما المجالات التي تقترح تعزيزها؟', 'multi', ['الأنشطة الرياضية', 'البرامج القرائية', 'التقنية والروبوت', 'الدعم الأكاديمي', 'البرامج الإرشادية']],
      ['ملاحظات أو مقترحات إضافية', 'text', null],
    ];
    const qids = [];
    for (const [i, [t, k, o]] of qs.entries()) qids.push(await db.insert('survey_questions', { survey_id: sid, text: t, qtype: k, options: o ? JSON.stringify(o) : null, required: k === 'text' ? 0 : 1, sort: i }));
    const opts3 = qs[2][2], opts4 = qs[3][2];
    for (let i = 0; i < 14; i++) {
      const a = {};
      a[qids[0]] = String(3 + (i % 3)); a[qids[1]] = String(2 + ((i * 2) % 4));
      a[qids[2]] = opts3[i % 4]; a[qids[3]] = [opts4[i % 5], opts4[(i + 2) % 5]]; a[qids[4]] = i % 4 === 0 ? 'شكرًا لجهود المدرسة (رد تجريبي)' : '';
      await db.insert('survey_responses', { survey_id: sid, answers: JSON.stringify(a), ip_hash: 'demo-' + i });
    }

    await db.insert('messages', { name: 'ولي أمر (رسالة تجريبية)', email: 'parent@example.com', subject: 'استفسار عن النقل المدرسي', message: 'السلام عليكم، أود الاستفسار عن مواعيد الحافلات المدرسية. شكرًا لكم.' });
    await db.insert('suggestions', { name: 'ولية أمر (مقترح تجريبي)', student_grade: 'الصف الثالث', category: 'اقتراح', message: 'أقترح تخصيص ركن للقراءة في كل فصل دراسي للصفوف الأولى.' });
  });
  return true;
}

async function removeDemo() {
  const tables = ['posts', 'gallery', 'schedules', 'calendar_items', 'staff', 'stats', 'alerts', 'surveys'];
  const counts = {};
  await db.tx(async () => {
    for (const t of tables) counts[t] = Number((await db.run(`DELETE FROM ${t} WHERE is_demo = 1`)).changes);
    counts.messages = Number((await db.run("DELETE FROM messages WHERE name LIKE '%تجريبية%'")).changes);
    counts.suggestions = Number((await db.run("DELETE FROM suggestions WHERE name LIKE '%تجريبي%'")).changes);
  });
  await db.setSetting('demo_banner', '0');
  return counts;
}

module.exports = { ensureBase, seedDemo, removeDemo, DEFAULT_SETTINGS };
