'use strict';
// تعريف أنواع المحتوى والأدوار والصلاحيات

const TYPES = {
  news: {
    label: 'الأخبار', single: 'خبر', path: '/news', icon: 'news',
    categories: ['أكاديمي', 'ثقافي', 'رياضي', 'تقني', 'إداري', 'مجتمعي'],
    fields: ['category', 'tags', 'attachment'],
  },
  announcement: {
    label: 'الإعلانات', single: 'إعلان', path: '/news', icon: 'megaphone',
    categories: ['عام', 'أولياء الأمور', 'الطلبة', 'الاختبارات', 'إجازات'],
    fields: ['category', 'attachment'],
  },
  initiative: {
    label: 'المبادرات والمشاريع', single: 'مبادرة / مشروع', path: '/initiatives', icon: 'spark',
    categories: ['مبادرة طلابية', 'مشروع تعليمي', 'بيئي', 'تطوعي', 'ابتكار', 'قرائي'],
    fields: ['category', 'tags', 'attachment', 'event_start', 'event_end'],
  },
  event: {
    label: 'الفعاليات والأنشطة', single: 'فعالية', path: '/events', icon: 'calendar',
    categories: ['وطنية', 'ثقافية', 'رياضية', 'علمية', 'فنية', 'دينية', 'مجتمعية'],
    fields: ['category', 'event_start', 'event_end', 'location', 'attachment'],
  },
  achievement: {
    label: 'الإنجازات والتكريم', single: 'إنجاز', path: '/achievements', icon: 'trophy',
    categories: ['على مستوى المحافظة', 'على مستوى السلطنة', 'دولي', 'داخل المدرسة', 'تكريم معلمين'],
    fields: ['category', 'tags', 'event_start'],
  },
  library: {
    label: 'المكتبة التعليمية', single: 'مصدر تعليمي', path: '/library', icon: 'book',
    categories: ['أوراق عمل', 'ملخصات', 'عروض تقديمية', 'كتب وقصص', 'فيديوهات تعليمية', 'روابط مفيدة', 'نماذج اختبارات'],
    fields: ['category', 'tags', 'attachment', 'external_url'],
  },
  guide: {
    label: 'ركن ولي الأمر', single: 'دليل / مقال لولي الأمر', path: '/parents', icon: 'family',
    categories: ['إرشادات', 'أسئلة شائعة', 'صحة ورفاه', 'متابعة دراسية', 'لوائح وأنظمة', 'نماذج'],
    fields: ['category', 'attachment'],
  },
  partnership: {
    label: 'الشراكة المجتمعية', single: 'شراكة', path: '/partnerships', icon: 'handshake',
    categories: ['مؤسسة حكومية', 'قطاع خاص', 'مجلس الآباء', 'جمعية أهلية', 'تطوع'],
    fields: ['category', 'external_url', 'event_start'],
  },
};

const STATUSES = {
  draft: { label: 'مسودة', cls: 'gray' },
  review: { label: 'بانتظار المراجعة', cls: 'amber' },
  published: { label: 'منشور', cls: 'green' },
  archived: { label: 'مؤرشف', cls: 'navy' },
};

const PERMISSIONS = {
  'dashboard.view': 'عرض لوحة المعلومات',
  'content.create': 'إنشاء محتوى',
  'content.edit_own': 'تعديل المحتوى الخاص به',
  'content.edit_all': 'تعديل كل المحتوى',
  'content.publish': 'نشر / مراجعة المحتوى',
  'content.delete': 'حذف المحتوى',
  'media.upload': 'رفع الصور والملفات',
  'media.manage': 'إدارة مكتبة الوسائط وحذفها',
  'gallery.manage': 'إدارة المعرض الإعلامي',
  'schedules.manage': 'إدارة الجداول المدرسية',
  'calendar.manage': 'إدارة التقويم المدرسي',
  'staff.manage': 'إدارة الهيئة الإدارية',
  'stats.manage': 'إدارة الإحصائيات',
  'alerts.manage': 'إدارة الإشعارات العاجلة',
  'surveys.manage': 'إدارة الاستبانات ونتائجها',
  'inbox.manage': 'إدارة الرسائل والمقترحات',
  'years.manage': 'إدارة الأعوام الدراسية',
  'users.manage': 'إدارة المستخدمين',
  'roles.manage': 'إدارة الأدوار والصلاحيات',
  'settings.manage': 'إدارة إعدادات الموقع',
  'logs.view': 'عرض سجل العمليات',
};

const ALL = Object.keys(PERMISSIONS);
const DEFAULT_ROLES = [
  { name: 'admin', label: 'مدير النظام', permissions: ALL },
  {
    name: 'editor', label: 'محرر رئيسي', permissions: ALL.filter((p) => !['users.manage', 'roles.manage', 'settings.manage', 'years.manage'].includes(p)),
  },
  { name: 'reviewer', label: 'مراجع محتوى', permissions: ['dashboard.view', 'content.edit_all', 'content.publish', 'media.upload', 'logs.view'] },
  { name: 'author', label: 'كاتب محتوى', permissions: ['dashboard.view', 'content.create', 'content.edit_own', 'media.upload'] },
];

const CALENDAR_KINDS = {
  event: { label: 'فعالية', color: 'teal' },
  exam: { label: 'اختبارات', color: 'red' },
  holiday: { label: 'إجازة', color: 'gold' },
  meeting: { label: 'اجتماع', color: 'navy' },
  term: { label: 'بداية/نهاية فصل', color: 'violet' },
};
const SCHEDULE_KINDS = { class: 'جدول الحصص', exam: 'جدول الاختبارات', duty: 'جدول المناوبة والإشراف', activity: 'جدول الأنشطة' };
const GRADES = ['الصف الأول', 'الصف الثاني', 'الصف الثالث', 'الصف الرابع', 'الصف الخامس', 'الصف السادس', 'الصف السابع', 'الصف الثامن', 'الصف التاسع', 'الصف العاشر', 'جميع الصفوف'];
const DAYS = ['الأحد', 'الاثنين', 'الثلاثاء', 'الأربعاء', 'الخميس'];

module.exports = { TYPES, STATUSES, PERMISSIONS, DEFAULT_ROLES, CALENDAR_KINDS, SCHEDULE_KINDS, GRADES, DAYS };
