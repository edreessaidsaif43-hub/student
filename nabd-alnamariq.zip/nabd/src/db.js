'use strict';
// قاعدة البيانات: محركان بنفس الواجهة (async)
//  - محلي: SQLite المدمج في Node.js (node:sqlite) — بدون أي حزمة
//  - سحابي: Turso / libSQL عبر واجهة HTTP (عند ضبط TURSO_DATABASE_URL) — مناسب لـ Vercel
const fs = require('node:fs');
const path = require('node:path');
const config = require('./config');
const { normalizeAr } = require('./core/util');

const SCHEMA = `
CREATE TABLE IF NOT EXISTS schema_version (version INTEGER NOT NULL);

CREATE TABLE IF NOT EXISTS settings (
  key TEXT PRIMARY KEY,
  value TEXT
);

CREATE TABLE IF NOT EXISTS roles (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL UNIQUE,
  label TEXT NOT NULL,
  permissions TEXT NOT NULL DEFAULT '[]',
  is_system INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  email TEXT NOT NULL UNIQUE COLLATE NOCASE,
  password_hash TEXT NOT NULL,
  role_id INTEGER NOT NULL REFERENCES roles(id),
  active INTEGER NOT NULL DEFAULT 1,
  must_change_password INTEGER NOT NULL DEFAULT 0,
  last_login_at TEXT,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS sessions (
  id TEXT PRIMARY KEY,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  csrf TEXT NOT NULL,
  ip TEXT,
  user_agent TEXT,
  expires_at TEXT NOT NULL,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS academic_years (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL UNIQUE,
  starts_on TEXT,
  ends_on TEXT,
  is_current INTEGER NOT NULL DEFAULT 0
);

CREATE TABLE IF NOT EXISTS posts (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  type TEXT NOT NULL,
  title TEXT NOT NULL,
  slug TEXT NOT NULL,
  excerpt TEXT,
  body TEXT,
  cover TEXT,
  cover_alt TEXT,
  category TEXT,
  tags TEXT,
  status TEXT NOT NULL DEFAULT 'draft',
  featured INTEGER NOT NULL DEFAULT 0,
  pinned INTEGER NOT NULL DEFAULT 0,
  academic_year_id INTEGER REFERENCES academic_years(id) ON DELETE SET NULL,
  event_start TEXT,
  event_end TEXT,
  location TEXT,
  attachment TEXT,
  external_url TEXT,
  author_id INTEGER REFERENCES users(id) ON DELETE SET NULL,
  reviewer_id INTEGER REFERENCES users(id) ON DELETE SET NULL,
  review_note TEXT,
  published_at TEXT,
  views INTEGER NOT NULL DEFAULT 0,
  is_demo INTEGER NOT NULL DEFAULT 0,
  search_text TEXT,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at TEXT NOT NULL DEFAULT (datetime('now')),
  UNIQUE(type, slug)
);
CREATE INDEX IF NOT EXISTS idx_posts_type_status ON posts(type, status, published_at);
CREATE INDEX IF NOT EXISTS idx_posts_year ON posts(academic_year_id);
CREATE INDEX IF NOT EXISTS idx_posts_event ON posts(event_start);

CREATE TABLE IF NOT EXISTS post_revisions (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  post_id INTEGER NOT NULL REFERENCES posts(id) ON DELETE CASCADE,
  snapshot TEXT NOT NULL,
  user_id INTEGER REFERENCES users(id) ON DELETE SET NULL,
  user_name TEXT,
  note TEXT,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS files (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  original_name TEXT NOT NULL,
  path TEXT NOT NULL UNIQUE,
  mime TEXT NOT NULL,
  size INTEGER NOT NULL,
  kind TEXT NOT NULL,
  alt TEXT,
  uploaded_by INTEGER REFERENCES users(id) ON DELETE SET NULL,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS gallery (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  kind TEXT NOT NULL DEFAULT 'image',
  title TEXT NOT NULL,
  description TEXT,
  album TEXT,
  file TEXT,
  video_url TEXT,
  academic_year_id INTEGER REFERENCES academic_years(id) ON DELETE SET NULL,
  status TEXT NOT NULL DEFAULT 'published',
  sort INTEGER NOT NULL DEFAULT 0,
  is_demo INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS schedules (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  title TEXT NOT NULL,
  kind TEXT NOT NULL DEFAULT 'class',
  grade TEXT,
  section TEXT,
  academic_year_id INTEGER REFERENCES academic_years(id) ON DELETE SET NULL,
  grid TEXT,
  attachment TEXT,
  notes TEXT,
  status TEXT NOT NULL DEFAULT 'published',
  sort INTEGER NOT NULL DEFAULT 0,
  is_demo INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS calendar_items (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  title TEXT NOT NULL,
  kind TEXT NOT NULL DEFAULT 'event',
  starts_on TEXT NOT NULL,
  ends_on TEXT,
  description TEXT,
  academic_year_id INTEGER REFERENCES academic_years(id) ON DELETE SET NULL,
  status TEXT NOT NULL DEFAULT 'published',
  is_demo INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_cal_dates ON calendar_items(starts_on, ends_on);

CREATE TABLE IF NOT EXISTS staff (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  position TEXT NOT NULL,
  department TEXT,
  photo TEXT,
  bio TEXT,
  sort INTEGER NOT NULL DEFAULT 0,
  status TEXT NOT NULL DEFAULT 'published',
  is_demo INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS stats (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  label TEXT NOT NULL,
  value INTEGER NOT NULL DEFAULT 0,
  suffix TEXT,
  icon TEXT,
  sort INTEGER NOT NULL DEFAULT 0,
  is_demo INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS alerts (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  message TEXT NOT NULL,
  link TEXT,
  level TEXT NOT NULL DEFAULT 'info',
  starts_at TEXT,
  ends_at TEXT,
  active INTEGER NOT NULL DEFAULT 1,
  is_demo INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS messages (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  email TEXT,
  phone TEXT,
  subject TEXT,
  message TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'new',
  admin_note TEXT,
  ip TEXT,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS suggestions (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT,
  phone TEXT,
  student_grade TEXT,
  category TEXT NOT NULL DEFAULT 'اقتراح',
  message TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'new',
  admin_note TEXT,
  ip TEXT,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS surveys (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  title TEXT NOT NULL,
  description TEXT,
  status TEXT NOT NULL DEFAULT 'draft',
  academic_year_id INTEGER REFERENCES academic_years(id) ON DELETE SET NULL,
  starts_on TEXT,
  ends_on TEXT,
  is_demo INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS survey_questions (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  survey_id INTEGER NOT NULL REFERENCES surveys(id) ON DELETE CASCADE,
  text TEXT NOT NULL,
  qtype TEXT NOT NULL DEFAULT 'rating',
  options TEXT,
  required INTEGER NOT NULL DEFAULT 1,
  sort INTEGER NOT NULL DEFAULT 0
);

CREATE TABLE IF NOT EXISTS survey_responses (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  survey_id INTEGER NOT NULL REFERENCES surveys(id) ON DELETE CASCADE,
  answers TEXT NOT NULL,
  ip_hash TEXT,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS file_blobs (
  file_id INTEGER PRIMARY KEY REFERENCES files(id) ON DELETE CASCADE,
  data BLOB NOT NULL
);

CREATE TABLE IF NOT EXISTS audit_log (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER,
  user_name TEXT,
  action TEXT NOT NULL,
  entity TEXT,
  entity_id INTEGER,
  details TEXT,
  ip TEXT,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_audit_created ON audit_log(created_at);
`;


// ===== المحرك المحلي =====
function localDriver(file) {
  const { DatabaseSync } = require('node:sqlite');
  if (file !== ':memory:') fs.mkdirSync(path.dirname(file), { recursive: true });
  const d = new DatabaseSync(file);
  d.exec('PRAGMA journal_mode = WAL; PRAGMA foreign_keys = ON; PRAGMA busy_timeout = 5000;');
  const fix = (r) => {
    if (!r) return r;
    for (const k in r) if (r[k] instanceof Uint8Array) r[k] = Buffer.from(r[k]);
    return r;
  };
  const norm = (p) => p.map((v) => (v === undefined ? null : typeof v === 'boolean' ? (v ? 1 : 0) : v));
  return {
    name: 'sqlite',
    async exec(sql) { d.exec(sql); },
    async get(sql, p) { return fix(d.prepare(sql).get(...norm(p))); },
    async all(sql, p) { return d.prepare(sql).all(...norm(p)).map(fix); },
    async run(sql, p) { const r = d.prepare(sql).run(...norm(p)); return { lastInsertRowid: Number(r.lastInsertRowid), changes: Number(r.changes) }; },
    close() { d.close(); },
  };
}

// ===== محرك Turso عبر HTTP (بدون حزم خارجية) =====
function tursoDriver(url, token) {
  const base = url.replace(/^libsql:\/\//, /^libsql:\/\/(127\.0\.0\.1|localhost)/.test(url) ? 'http://' : 'https://').replace(/\/+$/, '');
  const arg = (v) => {
    if (v === null || v === undefined) return { type: 'null' };
    if (typeof v === 'boolean') return { type: 'integer', value: v ? '1' : '0' };
    if (typeof v === 'number') return Number.isInteger(v) ? { type: 'integer', value: String(v) } : { type: 'float', value: v };
    if (typeof v === 'bigint') return { type: 'integer', value: v.toString() };
    if (v instanceof Uint8Array) return { type: 'blob', base64: Buffer.from(v).toString('base64') };
    return { type: 'text', value: String(v) };
  };
  const val = (c) => {
    if (!c || c.type === 'null') return null;
    if (c.type === 'integer') return Number(c.value);
    if (c.type === 'float') return Number(c.value);
    if (c.type === 'blob') return Buffer.from(c.base64 || '', 'base64');
    return c.value;
  };
  async function pipeline(stmts) {
    const body = { requests: stmts.map((s) => ({ type: 'execute', stmt: { sql: s.sql, args: (s.args || []).map(arg) } })).concat({ type: 'close' }) };
    let res, lastErr;
    for (let attempt = 0; attempt < 3; attempt++) {
      try {
        res = await fetch(base + '/v2/pipeline', { method: 'POST', headers: { Authorization: 'Bearer ' + token, 'Content-Type': 'application/json' }, body: JSON.stringify(body) });
        if (res.status >= 500) { lastErr = new Error('Turso HTTP ' + res.status); await new Promise((r) => setTimeout(r, 150 * (attempt + 1))); continue; }
        break;
      } catch (e) { lastErr = e; await new Promise((r) => setTimeout(r, 150 * (attempt + 1))); }
    }
    if (!res) throw lastErr;
    const json = await res.json().catch(() => ({}));
    if (!res.ok) throw new Error('Turso: ' + (json.message || res.status));
    return json.results.slice(0, stmts.length).map((r) => {
      if (r.type === 'error') throw new Error('SQL: ' + (r.error && r.error.message));
      return r.response.result;
    });
  }
  const rows = (r) => r.rows.map((row) => { const o = {}; r.cols.forEach((c, i) => { o[c.name] = val(row[i]); }); return o; });
  return {
    name: 'turso',
    async exec(sql) {
      const parts = sql.split(';').map((s) => s.trim()).filter(Boolean);
      for (let i = 0; i < parts.length; i += 40) await pipeline(parts.slice(i, i + 40).map((s) => ({ sql: s })));
    },
    async get(sql, p) { const [r] = await pipeline([{ sql, args: p }]); return rows(r)[0]; },
    async all(sql, p) { const [r] = await pipeline([{ sql, args: p }]); return rows(r); },
    async run(sql, p) { const [r] = await pipeline([{ sql, args: p }]); return { lastInsertRowid: Number(r.last_insert_rowid || 0), changes: Number(r.affected_row_count || 0) }; },
    async batch(list) { return pipeline(list); },
    close() {},
  };
}

let driver = null;
let ready = null;

function open(file) {
  if (ready) return ready;
  ready = (async () => {
    driver = config.tursoUrl && !file ? tursoDriver(config.tursoUrl, config.tursoToken) : localDriver(file || config.dbPath);
    if (driver.name === 'turso') await driver.exec('PRAGMA foreign_keys = ON');
    const hasVersion = await driver.get("SELECT name FROM sqlite_master WHERE type='table' AND name='schema_version'", []);
    if (!hasVersion || !(await driver.get('SELECT version FROM schema_version', []))) {
      await driver.exec(SCHEMA);
      await driver.run('INSERT INTO schema_version(version) VALUES (1)', []);
    }
    return driver;
  })().catch((e) => { ready = null; throw e; });
  return ready;
}

async function close() { if (driver) { driver.close(); driver = null; ready = null; settingsCache = null; } }
const engine = () => (driver ? driver.name : null);

// أدوات استعلام مختصرة (كلها async)
const get = async (sql, ...p) => (await open()).get(sql, p);
const all = async (sql, ...p) => (await open()).all(sql, p);
const run = async (sql, ...p) => (await open()).run(sql, p);
async function tx(fn) {
  const d = await open();
  if (d.name !== 'sqlite') return fn(); // عبر HTTP تُنفَّذ العمليات بالتتابع
  await d.exec('BEGIN');
  try { const r = await fn(); await d.exec('COMMIT'); return r; } catch (e) { await d.exec('ROLLBACK'); throw e; }
}

async function insert(table, data) {
  const keys = Object.keys(data);
  const r = await run(`INSERT INTO ${table} (${keys.join(',')}) VALUES (${keys.map(() => '?').join(',')})`, ...keys.map((k) => data[k]));
  return Number(r.lastInsertRowid);
}
async function update(table, id, data) {
  const keys = Object.keys(data);
  if (!keys.length) return;
  await run(`UPDATE ${table} SET ${keys.map((k) => k + ' = ?').join(', ')} WHERE id = ?`, ...keys.map((k) => data[k]), id);
}

// الإعدادات (ذاكرة مؤقتة قصيرة لتناسب البيئات متعددة النسخ)
let settingsCache = null, settingsAt = 0;
async function settings() {
  if (!settingsCache || Date.now() - settingsAt > 30000) {
    const s = {};
    for (const r of await all('SELECT key, value FROM settings')) s[r.key] = r.value;
    settingsCache = s; settingsAt = Date.now();
  }
  return settingsCache;
}
async function setSetting(key, value) {
  await run('INSERT INTO settings(key, value) VALUES (?, ?) ON CONFLICT(key) DO UPDATE SET value = excluded.value', key, value == null ? '' : String(value));
  settingsCache = null;
}
function clearSettingsCache() { settingsCache = null; }

async function currentYear() {
  return (await get('SELECT * FROM academic_years WHERE is_current = 1')) || get('SELECT * FROM academic_years ORDER BY name DESC LIMIT 1');
}

function postSearchText(p) {
  return normalizeAr([p.title, p.excerpt, p.body, p.category, p.tags, p.location].filter(Boolean).join(' '));
}

async function audit(req, action, entity, entityId, details) {
  const u = req && req.user;
  await run('INSERT INTO audit_log(user_id, user_name, action, entity, entity_id, details, ip) VALUES (?,?,?,?,?,?,?)',
    u ? u.id : null, u ? u.name : (details && details.email) || null, action, entity || null, entityId == null ? null : Number(entityId),
    details ? JSON.stringify(details).slice(0, 2000) : null, req ? req.ip : null);
}

module.exports = { open, close, engine, get, all, run, tx, insert, update, settings, setSetting, clearSettingsCache, currentYear, postSearchText, audit, SCHEMA };
