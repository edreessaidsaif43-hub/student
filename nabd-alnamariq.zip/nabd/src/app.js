'use strict';
// معالج الطلبات الرئيسي — يُستخدم من server.js محليًا ومن api/index.js على Vercel
const config = require('./config');
const db = require('./db');
const { Router, HttpError, enhance, parseBody, serveStatic, securityHeaders } = require('./core/http');
const { loadSession } = require('./core/security');
const uploads = require('./core/uploads');
const { ensureBase, seedDemo } = require('./seed');
const { html, raw } = require('./core/util');
const { icon } = require('./core/icons');

const router = new Router();
require('./public/routes')(router);
require('./admin/routes')(router);

let initPromise = null;
function init() {
  if (!initPromise) {
    initPromise = (async () => {
      await db.open();
      const generated = await ensureBase();
      if (generated) {
        console.log('\n================ حساب مدير النظام ================');
        console.log(' البريد: ' + config.adminEmail);
        console.log(' كلمة المرور المؤقتة: ' + generated);
        console.log(' (سيُطلب تغييرها عند أول تسجيل دخول)');
        console.log('==================================================\n');
      }
      if (config.seedDemo) await seedDemo();
    })().catch((e) => { initPromise = null; throw e; });
  }
  return initPromise;
}

async function errorPage(req, res, status, message) {
  res.statusCode = status;
  const titles = { 400: 'طلب غير صالح', 401: 'يلزم تسجيل الدخول', 403: 'غير مسموح', 404: 'الصفحة غير موجودة', 413: 'الملف كبير جدًا', 429: 'طلبات كثيرة', 500: 'خطأ في الخادم' };
  const title = titles[status] || 'خطأ';
  if (req.path.startsWith('/api/') || req.path.startsWith('/admin/api/') || String(req.headers.accept || '').includes('application/json')) {
    return res.json({ error: message || title }, status);
  }
  const body = html`<section class="error-page"><div class="wrap">
    <div class="err-code">${status}</div><h1>${title}</h1><p>${message || (status === 404 ? 'عذرًا، لم نعثر على الصفحة التي تبحث عنها. ربما نُقلت أو حُذفت.' : 'حدث خطأ غير متوقع، يرجى المحاولة لاحقًا.')}</p>
    <div class="actions"><a class="btn btn-gold" href="/">${raw(icon('home', 'sm'))} العودة للرئيسية</a><a class="btn btn-ghost" href="javascript:history.back()">رجوع</a><a class="btn btn-ghost" href="/search">${raw(icon('search', 'sm'))} البحث</a></div>
  </div></section>`;
  try {
    if (req.path.startsWith('/admin')) {
      const { adminShell } = require('./admin/layout');
      return res.send(await adminShell(req, { title, body: html`<div class="panel"><h2>${title}</h2><p>${message || ''}</p><a class="btn btn-navy" href="javascript:history.back()">رجوع</a></div>` }), undefined, status);
    }
    const { layout } = require('./public/layout');
    res.send(await layout(req, { title, body, noindex: true }), undefined, status);
  } catch {
    res.send(`<!doctype html><meta charset="utf-8"><title>${title}</title><body dir="rtl" style="font-family:sans-serif;padding:3rem"><h1>${title}</h1><p>${message || ''}</p><a href="/">الرئيسية</a>`, undefined, status);
  }
}

async function handle(req, res) {
  enhance(req, res);
  req.res = res;
  securityHeaders(res);
  try {
    if (req.method === 'GET' || req.method === 'HEAD') {
      const p = req.path;
      if (/^\/(css|js|img|files)\//.test(p) || p === '/favicon.ico') {
        const rel = p === '/favicon.ico' ? '/img/favicon.svg' : p;
        if (serveStatic(req, res, config.publicDir, rel, { maxAge: /\/(css|js)\//.test(p) ? 86400 * 7 : 86400 * 30 })) return;
        return errorPage(req, res, 404);
      }
    }
    await init();
    if (req.path.startsWith('/uploads/') && (req.method === 'GET' || req.method === 'HEAD')) {
      if (await uploads.serve(req, res, req.path)) return;
      return errorPage(req, res, 404);
    }
    if (req.path === '/healthz') return res.json({ ok: true, db: db.engine(), time: new Date().toISOString() });

    const m = router.match(req.method, req.path);
    if (!m) return errorPage(req, res, req.method === 'GET' || req.method === 'HEAD' ? 404 : 405, req.method === 'GET' ? null : 'طريقة الطلب غير مدعومة');
    req.params = m.params;
    await parseBody(req);
    await loadSession(req);
    if (req.path.startsWith('/admin')) {
      res.setHeader('Cache-Control', 'no-store');
      res.setHeader('X-Robots-Tag', 'noindex, nofollow');
    }

    let i = 0;
    let fellThrough = false;
    const next = async () => {
      const h = m.handlers[i++];
      if (!h) { fellThrough = true; return; }
      await h(req, res, next);
    };
    await next();
    if (fellThrough && !res.headersSent) return errorPage(req, res, 404);
  } catch (err) {
    const status = err instanceof HttpError ? err.status : 500;
    if (status >= 500) console.error('[خطأ]', req.method, req.path, err);
    if (res.headersSent) { try { res.end(); } catch { /* */ } return; }
    // إعادة توجيه غير المسجلين إلى صفحة الدخول
    if (status === 401 && req.method === 'GET' && req.path.startsWith('/admin')) return res.redirect('/admin/login?next=' + encodeURIComponent(req.path + (req.search || '')));
    return errorPage(req, res, status, err instanceof HttpError ? err.message : null);
  }
}

module.exports = { handle, init, router };
