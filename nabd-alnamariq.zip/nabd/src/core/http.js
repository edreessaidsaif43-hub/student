'use strict';
// طبقة HTTP خفيفة: موجّه، تحليل الطلبات (نماذج، ملفات)، ملفات ثابتة، ضغط، رؤوس أمان
const fs = require('node:fs');
const path = require('node:path');
const zlib = require('node:zlib');
const crypto = require('node:crypto');
const config = require('../config');

class HttpError extends Error {
  constructor(status, message) { super(message); this.status = status; }
}

class Router {
  constructor() { this.routes = []; }
  add(method, pattern, ...handlers) {
    const keys = [];
    const re = new RegExp('^' + pattern.replace(/\/$/, '').replace(/:(\w+)/g, (_, k) => { keys.push(k); return '([^/]+)'; }) + '/?$');
    this.routes.push({ method, re, keys, handlers });
  }
  get(p, ...h) { this.add('GET', p, ...h); }
  post(p, ...h) { this.add('POST', p, ...h); }
  match(method, pathname) {
    for (const r of this.routes) {
      if (r.method !== method && !(method === 'HEAD' && r.method === 'GET')) continue;
      const m = pathname.match(r.re);
      if (m) {
        const params = {};
        r.keys.forEach((k, i) => { try { params[k] = decodeURIComponent(m[i + 1]); } catch { params[k] = m[i + 1]; } });
        return { handlers: r.handlers, params };
      }
    }
    return null;
  }
}

function parseCookies(header) {
  const out = {};
  String(header || '').split(';').forEach((p) => {
    const i = p.indexOf('=');
    if (i > 0) { try { out[p.slice(0, i).trim()] = decodeURIComponent(p.slice(i + 1).trim()); } catch { /* تجاهل */ } }
  });
  return out;
}

function enhance(req, res) {
  const url = new URL(req.url, 'http://local');
  req.path = decodeURIComponent(url.pathname).replace(/\/{2,}/g, '/');
  req.query = Object.fromEntries(url.searchParams);
  req.search = url.search;
  req.cookies = parseCookies(req.headers.cookie);
  const fwd = config.trustProxy && req.headers['x-forwarded-for'];
  req.ip = (fwd ? String(fwd).split(',')[0].trim() : req.socket.remoteAddress) || '';
  req.body = {};
  req.files = {};

  res.locals = {};
  res.setCookie = (name, value, opts = {}) => {
    let c = `${name}=${encodeURIComponent(value)}; Path=${opts.path || '/'}; SameSite=${opts.sameSite || 'Lax'}`;
    if (opts.httpOnly !== false) c += '; HttpOnly';
    if (config.secureCookies) c += '; Secure';
    if (opts.maxAge !== undefined) c += `; Max-Age=${opts.maxAge}`;
    const prev = res.getHeader('Set-Cookie');
    res.setHeader('Set-Cookie', prev ? [].concat(prev, c) : c);
  };
  res.redirect = (loc, code = 303) => { res.statusCode = code; res.setHeader('Location', loc); res.end(); };
  res.send = (body, type = 'text/html; charset=utf-8', status) => {
    if (status) res.statusCode = status;
    sendCompressed(req, res, Buffer.from(String(body)), type);
  };
  res.json = (obj, status) => res.send(JSON.stringify(obj), 'application/json; charset=utf-8', status);
}

function sendCompressed(req, res, buf, type) {
  res.setHeader('Content-Type', type);
  const ae = String(req.headers['accept-encoding'] || '');
  if (buf.length > 1024 && /\bgzip\b/.test(ae) && /text|json|javascript|svg|xml/.test(type)) {
    buf = zlib.gzipSync(buf, { level: 6 });
    res.setHeader('Content-Encoding', 'gzip');
    res.setHeader('Vary', 'Accept-Encoding');
  }
  res.setHeader('Content-Length', buf.length);
  res.end(req.method === 'HEAD' ? undefined : buf);
}

function securityHeaders(res) {
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('X-Frame-Options', 'SAMEORIGIN');
  res.setHeader('Referrer-Policy', 'strict-origin-when-cross-origin');
  res.setHeader('Permissions-Policy', 'camera=(), microphone=(), geolocation=()');
  res.setHeader('Cross-Origin-Opener-Policy', 'same-origin');
  res.setHeader('Content-Security-Policy', [
    "default-src 'self'",
    "script-src 'self'",
    "style-src 'self' 'unsafe-inline' https://fonts.googleapis.com",
    "font-src 'self' https://fonts.gstatic.com data:",
    "img-src 'self' data: blob: https://i.ytimg.com https://pbs.twimg.com",
    "media-src 'self'",
    "frame-src https://www.youtube-nocookie.com https://www.google.com https://maps.google.com",
    "connect-src 'self'",
    "form-action 'self' https://wa.me",
    "base-uri 'self'",
    "object-src 'none'",
    "frame-ancestors 'self'",
  ].join('; '));
  if (config.secureCookies) res.setHeader('Strict-Transport-Security', 'max-age=31536000; includeSubDomains');
}

// قراءة جسم الطلب مع حد أقصى للحجم
function readBody(req, limit) {
  return new Promise((resolve, reject) => {
    const chunks = [];
    let size = 0;
    req.on('data', (c) => {
      size += c.length;
      if (size > limit) { reject(new HttpError(413, 'حجم الطلب أكبر من المسموح')); req.destroy(); return; }
      chunks.push(c);
    });
    req.on('end', () => resolve(Buffer.concat(chunks)));
    req.on('error', reject);
  });
}

function addField(obj, key, val) {
  if (key.endsWith('[]')) { key = key.slice(0, -2); (obj[key] = obj[key] || []).push(val); }
  else if (obj[key] !== undefined) { obj[key] = [].concat(obj[key], val); }
  else obj[key] = val;
}

function parseMultipart(buf, boundary) {
  const fields = {}, files = {};
  const delim = Buffer.from('--' + boundary);
  let pos = buf.indexOf(delim);
  while (pos !== -1) {
    pos += delim.length;
    if (buf[pos] === 45 && buf[pos + 1] === 45) break; // --
    pos += 2; // CRLF
    const headEnd = buf.indexOf('\r\n\r\n', pos);
    if (headEnd === -1) break;
    const head = buf.slice(pos, headEnd).toString('utf8');
    const next = buf.indexOf(delim, headEnd + 4);
    if (next === -1) break;
    const data = buf.slice(headEnd + 4, next - 2);
    const name = (head.match(/name="([^"]*)"/i) || [])[1];
    const filename = (head.match(/filename="([^"]*)"/i) || [])[1];
    const ctype = (head.match(/content-type:\s*([^\r\n]+)/i) || [])[1];
    if (name) {
      if (filename !== undefined) {
        if (filename && data.length) addField(files, name, { filename: path.basename(filename), type: ctype || 'application/octet-stream', data, size: data.length });
      } else addField(fields, name, data.toString('utf8'));
    }
    pos = next;
  }
  return { fields, files };
}

async function parseBody(req) {
  if (!['POST', 'PUT', 'PATCH', 'DELETE'].includes(req.method)) return;
  const type = String(req.headers['content-type'] || '');
  if (type.startsWith('multipart/form-data')) {
    const boundary = (type.match(/boundary=(?:"([^"]+)"|([^;]+))/) || []).slice(1).find(Boolean);
    if (!boundary) throw new HttpError(400, 'طلب غير صالح');
    const buf = await readBody(req, (config.maxUploadMb + 2) * 1024 * 1024 * 3);
    const { fields, files } = parseMultipart(buf, boundary);
    req.body = fields; req.files = files;
  } else if (type.startsWith('application/json')) {
    const buf = await readBody(req, 1024 * 1024);
    try { req.body = JSON.parse(buf.toString('utf8') || '{}'); } catch { throw new HttpError(400, 'JSON غير صالح'); }
  } else {
    const buf = await readBody(req, 2 * 1024 * 1024);
    const sp = new URLSearchParams(buf.toString('utf8'));
    const out = {};
    for (const [k, v] of sp) addField(out, k, v);
    req.body = out;
  }
}

// ملفات ثابتة مع ETag وتخزين مؤقت وضغط
const MIME = {
  '.html': 'text/html; charset=utf-8', '.css': 'text/css; charset=utf-8', '.js': 'application/javascript; charset=utf-8',
  '.json': 'application/json; charset=utf-8', '.svg': 'image/svg+xml', '.png': 'image/png', '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg',
  '.webp': 'image/webp', '.gif': 'image/gif', '.ico': 'image/x-icon', '.pdf': 'application/pdf', '.mp4': 'video/mp4', '.webm': 'video/webm',
  '.mp3': 'audio/mpeg', '.txt': 'text/plain; charset=utf-8', '.xml': 'application/xml; charset=utf-8', '.woff2': 'font/woff2',
  '.docx': 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
  '.xlsx': 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
  '.pptx': 'application/vnd.openxmlformats-officedocument.presentationml.presentation',
  '.webmanifest': 'application/manifest+json',
};
const gzCache = new Map();

function serveStatic(req, res, baseDir, relPath, { maxAge = 3600, download = false } = {}) {
  const full = path.resolve(baseDir, '.' + path.posix.normalize('/' + relPath));
  if (!full.startsWith(path.resolve(baseDir) + path.sep)) return false;
  let st;
  try { st = fs.statSync(full); } catch { return false; }
  if (!st.isFile()) return false;
  const ext = path.extname(full).toLowerCase();
  const type = MIME[ext] || 'application/octet-stream';
  const etag = `W/"${st.size.toString(16)}-${Math.floor(st.mtimeMs).toString(16)}"`;
  res.setHeader('ETag', etag);
  res.setHeader('Cache-Control', `public, max-age=${maxAge}`);
  res.setHeader('Last-Modified', st.mtime.toUTCString());
  if (download) res.setHeader('Content-Disposition', 'attachment');
  if (ext === '.svg') res.setHeader('Content-Security-Policy', "default-src 'none'; style-src 'unsafe-inline'; sandbox");
  if (req.headers['if-none-match'] === etag) { res.statusCode = 304; res.end(); return true; }
  res.setHeader('Content-Type', type);

  const compressible = /text|javascript|json|svg|xml/.test(type);
  if (compressible && /\bgzip\b/.test(String(req.headers['accept-encoding'] || '')) && st.size < 2 * 1024 * 1024) {
    let c = gzCache.get(full);
    if (!c || c.etag !== etag) { c = { etag, buf: zlib.gzipSync(fs.readFileSync(full), { level: 9 }) }; gzCache.set(full, c); }
    res.setHeader('Content-Encoding', 'gzip');
    res.setHeader('Vary', 'Accept-Encoding');
    res.setHeader('Content-Length', c.buf.length);
    res.end(req.method === 'HEAD' ? undefined : c.buf);
    return true;
  }
  // دعم طلبات النطاق (للفيديو)
  const range = req.headers.range && String(req.headers.range).match(/bytes=(\d*)-(\d*)/);
  res.setHeader('Accept-Ranges', 'bytes');
  if (range) {
    const start = range[1] ? parseInt(range[1], 10) : 0;
    const end = range[2] ? Math.min(parseInt(range[2], 10), st.size - 1) : st.size - 1;
    if (start >= st.size || start > end) { res.statusCode = 416; res.setHeader('Content-Range', `bytes */${st.size}`); res.end(); return true; }
    res.statusCode = 206;
    res.setHeader('Content-Range', `bytes ${start}-${end}/${st.size}`);
    res.setHeader('Content-Length', end - start + 1);
    if (req.method === 'HEAD') { res.end(); return true; }
    fs.createReadStream(full, { start, end }).pipe(res);
    return true;
  }
  res.setHeader('Content-Length', st.size);
  if (req.method === 'HEAD') { res.end(); return true; }
  fs.createReadStream(full).pipe(res);
  return true;
}

const randomToken = (n = 32) => crypto.randomBytes(n).toString('base64url');

module.exports = { Router, HttpError, enhance, parseBody, serveStatic, securityHeaders, randomToken, MIME };
