'use strict';
// الأمان: تجزئة كلمات المرور، الجلسات، رموز CSRF، تحديد معدل الطلبات
const crypto = require('node:crypto');
const db = require('../db');
const config = require('../config');
const { HttpError, randomToken } = require('./http');
const { safeJson } = require('./util');

const SESSION_COOKIE = 'nabd_sid';

function hashPassword(pw) {
  const salt = crypto.randomBytes(16);
  const hash = crypto.scryptSync(String(pw), salt, 64, { N: 16384, r: 8, p: 1 });
  return `scrypt$${salt.toString('base64')}$${hash.toString('base64')}`;
}
function verifyPassword(pw, stored) {
  const [alg, s, h] = String(stored || '').split('$');
  if (alg !== 'scrypt' || !s || !h) return false;
  const expected = Buffer.from(h, 'base64');
  const got = crypto.scryptSync(String(pw), Buffer.from(s, 'base64'), expected.length, { N: 16384, r: 8, p: 1 });
  return crypto.timingSafeEqual(expected, got);
}
function passwordProblem(pw) {
  pw = String(pw || '');
  if (pw.length < 10) return 'يجب ألا تقل كلمة المرور عن 10 أحرف';
  if (!/[A-Za-z؀-ۿ]/.test(pw) || !/\d/.test(pw)) return 'يجب أن تحتوي كلمة المرور على حروف وأرقام';
  return null;
}

const sha = (s) => crypto.createHash('sha256').update(s).digest('hex');

async function createSession(req, res, user) {
  const token = randomToken(32);
  const csrf = randomToken(24);
  const expires = new Date(Date.now() + config.sessionDays * 864e5).toISOString().slice(0, 19).replace('T', ' ');
  await db.run('INSERT INTO sessions(id, user_id, csrf, ip, user_agent, expires_at) VALUES (?,?,?,?,?,?)',
    sha(token), user.id, csrf, req.ip, String(req.headers['user-agent'] || '').slice(0, 250), expires);
  res.setCookie(SESSION_COOKIE, token, { maxAge: config.sessionDays * 86400, sameSite: 'Lax' });
}

async function loadSession(req) {
  const token = req.cookies[SESSION_COOKIE];
  if (!token) return;
  const row = await db.get(`SELECT s.id sid, s.csrf, s.expires_at, u.*, r.name role_name, r.label role_label, r.permissions
    FROM sessions s JOIN users u ON u.id = s.user_id JOIN roles r ON r.id = u.role_id
    WHERE s.id = ? AND s.expires_at > datetime('now') AND u.active = 1`, sha(token));
  if (!row) return;
  const perms = new Set(safeJson(row.permissions, []));
  req.session = { id: row.sid, csrf: row.csrf };
  req.user = {
    id: row.id, name: row.name, email: row.email, role: row.role_name, roleLabel: row.role_label, roleId: row.role_id,
    mustChange: !!row.must_change_password, perms, can: (p) => perms.has(p),
  };
}

async function destroySession(req, res) {
  if (req.session) await db.run('DELETE FROM sessions WHERE id = ?', req.session.id);
  res.setCookie(SESSION_COOKIE, '', { maxAge: 0 });
}

function checkCsrf(req) {
  const t = req.body._csrf || req.headers['x-csrf-token'];
  if (!req.session || !t || typeof t !== 'string' || t.length !== req.session.csrf.length ||
      !crypto.timingSafeEqual(Buffer.from(t), Buffer.from(req.session.csrf))) {
    throw new HttpError(403, 'انتهت صلاحية النموذج، يرجى تحديث الصفحة والمحاولة مجددًا');
  }
}

// رمز النماذج العامة (تواصل، مقترحات، استبانات) — موقّع بالمفتاح السري ومحدد بالوقت
function formToken() {
  const ts = Date.now().toString(36);
  const sig = crypto.createHmac('sha256', config.sessionSecret).update('form:' + ts).digest('base64url').slice(0, 32);
  return ts + '.' + sig;
}
function checkFormToken(req) {
  const t = String(req.body._ft || '');
  const [ts, sig] = t.split('.');
  const exp = ts && crypto.createHmac('sha256', config.sessionSecret).update('form:' + ts).digest('base64url').slice(0, 32);
  const age = Date.now() - parseInt(ts, 36);
  if (!sig || sig !== exp || !(age >= 0 && age < 6 * 3600 * 1000)) throw new HttpError(400, 'انتهت صلاحية النموذج، يرجى تحديث الصفحة');
  if (req.body.website) throw new HttpError(400, 'تعذّر إرسال النموذج'); // مصيدة الروبوتات
}

// تحديد معدل الطلبات في الذاكرة
const buckets = new Map();
function rateLimit(key, max, windowMs) {
  const now = Date.now();
  let b = buckets.get(key);
  if (!b || b.reset < now) { b = { count: 0, reset: now + windowMs }; buckets.set(key, b); }
  b.count++;
  if (buckets.size > 10000) for (const [k, v] of buckets) if (v.reset < now) buckets.delete(k);
  return b.count <= max;
}
function resetRate(key) { buckets.delete(key); }

function requirePerm(req, perm) {
  if (!req.user) throw new HttpError(401, 'يجب تسجيل الدخول');
  const list = [].concat(perm);
  if (!list.some((p) => req.user.can(p))) throw new HttpError(403, 'ليست لديك صلاحية لتنفيذ هذا الإجراء');
}

const ipHash = (ip) => sha(config.sessionSecret + '|' + ip).slice(0, 24);

module.exports = { hashPassword, verifyPassword, passwordProblem, createSession, loadSession, destroySession, checkCsrf, formToken, checkFormToken, rateLimit, resetRate, requirePerm, ipHash, sha };
