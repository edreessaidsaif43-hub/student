'use strict';
// أدوات عامة: التهريب، الروابط اللطيفة، تنسيق التواريخ، محوّل Markdown آمن

const ESC = { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' };
const esc = (v) => (v === null || v === undefined ? '' : String(v).replace(/[&<>"']/g, (c) => ESC[c]));

// قوالب HTML: كل قيمة تُهرَّب تلقائيًا ما لم تُغلَّف بـ raw()
class Raw { constructor(s) { this.s = s; } toString() { return this.s; } }
const raw = (s) => new Raw(s == null ? '' : String(s));
function html(strings, ...vals) {
  let out = '';
  strings.forEach((s, i) => {
    out += s;
    if (i < vals.length) out += fmt(vals[i]);
  });
  return raw(out);
}
function fmt(v) {
  if (v instanceof Raw) return v.s;
  if (Array.isArray(v)) return v.map(fmt).join('');
  if (v === false || v === null || v === undefined) return '';
  return esc(v);
}

// توحيد الحروف العربية لأغراض البحث
function normalizeAr(s) {
  return String(s || '')
    .toLowerCase()
    .replace(/[ً-ْـ]/g, '') // التشكيل والتطويل
    .replace(/[أإآٱ]/g, 'ا')
    .replace(/ة/g, 'ه')
    .replace(/ى/g, 'ي')
    .replace(/ؤ/g, 'و')
    .replace(/ئ/g, 'ي')
    .replace(/\s+/g, ' ')
    .trim();
}

function slugify(s) {
  const base = String(s || '')
    .trim()
    .replace(/[ً-ْـ]/g, '')
    .replace(/[^\p{L}\p{N}\s-]/gu, '')
    .replace(/\s+/g, '-')
    .replace(/-+/g, '-')
    .replace(/^-|-$/g, '')
    .toLowerCase()
    .slice(0, 80);
  return base || 'item-' + Date.now().toString(36);
}

const AR_LOCALE = 'ar-OM-u-nu-latn';
function toDate(v) {
  if (!v) return null;
  if (v instanceof Date) return isNaN(v) ? null : v;
  // القيم بلا منطقة زمنية تُعامَل على أنها بتوقيت مسقط (+04:00)
  const s = String(v).trim();
  let d;
  if (/^\d{4}-\d{2}-\d{2}$/.test(s)) d = new Date(s + 'T00:00:00+04:00');
  else if (/^\d{4}-\d{2}-\d{2}[T ]\d{2}:\d{2}(:\d{2})?$/.test(s)) d = new Date(s.replace(' ', 'T').slice(0, 16) + ':00+04:00');
  else d = new Date(s);
  return isNaN(d) ? null : d;
}
function fmtDate(v, opts = { dateStyle: 'long' }) {
  const d = toDate(v);
  return d ? new Intl.DateTimeFormat(AR_LOCALE, { timeZone: 'Asia/Muscat', ...opts }).format(d) : '';
}
const fmtDateTime = (v) => fmtDate(v, { dateStyle: 'medium', timeStyle: 'short' });
const fmtDay = (v) => fmtDate(v, { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' });
const fmtNum = (n) => new Intl.NumberFormat(AR_LOCALE).format(Number(n) || 0);

// الوقت الحالي بصيغة SQLite (UTC)
const nowSql = () => new Date().toISOString().slice(0, 19).replace('T', ' ');
// تحويل قيمة datetime-local (بتوقيت مسقط) إلى UTC
function localToUtc(v) {
  if (!v) return null;
  const s = String(v).trim();
  if (/^\d{4}-\d{2}-\d{2}$/.test(s)) return s + ' 00:00:00';
  const m = s.match(/^(\d{4}-\d{2}-\d{2})[T ](\d{2}:\d{2})/);
  if (!m) return null;
  const d = new Date(m[1] + 'T' + m[2] + ':00+04:00');
  return isNaN(d) ? null : d.toISOString().slice(0, 19).replace('T', ' ');
}
function utcToLocalInput(v) {
  const d = toDateUtc(v);
  if (!d) return '';
  const t = new Date(d.getTime() + 4 * 3600 * 1000);
  return t.toISOString().slice(0, 16);
}
function toDateUtc(v) {
  if (!v) return null;
  const s = String(v);
  const d = new Date(s.includes('T') || s.endsWith('Z') ? s : s.replace(' ', 'T') + 'Z');
  return isNaN(d) ? null : d;
}
const fmtUtc = (v, opts) => fmtDate(toDateUtc(v), opts);
const fmtUtcDT = (v) => fmtDate(toDateUtc(v), { dateStyle: 'medium', timeStyle: 'short' });

function excerpt(text, n = 160) {
  const t = String(text || '').replace(/[#>*_`\[\]()!-]/g, ' ').replace(/\s+/g, ' ').trim();
  return t.length > n ? t.slice(0, n).replace(/\s+\S*$/, '') + '…' : t;
}

// تحويل Markdown مبسّط إلى HTML آمن (يُهرَّب النص أولًا)
function safeUrl(u) {
  u = String(u || '').trim();
  if (/^(https?:\/\/|\/(?!\/)|mailto:|tel:|#)/i.test(u)) return u;
  return '#';
}
function inline(s) {
  return s
    .replace(/!\[([^\]]*)\]\(([^)\s]+)\)/g, (_, alt, url) => `<img src="${esc(safeUrl(url))}" alt="${alt}" loading="lazy">`)
    .replace(/\[([^\]]+)\]\(([^)\s]+)\)/g, (_, t, url) => {
      const u = safeUrl(url);
      const ext = /^https?:/i.test(u) ? ' target="_blank" rel="noopener noreferrer"' : '';
      return `<a href="${esc(u)}"${ext}>${t}</a>`;
    })
    .replace(/\*\*([^*]+)\*\*/g, '<strong>$1</strong>')
    .replace(/(^|[\s(])\*([^*\n]+)\*/g, '$1<em>$2</em>');
}
function markdown(src) {
  const lines = esc(String(src || '').replace(/\r\n/g, '\n')).split('\n');
  const out = [];
  let para = [], list = null;
  const flushP = () => { if (para.length) { out.push('<p>' + inline(para.join('<br>')) + '</p>'); para = []; } };
  const flushL = () => { if (list) { out.push(`<${list.t}>` + list.items.map((i) => '<li>' + inline(i) + '</li>').join('') + `</${list.t}>`); list = null; } };
  for (const line of lines) {
    let m;
    if (!line.trim()) { flushP(); flushL(); continue; }
    if ((m = line.match(/^(#{2,4})\s+(.*)$/))) { flushP(); flushL(); const l = m[1].length; out.push(`<h${l}>${inline(m[2])}</h${l}>`); continue; }
    if ((m = line.match(/^\s*[-•]\s+(.*)$/))) { flushP(); if (!list || list.t !== 'ul') { flushL(); list = { t: 'ul', items: [] }; } list.items.push(m[1]); continue; }
    if ((m = line.match(/^\s*\d+[.)]\s+(.*)$/))) { flushP(); if (!list || list.t !== 'ol') { flushL(); list = { t: 'ol', items: [] }; } list.items.push(m[1]); continue; }
    if ((m = line.match(/^&gt;\s?(.*)$/))) { flushP(); flushL(); out.push('<blockquote>' + inline(m[1]) + '</blockquote>'); continue; }
    if (/^---+$/.test(line.trim())) { flushP(); flushL(); out.push('<hr>'); continue; }
    flushL();
    para.push(line);
  }
  flushP(); flushL();
  return out.join('\n');
}

function toInt(v, d = 0) { const n = parseInt(v, 10); return Number.isFinite(n) ? n : d; }
function clampStr(v, n) { return String(v == null ? '' : v).trim().slice(0, n); }
function isEmail(v) { return /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(String(v || '')); }
function lines(v) { return String(v || '').split(/\r?\n/).map((s) => s.trim()).filter(Boolean); }
function safeJson(v, d) { try { return v ? JSON.parse(v) : d; } catch { return d; } }

function youtubeEmbed(url) {
  const m = String(url || '').match(/(?:youtube\.com\/(?:watch\?v=|embed\/|shorts\/)|youtu\.be\/)([\w-]{11})/);
  return m ? 'https://www.youtube-nocookie.com/embed/' + m[1] : null;
}

module.exports = {
  esc, raw, html, Raw, normalizeAr, slugify, fmtDate, fmtDateTime, fmtDay, fmtNum, nowSql, localToUtc, utcToLocalInput,
  toDateUtc, fmtUtc, fmtUtcDT, excerpt, markdown, toInt, clampStr, isEmail, lines, safeJson, youtubeEmbed, safeUrl, toDate,
};
