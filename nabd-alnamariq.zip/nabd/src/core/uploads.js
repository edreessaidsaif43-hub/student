'use strict';
// رفع الملفات: التحقق من النوع الحقيقي (التوقيع الثنائي) والحجم والامتداد،
// وتُحفظ داخل قاعدة البيانات (جدول file_blobs) لتعمل محليًا وعلى Vercel دون نظام ملفات دائم
const path = require('node:path');
const crypto = require('node:crypto');
const config = require('../config');
const db = require('../db');
const { HttpError } = require('./http');

const isZip = (b) => b[0] === 0x50 && b[1] === 0x4b && b[2] === 0x03 && b[3] === 0x04;
const ALLOWED = {
  '.jpg': { kind: 'image', mime: 'image/jpeg', sig: (b) => b[0] === 0xff && b[1] === 0xd8 && b[2] === 0xff },
  '.jpeg': { kind: 'image', mime: 'image/jpeg', sig: (b) => b[0] === 0xff && b[1] === 0xd8 && b[2] === 0xff },
  '.png': { kind: 'image', mime: 'image/png', sig: (b) => b.slice(0, 8).equals(Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a])) },
  '.gif': { kind: 'image', mime: 'image/gif', sig: (b) => b.slice(0, 4).toString() === 'GIF8' },
  '.webp': { kind: 'image', mime: 'image/webp', sig: (b) => b.slice(0, 4).toString() === 'RIFF' && b.slice(8, 12).toString() === 'WEBP' },
  '.pdf': { kind: 'document', mime: 'application/pdf', sig: (b) => b.slice(0, 5).toString() === '%PDF-' },
  '.docx': { kind: 'document', mime: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document', sig: isZip },
  '.xlsx': { kind: 'document', mime: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', sig: isZip },
  '.pptx': { kind: 'document', mime: 'application/vnd.openxmlformats-officedocument.presentationml.presentation', sig: isZip },
  '.mp4': { kind: 'video', mime: 'video/mp4', sig: (b) => b.slice(4, 8).toString() === 'ftyp' },
  '.webm': { kind: 'video', mime: 'video/webm', sig: (b) => b[0] === 0x1a && b[1] === 0x45 && b[2] === 0xdf && b[3] === 0xa3 },
  '.mp3': { kind: 'audio', mime: 'audio/mpeg', sig: (b) => b.slice(0, 3).toString() === 'ID3' || (b[0] === 0xff && (b[1] & 0xe0) === 0xe0) },
};
const KIND_LABEL = { image: 'صورة', document: 'مستند', video: 'فيديو', audio: 'صوت' };

function validate(file, allowKinds) {
  const ext = path.extname(file.filename).toLowerCase();
  const rule = ALLOWED[ext];
  if (!rule) throw new HttpError(400, `نوع الملف غير مسموح (${ext || 'بدون امتداد'}). الأنواع المسموحة: ${Object.keys(ALLOWED).join(' ')}`);
  if (allowKinds && !allowKinds.includes(rule.kind)) throw new HttpError(400, `يجب أن يكون الملف من نوع: ${allowKinds.map((k) => KIND_LABEL[k]).join(' أو ')}`);
  if (file.size > config.maxUploadMb * 1024 * 1024) throw new HttpError(400, `حجم الملف يتجاوز ${config.maxUploadMb} ميجابايت`);
  if (!rule.sig(file.data)) throw new HttpError(400, 'محتوى الملف لا يطابق امتداده');
  return { ext, ...rule };
}

// حفظ الملف وتسجيله في مكتبة الوسائط، يعيد المسار العام /uploads/...
async function save(file, user, { allowKinds, alt } = {}) {
  const info = validate(file, allowKinds);
  const publicPath = `/uploads/${crypto.randomBytes(12).toString('hex')}${info.ext}`;
  const id = await db.insert('files', {
    original_name: file.filename.slice(0, 200), path: publicPath, mime: info.mime, size: file.size, kind: info.kind,
    alt: alt || null, uploaded_by: user ? user.id : null,
  });
  await db.run('INSERT INTO file_blobs(file_id, data) VALUES (?, ?)', id, file.data);
  return publicPath;
}

async function removeFile(publicPath) {
  if (!publicPath || !publicPath.startsWith('/uploads/')) return;
  const f = await db.get('SELECT id FROM files WHERE path = ?', publicPath);
  if (f) { await db.run('DELETE FROM file_blobs WHERE file_id = ?', f.id); await db.run('DELETE FROM files WHERE id = ?', f.id); }
}

async function serve(req, res, publicPath) {
  const f = await db.get('SELECT f.mime, f.size, f.original_name, f.kind, b.data FROM files f JOIN file_blobs b ON b.file_id = f.id WHERE f.path = ?', publicPath);
  if (!f) return false;
  const etag = '"' + path.basename(publicPath) + '"';
  res.setHeader('ETag', etag);
  res.setHeader('Cache-Control', 'public, max-age=31536000, immutable');
  if (req.headers['if-none-match'] === etag) { res.statusCode = 304; res.end(); return true; }
  res.setHeader('Content-Type', f.mime);
  res.setHeader('Content-Length', f.data.length);
  const disp = f.kind === 'document' ? 'attachment' : 'inline';
  res.setHeader('Content-Disposition', `${disp}; filename*=UTF-8''${encodeURIComponent(f.original_name)}`);
  res.end(req.method === 'HEAD' ? undefined : f.data);
  return true;
}

const fmtSize = (n) => (n > 1048576 ? (n / 1048576).toFixed(1) + ' م.ب' : Math.max(1, Math.round(n / 1024)) + ' ك.ب');

module.exports = { save, validate, removeFile, serve, ALLOWED, KIND_LABEL, fmtSize };
