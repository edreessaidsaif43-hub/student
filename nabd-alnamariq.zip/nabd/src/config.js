'use strict';
// تحميل متغيرات البيئة من ملف .env (بدون أي مكتبات خارجية)
const fs = require('node:fs');
const path = require('node:path');

const ROOT = path.resolve(__dirname, '..');

function loadEnvFile(file) {
  if (!fs.existsSync(file)) return;
  const lines = fs.readFileSync(file, 'utf8').split(/\r?\n/);
  for (const line of lines) {
    const m = line.match(/^\s*([A-Z0-9_]+)\s*=\s*(.*)\s*$/i);
    if (!m) continue;
    let v = m[2];
    if ((v.startsWith('"') && v.endsWith('"')) || (v.startsWith("'") && v.endsWith("'"))) v = v.slice(1, -1);
    if (process.env[m[1]] === undefined) process.env[m[1]] = v;
  }
}
loadEnvFile(path.join(ROOT, '.env'));

const env = process.env;
const resolve = (p, d) => path.resolve(ROOT, p || d);

const config = {
  root: ROOT,
  env: env.NODE_ENV || 'development',
  isProd: (env.NODE_ENV || '') === 'production',
  host: env.HOST || '0.0.0.0',
  port: Number(env.PORT || 3000),
  siteUrl: (env.SITE_URL || (env.VERCEL_PROJECT_PRODUCTION_URL ? 'https://' + env.VERCEL_PROJECT_PRODUCTION_URL : 'http://localhost:' + (env.PORT || 3000))).replace(/\/+$/, ''),
  dbPath: resolve(env.DB_PATH, 'data/nabd.db'),
  uploadDir: resolve(env.UPLOAD_DIR, 'uploads'),
  publicDir: path.join(ROOT, 'public'),
  sessionSecret: env.SESSION_SECRET || 'dev-only-secret-change-me',
  sessionDays: Number(env.SESSION_DAYS || 7),
  maxUploadMb: Number(env.MAX_UPLOAD_MB || (env.VERCEL ? 4 : 20)),
  // NABD_TURSO_URL/TOKEN (اختياريان) يتقدمان على متغيرات تكامل Turso — مفيدان لربط قاعدة مستعادة من نسخة زمنية
  tursoUrl: env.NABD_TURSO_URL || env.TURSO_DATABASE_URL || env.LIBSQL_URL || '',
  tursoToken: (env.NABD_TURSO_URL && env.NABD_TURSO_TOKEN) || env.TURSO_AUTH_TOKEN || env.LIBSQL_AUTH_TOKEN || '',
  isVercel: !!env.VERCEL,
  trustProxy: env.TRUST_PROXY === '1' || env.TRUST_PROXY === 'true' || !!env.VERCEL,
  secureCookies: env.SECURE_COOKIES ? env.SECURE_COOKIES === '1' || env.SECURE_COOKIES === 'true' : (env.NODE_ENV === 'production' || !!env.VERCEL),
  adminEmail: env.ADMIN_EMAIL || 'admin@alnamariq.edu.om',
  adminPassword: env.ADMIN_PASSWORD || '',
  seedDemo: env.SEED_DEMO !== '0',
};

if ((config.isProd || config.isVercel) && config.sessionSecret === 'dev-only-secret-change-me') {
  throw new Error('يجب ضبط متغير البيئة SESSION_SECRET في بيئة الإنتاج.');
}
if (config.isVercel && !config.tursoUrl) {
  console.error('[تحذير] لم يُضبط TURSO_DATABASE_URL — البيانات على Vercel لن تُحفظ بين الطلبات.');
  config.dbPath = '/tmp/nabd.db';
}

module.exports = config;
