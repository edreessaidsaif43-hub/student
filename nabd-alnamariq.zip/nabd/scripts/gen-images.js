'use strict';
// يولّد رسومًا توضيحية أصلية (SVG) بطابع مدرسي عُماني تُستخدم في المحتوى التجريبي
// التشغيل: node scripts/gen-images.js
const fs = require('node:fs');
const path = require('node:path');
const OUT = path.join(__dirname, '..', 'public', 'img');
fs.mkdirSync(OUT, { recursive: true });

const C = {
  navy: '#0B1F3A', navy2: '#163A63', navy3: '#24507F', teal: '#0FA3A3', teal2: '#3CC9C0', tealL: '#BFEDE8',
  gold: '#C9A227', gold2: '#E8C65A', sand: '#F3E6CF', sand2: '#E2CBA4', sand3: '#C9A97A', white: '#FFFFFF',
  skin1: '#C98B5B', skin2: '#A86F45', skin3: '#E0A878', red: '#C8102E', green: '#00843D', gray: '#DDE3EA', wood: '#9A6B3F',
};
const W = 1200, H = 750;

const svg = (body, defs = '', w = W, h = H) =>
  `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${w} ${h}" width="${w}" height="${h}" role="img">` +
  `<defs>${defs}<linearGradient id="sky" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#CFEFF0"/><stop offset="1" stop-color="#F7F1E6"/></linearGradient>` +
  `<linearGradient id="skyN" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="${C.navy}"/><stop offset="1" stop-color="${C.navy3}"/></linearGradient>` +
  `<linearGradient id="goldG" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="${C.gold2}"/><stop offset="1" stop-color="${C.gold}"/></linearGradient>` +
  `<linearGradient id="tealG" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="${C.teal2}"/><stop offset="1" stop-color="${C.teal}"/></linearGradient>` +
  `<pattern id="omani" width="40" height="40" patternUnits="userSpaceOnUse"><path d="M20 2 L38 20 L20 38 L2 20Z" fill="none" stroke="${C.gold}" stroke-opacity=".25" stroke-width="1.5"/><circle cx="20" cy="20" r="3" fill="${C.gold}" fill-opacity=".3"/></pattern>` +
  `</defs>${body}</svg>`;

// ===== عناصر مشتركة =====
const sun = (x, y, r = 46) => `<circle cx="${x}" cy="${y}" r="${r + 30}" fill="${C.gold2}" opacity=".18"/><circle cx="${x}" cy="${y}" r="${r}" fill="${C.gold2}"/>`;
const mountains = (y, color = '#9FB7C4', op = 1) =>
  `<path d="M0 ${y} L120 ${y - 120} L210 ${y - 60} L330 ${y - 190} L470 ${y - 70} L560 ${y - 140} L700 ${y - 40} L820 ${y - 170} L960 ${y - 60} L1060 ${y - 130} L1200 ${y - 50} L1200 ${y + 10} L0 ${y + 10}Z" fill="${color}" opacity="${op}"/>`;
function palm(x, y, s = 1) {
  const fr = (a, l) => `<path d="M0 0 Q ${Math.cos(a) * l * 0.5} ${Math.sin(a) * l * 0.5 - 30} ${Math.cos(a) * l} ${Math.sin(a) * l}" stroke="#2E8B57" stroke-width="14" fill="none" stroke-linecap="round"/>`;
  return `<g transform="translate(${x} ${y}) scale(${s})"><path d="M-8 0 Q -18 -110 -2 -230 L10 -230 Q -2 -110 8 0Z" fill="${C.wood}"/>` +
    `<g transform="translate(4 -230)">${[-2.8, -2.2, -1.6, -1, -0.4, 0.2].map((a) => fr(a, 120)).join('')}<circle r="14" fill="#7A4A23"/></g></g>`;
}
function omaniFlag(x, y, s = 1) {
  return `<g transform="translate(${x} ${y}) scale(${s})"><rect x="-3" y="0" width="6" height="200" fill="#8A8F98"/>` +
    `<g transform="translate(3 6)"><rect width="150" height="96" fill="${C.red}"/><rect x="45" width="105" height="32" fill="#fff"/><rect x="45" y="64" width="105" height="32" fill="${C.green}"/></g></g>`;
}
// مبنى مدرسي بطابع القلاع العُمانية (شرفات وأقواس)
function building(x, y, w, h, opt = {}) {
  const cren = [];
  for (let i = 0; i < w; i += 36) cren.push(`<path d="M${i + 6} 0 L${i + 6} -16 Q ${i + 18} -26 ${i + 30} -16 L${i + 30} 0Z" fill="${C.sand2}"/>`);
  const wins = [];
  const cols = Math.floor((w - 60) / 90);
  for (let r = 0; r < (opt.floors || 2); r++) {
    for (let c = 0; c < cols; c++) {
      const wx = 40 + c * ((w - 80) / cols) + ((w - 80) / cols - 46) / 2;
      const wy = 40 + r * 110;
      if (opt.door && r === (opt.floors || 2) - 1 && Math.abs(wx + 23 - w / 2) < 60) continue;
      wins.push(`<path d="M${wx} ${wy + 70} L${wx} ${wy + 23} A23 23 0 0 1 ${wx + 46} ${wy + 23} L${wx + 46} ${wy + 70}Z" fill="${C.navy2}"/><path d="M${wx + 6} ${wy + 66} L${wx + 6} ${wy + 25} A17 17 0 0 1 ${wx + 40} ${wy + 25} L${wx + 40} ${wy + 66}Z" fill="${C.tealL}" opacity=".55"/><rect x="${wx + 21}" y="${wy + 10}" width="4" height="60" fill="${C.navy2}"/>`);
    }
  }
  const door = opt.door ? `<path d="M${w / 2 - 50} ${h} L${w / 2 - 50} ${h - 110} A50 50 0 0 1 ${w / 2 + 50} ${h - 110} L${w / 2 + 50} ${h}Z" fill="${C.wood}"/><path d="M${w / 2 - 40} ${h} L${w / 2 - 40} ${h - 105} A40 40 0 0 1 ${w / 2 + 40} ${h - 105} L${w / 2 + 40} ${h}Z" fill="#7A5230"/><rect x="${w / 2 - 2}" y="${h - 140}" width="4" height="140" fill="#5E3D22"/><circle cx="${w / 2 - 12}" cy="${h - 55}" r="4" fill="${C.gold2}"/><circle cx="${w / 2 + 12}" cy="${h - 55}" r="4" fill="${C.gold2}"/>` : '';
  const sign = opt.sign ? `<rect x="${w / 2 - 130}" y="-70" width="260" height="46" rx="8" fill="${C.navy}"/><rect x="${w / 2 - 124}" y="-64" width="248" height="34" rx="6" fill="none" stroke="${C.gold2}" stroke-width="2"/><rect x="${w / 2 - 90}" y="-52" width="180" height="10" rx="5" fill="${C.gold2}"/>` : '';
  return `<g transform="translate(${x} ${y})"><g>${cren.join('')}</g><rect width="${w}" height="${h}" fill="${C.sand}"/><rect width="${w}" height="10" fill="${C.sand2}"/>` +
    `<rect y="${h - 14}" width="${w}" height="14" fill="${C.sand3}"/>${wins.join('')}${door}${sign}</g>`;
}
function tower(x, y, w, h) {
  return `<g transform="translate(${x} ${y})"><path d="M0 ${h} L8 0 L${w - 8} 0 L${w} ${h}Z" fill="${C.sand2}"/>` +
    [0, 1, 2, 3].map((i) => `<path d="M${6 + i * (w - 12) / 4} 0 L${6 + i * (w - 12) / 4} -16 Q ${6 + i * (w - 12) / 4 + (w - 12) / 8} -26 ${6 + (i + 1) * (w - 12) / 4 - 4} -16 L${6 + (i + 1) * (w - 12) / 4 - 4} 0Z" fill="${C.sand3}"/>`).join('') +
    `<rect x="${w / 2 - 6}" y="40" width="12" height="34" rx="6" fill="${C.navy2}"/><rect x="${w / 2 - 6}" y="110" width="12" height="34" rx="6" fill="${C.navy2}"/></g>`;
}
// شخصيات: طالب بالدشداشة والكمة، طالبة بالحجاب، معلم/معلمة
function person(x, y, s = 1, t = 'boy', opt = {}) {
  const skin = opt.skin || C.skin1;
  const g = [];
  if (t === 'boy' || t === 'man') {
    const tall = t === 'man' ? 1.18 : 1;
    g.push(`<path d="M-34 0 L-26 ${-120 * tall} Q 0 ${-138 * tall} 26 ${-120 * tall} L34 0Z" fill="#FDFDFD" stroke="#D6DCE3" stroke-width="2"/>`);
    g.push(`<path d="M0 ${-118 * tall} L0 ${-80 * tall}" stroke="#C9D1DA" stroke-width="3"/><circle cx="0" cy="${-112 * tall}" r="4" fill="${opt.tassel || C.gold}"/>`);
    g.push(`<rect x="-7" y="${-134 * tall}" width="14" height="14" fill="${skin}"/>`);
    g.push(`<circle cx="0" cy="${-152 * tall}" r="24" fill="${skin}"/>`);
    if (t === 'man') g.push(`<path d="M-26 ${-168 * tall} Q 0 ${-186 * tall} 26 ${-168 * tall} L28 ${-150 * tall} Q 0 ${-158 * tall} -28 ${-150 * tall}Z" fill="${opt.massar || C.teal}"/><path d="M-20 ${-140 * tall} Q 0 ${-122 * tall} 20 ${-140 * tall}" fill="#3B2A1E" opacity=".7"/>`);
    else g.push(`<path d="M-24 ${-158 * tall} Q -24 ${-182 * tall} 0 ${-182 * tall} Q 24 ${-182 * tall} 24 ${-158 * tall}Z" fill="#fff" stroke="${opt.kuma || C.teal}" stroke-width="3"/><path d="M-18 ${-164 * tall} h36" stroke="${opt.kuma || C.teal}" stroke-width="2" stroke-dasharray="4 3"/>`);
    g.push(`<circle cx="-8" cy="${-150 * tall}" r="2.6" fill="${C.navy}"/><circle cx="8" cy="${-150 * tall}" r="2.6" fill="${C.navy}"/><path d="M-7 ${-140 * tall} Q 0 ${-135 * tall} 7 ${-140 * tall}" stroke="${C.navy}" stroke-width="2" fill="none"/>`);
  } else {
    const dress = opt.dress || (t === 'woman' ? C.navy2 : C.teal);
    const tall = t === 'woman' ? 1.15 : 1;
    g.push(`<path d="M-36 0 L-26 ${-112 * tall} Q 0 ${-128 * tall} 26 ${-112 * tall} L36 0Z" fill="${dress}"/>`);
    g.push(`<path d="M-30 ${-110 * tall} Q 0 ${-90 * tall} 30 ${-110 * tall} L26 ${-128 * tall} Q 0 ${-136 * tall} -26 ${-128 * tall}Z" fill="${t === 'woman' ? '#222B36' : '#fff'}"/>`);
    g.push(`<ellipse cx="0" cy="${-152 * tall}" rx="30" ry="33" fill="${t === 'woman' ? '#222B36' : '#fff'}" stroke="#D6DCE3" stroke-width="${t === 'woman' ? 0 : 2}"/>`);
    g.push(`<ellipse cx="0" cy="${-148 * tall}" rx="19" ry="21" fill="${skin}"/>`);
    g.push(`<circle cx="-7" cy="${-150 * tall}" r="2.6" fill="${C.navy}"/><circle cx="7" cy="${-150 * tall}" r="2.6" fill="${C.navy}"/><path d="M-6 ${-139 * tall} Q 0 ${-134 * tall} 6 ${-139 * tall}" stroke="${C.navy}" stroke-width="2" fill="none"/>`);
  }
  if (opt.book) g.push(`<rect x="12" y="-92" width="36" height="28" rx="3" fill="${opt.book}" transform="rotate(-12)"/><rect x="16" y="-88" width="28" height="3" fill="#fff" transform="rotate(-12)"/>`);
  if (opt.bag) g.push(`<rect x="-46" y="-104" width="22" height="44" rx="8" fill="${opt.bag}"/>`);
  if (opt.raise) g.push(`<path d="M24 -110 L48 -170" stroke="${t === 'boy' || t === 'man' ? '#FDFDFD' : opt.dress || C.teal}" stroke-width="13" stroke-linecap="round"/><circle cx="50" cy="-176" r="8" fill="${skin}"/>`);
  return `<g transform="translate(${x} ${y}) scale(${s})">${g.join('')}</g>`;
}
const ground = (y, color = '#E7D6B6') => `<rect y="${y}" width="${W}" height="${H - y}" fill="${color}"/>`;
const badge = (txt) => '';

function bookshelf(x, y, w, h) {
  const rows = [];
  const cols = ['#0FA3A3', '#C9A227', '#163A63', '#C8102E', '#3CC9C0', '#7A5230', '#E8C65A', '#24507F'];
  for (let r = 0; r < 4; r++) {
    let bx = 12;
    let i = r * 3;
    while (bx < w - 30) {
      const bw = 14 + ((i * 7) % 12), bh = h / 4 - 26 - ((i * 5) % 18);
      rows.push(`<rect x="${bx}" y="${r * h / 4 + (h / 4 - 10 - bh)}" width="${bw}" height="${bh}" rx="2" fill="${cols[i % cols.length]}"/>`);
      bx += bw + 3; i++;
    }
    rows.push(`<rect x="0" y="${(r + 1) * h / 4 - 10}" width="${w}" height="10" fill="${C.wood}"/>`);
  }
  return `<g transform="translate(${x} ${y})"><rect x="-10" y="-10" width="${w + 20}" height="${h + 10}" fill="#7A5230"/><rect width="${w}" height="${h}" fill="#F7EEDD"/>${rows.join('')}</g>`;
}
function desk(x, y, w = 200) {
  return `<g transform="translate(${x} ${y})"><rect x="0" y="0" width="${w}" height="16" rx="4" fill="${C.wood}"/><rect x="12" y="16" width="10" height="70" fill="#6B4A2B"/><rect x="${w - 22}" y="16" width="10" height="70" fill="#6B4A2B"/></g>`;
}
function board(x, y, w, h, content = '') {
  return `<g transform="translate(${x} ${y})"><rect x="-14" y="-14" width="${w + 28}" height="${h + 28}" rx="8" fill="${C.wood}"/><rect width="${w}" height="${h}" rx="4" fill="#1F4E46"/>${content}</g>`;
}

// ===== المشاهد =====
const scenes = {};

scenes['hero-campus'] = () => svg(
  `<rect width="${W}" height="${H}" fill="url(#sky)"/>${sun(980, 140)}${mountains(470, '#B7CCD6')}${mountains(520, '#9DB6C3', .8)}` +
  ground(560) + `<rect y="560" width="${W}" height="30" fill="#D9C4A0"/>` +
  tower(170, 250, 110, 310) + tower(920, 250, 110, 310) + building(270, 300, 660, 260, { floors: 2, door: true, sign: true }) +
  omaniFlag(600, 120, .9) + palm(110, 590, 1) + palm(1100, 600, 1.1) + palm(1010, 610, .8) +
  person(380, 690, 1, 'boy', { bag: C.navy2 }) + person(470, 700, 1, 'girl', { book: C.gold }) + person(740, 700, 1, 'girl', { dress: C.navy3, bag: C.teal }) + person(830, 690, 1, 'boy', { book: C.teal, kuma: C.gold })
);

scenes['classroom'] = () => svg(
  `<rect width="${W}" height="${H}" fill="#EAF4F3"/><rect y="0" width="${W}" height="60" fill="url(#omani)"/>` +
  board(250, 110, 700, 280, `<text x="350" y="90" font-family="Arial" font-size="56" fill="#fff" text-anchor="middle" opacity=".9">2 + 3 = 5</text><path d="M120 170 h460" stroke="#fff" stroke-opacity=".5" stroke-width="4" stroke-dasharray="14 10"/><circle cx="560" cy="220" r="34" fill="none" stroke="${C.gold2}" stroke-width="5"/><path d="M80 230 l60 -60 l60 60z" fill="none" stroke="${C.teal2}" stroke-width="5"/>`) +
  `<rect y="520" width="${W}" height="230" fill="#D8C3A0"/>` +
  person(1010, 560, 1.15, 'woman', { dress: C.teal }) +
  desk(130, 560, 240) + desk(480, 560, 240) + desk(830, 600, 220) +
  person(200, 640, .9, 'girl', { raise: true }) + person(300, 640, .9, 'boy') + person(550, 640, .9, 'boy', { raise: true, kuma: C.gold }) + person(650, 640, .9, 'girl', { dress: C.navy3 }) +
  `<rect x="60" y="150" width="120" height="160" rx="6" fill="#fff" stroke="${C.gold}" stroke-width="4"/><circle cx="120" cy="210" r="34" fill="${C.teal}"/><rect x="80" y="262" width="80" height="10" rx="5" fill="${C.navy2}"/>`
);

scenes['library'] = () => svg(
  `<rect width="${W}" height="${H}" fill="#F6EFE2"/>` + bookshelf(60, 90, 360, 440) + bookshelf(780, 90, 360, 440) +
  `<path d="M480 90 h240 v300 a120 120 0 0 1 -240 0z" fill="#CFEFF0"/><path d="M600 90 v420 M480 270 h240" stroke="#fff" stroke-width="10"/>` +
  `<rect y="560" width="${W}" height="190" fill="#D2B48C"/>` + desk(420, 570, 360) +
  `<rect x="470" y="545" width="80" height="26" rx="3" fill="${C.teal}"/><rect x="560" y="550" width="70" height="20" rx="3" fill="${C.gold}"/><path d="M640 560 l40 -18 l40 18 l-40 10z" fill="#fff" stroke="${C.navy2}" stroke-width="2"/>` +
  person(480, 690, 1, 'girl', { book: C.teal }) + person(720, 690, 1, 'boy', { book: C.gold }) + person(260, 700, 1.05, 'girl', { dress: C.navy3, book: C.red })
);

scenes['science-lab'] = () => svg(
  `<rect width="${W}" height="${H}" fill="#E8F1F8"/><rect width="${W}" height="70" fill="${C.navy2}"/><rect y="60" width="${W}" height="10" fill="${C.gold}"/>` +
  `<rect y="520" width="${W}" height="230" fill="#C9D5DF"/><rect x="80" y="470" width="1040" height="40" rx="6" fill="${C.navy}"/><rect x="100" y="510" width="20" height="120" fill="${C.navy}"/><rect x="1080" y="510" width="20" height="120" fill="${C.navy}"/>` +
  `<path d="M300 470 l-30 -80 h60z" fill="${C.teal2}" opacity=".8"/><rect x="285" y="340" width="30" height="50" fill="#fff" stroke="${C.navy2}" stroke-width="3"/>` +
  `<rect x="420" y="380" width="22" height="90" rx="10" fill="#fff" stroke="${C.navy2}" stroke-width="3"/><rect x="423" y="420" width="16" height="48" rx="8" fill="${C.gold2}"/>` +
  `<rect x="460" y="380" width="22" height="90" rx="10" fill="#fff" stroke="${C.navy2}" stroke-width="3"/><rect x="463" y="430" width="16" height="38" rx="8" fill="${C.red}" opacity=".7"/>` +
  `<g transform="translate(820 470)"><rect x="-50" y="-12" width="100" height="12" fill="${C.navy2}"/><path d="M-10 -12 L10 -12 L30 -150 L10 -150Z" fill="${C.navy3}"/><rect x="0" y="-190" width="26" height="60" rx="8" fill="${C.navy2}" transform="rotate(-20)"/><circle cx="-10" cy="-60" r="18" fill="${C.teal}"/></g>` +
  `<circle cx="640" cy="190" r="70" fill="none" stroke="${C.teal}" stroke-width="5"/><ellipse cx="640" cy="190" rx="130" ry="40" fill="none" stroke="${C.gold}" stroke-width="5" transform="rotate(25 640 190)"/><ellipse cx="640" cy="190" rx="130" ry="40" fill="none" stroke="${C.teal2}" stroke-width="5" transform="rotate(-25 640 190)"/><circle cx="640" cy="190" r="16" fill="${C.red}"/>` +
  person(360, 700, 1, 'girl', { dress: '#fff' }) + person(600, 700, 1, 'boy', { kuma: C.gold }) + person(960, 700, 1.15, 'man', { massar: C.navy2 })
);

scenes['robotics'] = () => svg(
  `<rect width="${W}" height="${H}" fill="url(#skyN)"/><rect width="${W}" height="${H}" fill="url(#omani)" opacity=".6"/>` +
  `<g stroke="${C.teal2}" stroke-width="3" fill="none" opacity=".5"><path d="M0 120 h200 l40 40 h160"/><path d="M1200 200 h-180 l-40 -40 h-140"/><path d="M0 360 h120 l40 -40 h100"/></g>` +
  `<rect y="560" width="${W}" height="190" fill="#0E2846"/><rect x="300" y="520" width="600" height="40" rx="8" fill="${C.navy3}"/>` +
  `<g transform="translate(600 300)"><rect x="-110" y="0" width="220" height="200" rx="30" fill="#E9EEF3"/><rect x="-80" y="-130" width="160" height="120" rx="26" fill="#E9EEF3"/><rect x="-62" y="-110" width="124" height="70" rx="16" fill="${C.navy}"/><circle cx="-28" cy="-75" r="14" fill="${C.teal2}"/><circle cx="28" cy="-75" r="14" fill="${C.teal2}"/><rect x="-4" y="-170" width="8" height="40" fill="#E9EEF3"/><circle cy="-176" r="12" fill="${C.gold2}"/><rect x="-60" y="40" width="120" height="70" rx="12" fill="${C.teal}"/><circle cx="-30" cy="75" r="10" fill="#fff"/><circle cx="0" cy="75" r="10" fill="${C.gold2}"/><circle cx="30" cy="75" r="10" fill="#fff"/><rect x="-160" y="20" width="50" height="22" rx="11" fill="#C9D3DD"/><rect x="110" y="20" width="50" height="22" rx="11" fill="#C9D3DD"/><circle cx="-80" cy="210" r="26" fill="${C.navy2}"/><circle cx="80" cy="210" r="26" fill="${C.navy2}"/></g>` +
  person(200, 700, 1.05, 'boy', { kuma: C.gold }) + person(1000, 700, 1.05, 'girl', { dress: C.teal }) +
  `<rect x="880" y="440" width="120" height="80" rx="8" fill="#1B3B60" stroke="${C.teal2}" stroke-width="3"/><path d="M900 470 h40 M900 490 h70" stroke="${C.teal2}" stroke-width="4"/>`
);

scenes['sports'] = () => svg(
  `<rect width="${W}" height="${H}" fill="url(#sky)"/>${sun(150, 120, 40)}${mountains(380, '#B7CCD6')}` +
  `<rect y="380" width="${W}" height="370" fill="#3FA463"/><g stroke="#fff" stroke-width="5" fill="none" opacity=".85"><rect x="80" y="420" width="1040" height="300"/><path d="M600 420 v300"/><circle cx="600" cy="570" r="70"/><rect x="80" y="500" width="110" height="140"/><rect x="1010" y="500" width="110" height="140"/></g>` +
  `<g transform="translate(1060 520)"><rect width="10" height="110" fill="#fff"/><rect x="60" width="10" height="110" fill="#fff"/><rect width="70" height="10" fill="#fff"/></g>` +
  person(420, 690, 1.05, 'boy', { kuma: C.gold }) + person(760, 670, 1, 'boy', { raise: true }) +
  `<circle cx="560" cy="660" r="22" fill="#fff"/><path d="M560 638 l8 12 l-8 10 l-8 -10z M538 656 l12 2 M582 656 l-12 2" stroke="${C.navy}" stroke-width="3" fill="${C.navy}"/>` +
  `<g transform="translate(200 300)"><rect width="140" height="70" rx="8" fill="${C.navy}"/><rect x="10" y="10" width="120" height="50" rx="4" fill="${C.teal}"/><rect x="65" y="70" width="10" height="80" fill="${C.navy}"/></g>`
);

scenes['art'] = () => svg(
  `<rect width="${W}" height="${H}" fill="#FBF3E7"/><rect y="560" width="${W}" height="190" fill="#E2CBA4"/>` +
  `<g transform="translate(380 140)"><path d="M40 420 L120 0 L140 0 L60 420Z M320 420 L240 0 L220 0 L300 420Z" fill="${C.wood}"/><rect x="40" y="40" width="300" height="230" fill="#fff" stroke="${C.wood}" stroke-width="8"/>` +
  `<rect x="60" y="60" width="260" height="190" fill="#D9F2EF"/><path d="M60 250 L130 150 L180 200 L240 110 L320 250Z" fill="${C.teal}"/><circle cx="270" cy="100" r="22" fill="${C.gold2}"/><rect x="90" y="190" width="70" height="60" fill="${C.sand2}"/><path d="M90 190 l35 -26 l35 26" fill="${C.sand3}"/></g>` +
  `<g transform="translate(860 420)"><path d="M0 0 C 60 -60 180 -40 180 30 C 180 90 100 80 80 110 C 60 140 -40 120 0 0Z" fill="#F3E2C0"/><circle cx="40" cy="10" r="14" fill="${C.red}"/><circle cx="90" cy="-8" r="14" fill="${C.gold}"/><circle cx="140" cy="20" r="14" fill="${C.teal}"/><circle cx="130" cy="64" r="14" fill="${C.navy2}"/></g>` +
  person(250, 700, 1.05, 'girl', { dress: C.navy3, raise: true }) + person(820, 700, 1, 'boy', { kuma: C.teal }) +
  `<g opacity=".9"><rect x="60" y="80" width="140" height="100" fill="#fff" stroke="${C.gold}" stroke-width="5"/><circle cx="130" cy="130" r="30" fill="${C.teal2}"/><rect x="980" y="80" width="150" height="110" fill="#fff" stroke="${C.gold}" stroke-width="5"/><path d="M1000 170 q 50 -90 110 0" fill="${C.gold2}"/></g>`
);

scenes['national-day'] = () => {
  const bunting = [];
  for (let i = 0; i < 16; i++) bunting.push(`<path d="M${i * 78 + 10} ${70 + Math.sin(i / 2) * 6} l34 0 l-17 40z" fill="${[C.red, '#fff', C.green][i % 3]}" stroke="#CCD" stroke-width="1"/>`);
  return svg(
    `<rect width="${W}" height="${H}" fill="url(#sky)"/><path d="M0 70 Q 600 110 1200 70" stroke="${C.navy2}" stroke-width="3" fill="none"/>${bunting.join('')}` +
    mountains(500, '#B7CCD6') + ground(520, '#E6D3AE') + building(330, 300, 540, 220, { floors: 2, door: true }) +
    omaniFlag(150, 220, 1.1) + omaniFlag(1000, 220, 1.1) +
    [180, 300, 420, 540, 660, 780, 900, 1020].map((x, i) => person(x, 720 - (i % 2) * 8, .95, i % 2 ? 'girl' : 'boy', { raise: i % 3 === 0, kuma: C.red, dress: i % 4 === 1 ? C.green : C.teal })).join('') +
    `<g fill="${C.gold2}"><circle cx="600" cy="160" r="6"/><circle cx="560" cy="190" r="4"/><circle cx="640" cy="190" r="4"/></g>`
  );
};

scenes['environment'] = () => svg(
  `<rect width="${W}" height="${H}" fill="url(#sky)"/>${sun(1040, 120)}${mountains(420, '#B9D4C4')}<rect y="440" width="${W}" height="310" fill="#C9B18A"/>` +
  `<path d="M0 520 Q 300 480 600 520 T 1200 520 V750 H0Z" fill="#B49A70"/>` +
  [[200, 560], [420, 600], [680, 560], [920, 600]].map(([x, y], i) => `<g transform="translate(${x} ${y})"><ellipse rx="60" ry="14" fill="#8C6C45"/><rect x="-5" y="-90" width="10" height="90" fill="${C.wood}"/><circle cy="-110" r="${40 + i * 4}" fill="#3FA463"/><circle cx="-26" cy="-90" r="26" fill="#2E8B57"/><circle cx="26" cy="-92" r="24" fill="#4CB873"/></g>`).join('') +
  person(300, 720, 1, 'girl', { dress: C.teal }) + person(560, 720, 1, 'boy', { kuma: C.green }) + person(820, 720, 1, 'girl', { dress: C.navy3 }) +
  `<g transform="translate(640 650)"><path d="M0 0 h60 v40 h-60z" fill="${C.teal}"/><path d="M60 8 l40 -20" stroke="${C.teal}" stroke-width="8"/><circle cx="104" cy="-14" r="4" fill="#6CC"/><circle cx="112" cy="-4" r="3" fill="#6CC"/></g>` +
  `<g transform="translate(1040 500)"><rect x="-30" y="0" width="60" height="70" rx="6" fill="${C.green}"/><path d="M-14 22 l14 -14 l14 14 M0 8 v30" stroke="#fff" stroke-width="5" fill="none"/></g>`
);

scenes['honoring'] = () => svg(
  `<rect width="${W}" height="${H}" fill="url(#skyN)"/><rect width="${W}" height="${H}" fill="url(#omani)" opacity=".7"/>` +
  `<g opacity=".25" fill="${C.gold2}"><path d="M600 0 L380 750 H820Z"/></g>` +
  `<rect x="200" y="520" width="800" height="70" fill="${C.navy3}"/><rect x="200" y="510" width="800" height="14" fill="${C.gold}"/><rect y="590" width="${W}" height="160" fill="#0A1A30"/>` +
  `<g transform="translate(600 300)"><path d="M-90 -120 h180 v40 c0 80 -40 120 -90 130 c-50 -10 -90 -50 -90 -130z" fill="url(#goldG)"/><path d="M-90 -100 c-60 0 -60 70 0 80 M90 -100 c60 0 60 70 0 80" stroke="${C.gold}" stroke-width="12" fill="none"/><rect x="-14" y="50" width="28" height="60" fill="${C.gold}"/><rect x="-70" y="110" width="140" height="34" rx="6" fill="${C.gold2}"/><path d="M0 -90 l12 26 l28 3 l-21 19 l6 28 l-25 -14 l-25 14 l6 -28 l-21 -19 l28 -3z" fill="#fff" opacity=".85"/></g>` +
  person(330, 510, 1.05, 'girl', { dress: C.teal, raise: true }) + person(860, 510, 1.05, 'boy', { kuma: C.gold, raise: true }) +
  `<g fill="${C.gold2}">${Array.from({ length: 30 }, (_, i) => `<rect x="${(i * 137) % 1200}" y="${(i * 71) % 260 + 20}" width="10" height="16" transform="rotate(${i * 23} ${(i * 137) % 1200} ${(i * 71) % 260 + 20})" opacity=".8" fill="${[C.gold2, C.teal2, '#fff'][i % 3]}"/>`).join('')}</g>`
);

scenes['parents'] = () => svg(
  `<rect width="${W}" height="${H}" fill="#EEF5F4"/><rect width="${W}" height="${H}" fill="url(#omani)" opacity=".5"/><rect y="560" width="${W}" height="190" fill="#D8C3A0"/>` +
  `<rect x="420" y="100" width="360" height="220" rx="12" fill="#fff" stroke="${C.navy2}" stroke-width="6"/><rect x="450" y="130" width="300" height="20" rx="10" fill="${C.teal}"/><rect x="450" y="170" width="240" height="14" rx="7" fill="${C.gray}"/><rect x="450" y="200" width="270" height="14" rx="7" fill="${C.gray}"/><rect x="450" y="250" width="120" height="40" rx="8" fill="${C.gold}"/>` +
  `<ellipse cx="600" cy="560" rx="380" ry="40" fill="${C.wood}"/><rect x="230" y="560" width="740" height="18" fill="#6B4A2B"/>` +
  person(320, 640, 1, 'man', { massar: C.teal }) + person(470, 640, 1, 'woman', { dress: C.navy2 }) + person(730, 640, 1, 'woman', { dress: C.teal }) + person(880, 640, 1, 'man', { massar: C.gold }) +
  `<g transform="translate(600 520)"><rect x="-40" y="-24" width="80" height="24" rx="3" fill="#fff" stroke="${C.navy2}" stroke-width="2"/><rect x="-30" y="-16" width="40" height="4" fill="${C.teal}"/></g>`
);

scenes['partnership'] = () => svg(
  `<rect width="${W}" height="${H}" fill="url(#sky)"/>${mountains(440, '#B7CCD6')}${ground(460, '#E6D3AE')}` +
  building(80, 270, 380, 190, { floors: 1, door: true }) +
  `<g transform="translate(760 210)"><rect width="340" height="250" fill="#D6E2EA"/>${Array.from({ length: 12 }, (_, i) => `<rect x="${24 + (i % 4) * 80}" y="${24 + Math.floor(i / 4) * 70}" width="50" height="44" fill="${C.navy2}" opacity=".85"/>`).join('')}<rect x="140" y="190" width="60" height="60" fill="${C.navy}"/></g>` +
  `<g transform="translate(600 320)"><circle r="90" fill="#fff" opacity=".9"/><path d="M-62 10 l30 -30 l30 10 l30 -10 l30 30 l-40 34 q-20 14 -40 0z" fill="${C.skin1}"/><path d="M-62 10 l-18 -18 l30 -30 l20 18z" fill="${C.teal}"/><path d="M62 10 l18 -18 l-30 -30 l-20 18z" fill="${C.navy2}"/></g>` +
  person(330, 690, 1, 'man', { massar: C.teal }) + person(470, 690, 1, 'boy') + person(760, 690, 1, 'woman', { dress: C.navy3 }) + person(900, 690, 1, 'man', { massar: C.gold })
);

scenes['digital'] = () => svg(
  `<rect width="${W}" height="${H}" fill="#EAF2FA"/><rect y="0" width="${W}" height="${H}" fill="url(#omani)" opacity=".4"/>` +
  `<g transform="translate(330 120)"><rect width="540" height="340" rx="22" fill="${C.navy}"/><rect x="20" y="20" width="500" height="300" rx="10" fill="#fff"/><rect x="40" y="40" width="200" height="20" rx="10" fill="${C.teal}"/><rect x="40" y="80" width="460" height="120" rx="10" fill="${C.tealL}"/><path d="M60 180 l60 -50 l50 30 l70 -70 l60 40 l60 -30 l80 50" stroke="${C.navy2}" stroke-width="6" fill="none"/><rect x="40" y="220" width="140" height="80" rx="10" fill="${C.sand}"/><rect x="200" y="220" width="140" height="80" rx="10" fill="${C.gold2}"/><rect x="360" y="220" width="140" height="80" rx="10" fill="${C.teal2}"/></g>` +
  `<rect y="560" width="${W}" height="190" fill="#C9D5DF"/>` + desk(200, 560, 260) + desk(740, 560, 260) +
  `<rect x="250" y="520" width="150" height="40" rx="6" fill="${C.navy2}" transform="skewX(-10)"/><rect x="800" y="520" width="150" height="40" rx="6" fill="${C.navy2}" transform="skewX(-10)"/>` +
  person(330, 680, .95, 'girl', { dress: C.teal }) + person(870, 680, .95, 'boy', { kuma: C.gold })
);

scenes['math'] = () => svg(
  `<rect width="${W}" height="${H}" fill="#F8F2E6"/>` +
  board(160, 90, 880, 380, `<g font-family="Arial" fill="#fff" font-size="60" text-anchor="middle"><text x="160" y="110">π</text><text x="440" y="110">√49 = 7</text><text x="720" y="110">∑</text></g><path d="M100 320 L260 160 L420 320Z" fill="none" stroke="${C.gold2}" stroke-width="6"/><circle cx="600" cy="250" r="80" fill="none" stroke="${C.teal2}" stroke-width="6"/><path d="M600 250 L680 250" stroke="${C.teal2}" stroke-width="4"/><rect x="740" y="180" width="120" height="120" fill="none" stroke="#fff" stroke-width="6"/>`) +
  `<rect y="560" width="${W}" height="190" fill="#D8C3A0"/>` + person(300, 700, 1, 'boy', { raise: true, kuma: C.teal }) + person(600, 700, 1.15, 'man', { massar: C.navy2 }) + person(900, 700, 1, 'girl', { book: C.gold })
);

scenes['quran-arabic'] = () => svg(
  `<rect width="${W}" height="${H}" fill="#F4EEE2"/><rect width="${W}" height="${H}" fill="url(#omani)"/>` +
  `<g transform="translate(600 300)"><path d="M-260 -40 L0 0 L260 -40 L260 160 L0 200 L-260 160Z" fill="#fff" stroke="${C.gold}" stroke-width="6"/><path d="M0 0 V200" stroke="${C.gold}" stroke-width="5"/>${[0, 1, 2, 3, 4].map((i) => `<path d="M-230 ${i * 34} Q -120 ${i * 34 - 10} -30 ${i * 34 + 6}" stroke="${C.navy2}" stroke-width="5" fill="none" opacity=".7"/><path d="M30 ${i * 34 + 6} Q 120 ${i * 34 - 10} 230 ${i * 34}" stroke="${C.navy2}" stroke-width="5" fill="none" opacity=".7"/>`).join('')}<path d="M-120 200 L-80 260 L80 260 L120 200" fill="${C.wood}"/></g>` +
  `<rect y="600" width="${W}" height="150" fill="#D2B48C"/>` + person(250, 720, 1, 'boy', { kuma: C.gold }) + person(950, 720, 1, 'girl', { dress: C.teal })
);

// صور رمزية للهيئة الإدارية
const avatar = (t) => svg(
  `<rect width="400" height="400" fill="${t === 'man' ? '#DDEFF0' : '#F3EBDD'}"/><circle cx="200" cy="200" r="190" fill="url(#omani)"/>` + person(200, 470, 2.1, t, { massar: C.teal, dress: C.navy2 }), '', 400, 400
);

// الشعار
const logo = () => `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 120 120" role="img" aria-label="شعار نبض النمارق">
<defs><linearGradient id="lg" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="${C.teal2}"/><stop offset="1" stop-color="${C.teal}"/></linearGradient><linearGradient id="lg2" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="${C.gold2}"/><stop offset="1" stop-color="${C.gold}"/></linearGradient></defs>
<path d="M60 4 L104 22 L104 62 Q104 98 60 116 Q16 98 16 62 L16 22Z" fill="${C.navy}"/>
<path d="M60 12 L97 27 L97 62 Q97 92 60 108 Q23 92 23 62 L23 27Z" fill="none" stroke="url(#lg2)" stroke-width="3"/>
<path d="M34 78 Q60 66 60 74 Q60 66 86 78 L86 48 Q60 38 60 46 Q60 38 34 48Z" fill="#fff"/>
<path d="M60 46 V74" stroke="${C.navy}" stroke-width="2"/>
<path d="M26 60 H44 L50 48 L58 72 L66 40 L72 60 H94" fill="none" stroke="url(#lg)" stroke-width="5" stroke-linecap="round" stroke-linejoin="round"/>
<circle cx="60" cy="28" r="5" fill="url(#lg2)"/></svg>`;

const pattern = () => `<svg xmlns="http://www.w3.org/2000/svg" width="80" height="80" viewBox="0 0 80 80"><g fill="none" stroke="${C.gold}" stroke-opacity=".22" stroke-width="1.4"><path d="M40 4 L76 40 L40 76 L4 40Z"/><path d="M40 18 L62 40 L40 62 L18 40Z"/><circle cx="40" cy="40" r="6"/><path d="M0 0 L12 12 M80 0 L68 12 M0 80 L12 68 M80 80 L68 68"/></g></svg>`;

for (const [name, fn] of Object.entries(scenes)) fs.writeFileSync(path.join(OUT, name + '.svg'), fn());
fs.writeFileSync(path.join(OUT, 'avatar-man.svg'), avatar('man'));
fs.writeFileSync(path.join(OUT, 'avatar-woman.svg'), avatar('woman'));
fs.writeFileSync(path.join(OUT, 'logo.svg'), logo());
fs.writeFileSync(path.join(OUT, 'favicon.svg'), logo());
fs.writeFileSync(path.join(OUT, 'pattern.svg'), pattern());
console.log('تم توليد', Object.keys(scenes).length + 5, 'صورة في', OUT);
