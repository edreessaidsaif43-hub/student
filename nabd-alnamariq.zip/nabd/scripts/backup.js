'use strict';
// نسخة احتياطية من قاعدة البيانات المحلية (SQLite) إلى مجلد backups/
const fs = require('node:fs');
const path = require('node:path');
const config = require('../src/config');
const { DatabaseSync } = require('node:sqlite');

if (config.tursoUrl) { console.log('قاعدة Turso: استخدم الأمر  turso db shell <name> .dump > backup.sql  أو النسخ التلقائي في لوحة Turso.'); process.exit(0); }
const dir = path.join(config.root, 'backups');
fs.mkdirSync(dir, { recursive: true });
const out = path.join(dir, 'nabd-' + new Date().toISOString().replace(/[:.]/g, '-').slice(0, 19) + '.db');
const db = new DatabaseSync(config.dbPath);
db.exec(`VACUUM INTO '${out.replace(/'/g, "''")}'`);
db.close();
console.log('تم حفظ النسخة الاحتياطية:', out);
