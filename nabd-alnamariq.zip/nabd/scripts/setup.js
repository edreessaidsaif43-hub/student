'use strict';
// تهيئة قاعدة البيانات وإدخال البيانات الأساسية والتجريبية
//   npm run setup          ← تهيئة (آمنة، لا تحذف شيئًا)
//   npm run reset          ← حذف قاعدة البيانات المحلية وإعادة إنشائها
const fs = require('node:fs');
const config = require('../src/config');
const db = require('../src/db');
const { ensureBase, seedDemo } = require('../src/seed');

(async () => {
  if (process.argv.includes('--reset')) {
    if (config.tursoUrl) { console.error('لا يمكن تنفيذ reset على قاعدة Turso من هنا. احذف القاعدة من لوحة Turso.'); process.exit(1); }
    for (const f of [config.dbPath, config.dbPath + '-wal', config.dbPath + '-shm']) fs.rmSync(f, { force: true });
    console.log('تم حذف قاعدة البيانات المحلية.');
  }
  await db.open();
  const pw = await ensureBase();
  if (pw) console.log(`\nحساب المدير: ${config.adminEmail}\nكلمة المرور المؤقتة: ${pw}\n`);
  if (config.seedDemo) console.log((await seedDemo()) ? 'تم إدخال المحتوى التجريبي.' : 'المحتوى التجريبي موجود مسبقًا.');
  console.log('قاعدة البيانات جاهزة (' + db.engine() + ').');
  await db.close();
})().catch((e) => { console.error(e); process.exit(1); });
