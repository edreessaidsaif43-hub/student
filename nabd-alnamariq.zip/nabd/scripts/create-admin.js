'use strict';
// إنشاء مدير نظام جديد أو إعادة تعيين كلمة مروره
//   npm run create-admin -- email@example.com "كلمة مرور قوية123" "الاسم"
const db = require('../src/db');
const { hashPassword, passwordProblem } = require('../src/core/security');
const { ensureBase } = require('../src/seed');

(async () => {
  const [email, password, name = 'مدير النظام'] = process.argv.slice(2);
  if (!email || !password) { console.error('الاستخدام: npm run create-admin -- email password [name]'); process.exit(1); }
  const p = passwordProblem(password); if (p) { console.error(p); process.exit(1); }
  await db.open(); await ensureBase();
  const role = await db.get("SELECT id FROM roles WHERE name = 'admin'");
  const ex = await db.get('SELECT id FROM users WHERE email = ?', email.toLowerCase());
  if (ex) { await db.run('UPDATE users SET password_hash = ?, role_id = ?, active = 1, must_change_password = 0 WHERE id = ?', hashPassword(password), role.id, ex.id); console.log('تم تحديث كلمة مرور المدير:', email); }
  else { await db.insert('users', { name, email: email.toLowerCase(), password_hash: hashPassword(password), role_id: role.id }); console.log('تم إنشاء المدير:', email); }
  await db.close();
})().catch((e) => { console.error(e); process.exit(1); });
