/* نبض النمارق — تفاعلات لوحة التحكم */
(function () {
  'use strict';
  var d = document;
  var $ = function (s, c) { return (c || d).querySelector(s); };
  var $$ = function (s, c) { return Array.prototype.slice.call((c || d).querySelectorAll(s)); };
  var csrfMeta = $('meta[name=csrf]');
  var csrf = csrfMeta ? csrfMeta.content : '';
  var esc = function (s) { return String(s || '').replace(/[&<>"]/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]; }); };

  // القائمة الجانبية للجوال
  var sb = $('#sidebar'), tg = $('#sb-toggle');
  if (tg) tg.addEventListener('click', function (e) { e.stopPropagation(); sb.classList.toggle('open'); });
  d.addEventListener('click', function (e) { if (sb && sb.classList.contains('open') && !e.target.closest('#sidebar')) sb.classList.remove('open'); });

  // تأكيد الإجراءات الحساسة
  d.addEventListener('click', function (e) {
    var b = e.target.closest('[data-confirm]');
    if (b && b.tagName !== 'FORM' && !confirm(b.getAttribute('data-confirm'))) { e.preventDefault(); e.stopPropagation(); }
  }, true);
  $$('form[data-confirm]').forEach(function (f) { f.addEventListener('submit', function (e) { if (!confirm(f.getAttribute('data-confirm'))) e.preventDefault(); }); });

  // تحديد الكل
  $$('[data-check-all]').forEach(function (c) {
    c.addEventListener('change', function () { $$('input[name=ids]', c.closest('form')).forEach(function (i) { i.checked = c.checked; }); });
  });

  // تحذير عند مغادرة نموذج معدّل
  $$('form[data-dirty]').forEach(function (f) {
    var dirty = false;
    f.addEventListener('input', function () { dirty = true; });
    f.addEventListener('change', function () { dirty = true; });
    f.addEventListener('submit', function () { dirty = false; syncGrids(f); });
    window.addEventListener('beforeunload', function (e) { if (dirty) { e.preventDefault(); e.returnValue = ''; } });
  });

  // نسخ
  $$('[data-copy]').forEach(function (b) {
    b.addEventListener('click', function () {
      var t = b.getAttribute('data-copy'); if (t.charAt(0) === '/') t = location.origin + t;
      var old = b.textContent;
      (navigator.clipboard ? navigator.clipboard.writeText(t) : Promise.reject()).then(function () { b.textContent = '✓ تم'; setTimeout(function () { b.textContent = old; }, 1500); }, function () { prompt('انسخ:', t); });
    });
  });

  // منطقة الرفع
  $$('.drop').forEach(function (z) {
    var inp = $('input[type=file]', z);
    ['dragenter', 'dragover'].forEach(function (ev) { z.addEventListener(ev, function (e) { e.preventDefault(); z.classList.add('over'); }); });
    ['dragleave', 'drop'].forEach(function (ev) { z.addEventListener(ev, function (e) { e.preventDefault(); z.classList.remove('over'); }); });
    z.addEventListener('drop', function (e) { inp.files = e.dataTransfer.files; inp.dispatchEvent(new Event('change')); });
    inp.addEventListener('change', function () { z.classList.toggle('has', inp.files.length > 0); $('b', z).textContent = inp.files.length ? inp.files.length + ' ملف جاهز للرفع' : 'اسحب الملفات هنا أو انقر للاختيار'; });
  });

  // حقول الملفات + مكتبة الوسائط
  var picker = $('#picker'), pickCb = null, pickKind = '';
  function setPreview(ff, path, name) {
    var prev = $('.ff-preview', ff);
    $('.ff-value', ff).value = path || '';
    if (!path) prev.innerHTML = '<span class="muted">لا يوجد ملف</span>';
    else if (/\.(png|jpe?g|webp|gif|svg)$/i.test(path)) prev.innerHTML = '<img src="' + esc(path) + '" alt="">';
    else prev.innerHTML = '<span>' + esc(name || path.split('/').pop()) + '</span>';
    ff.closest('form') && ff.closest('form').dispatchEvent(new Event('change'));
  }
  $$('.file-field').forEach(function (ff) {
    var up = $('.ff-upload', ff);
    up.addEventListener('change', function () {
      var f = up.files[0]; if (!f) return;
      var prev = $('.ff-preview', ff);
      if (/^image\//.test(f.type)) { var r = new FileReader(); r.onload = function () { prev.innerHTML = '<img src="' + r.result + '" alt="">'; }; r.readAsDataURL(f); }
      else prev.innerHTML = '<span>' + esc(f.name) + '</span>';
    });
    $('[data-clear]', ff).addEventListener('click', function () { up.value = ''; setPreview(ff, ''); });
    $('[data-pick]', ff).addEventListener('click', function () {
      openPicker(ff.getAttribute('data-kind'), function (file) { up.value = ''; setPreview(ff, file.path, file.original_name); });
    });
  });
  function openPicker(kind, cb) {
    if (!picker) return;
    pickCb = cb; pickKind = kind || ''; picker.hidden = false; loadPicker('');
    $('.picker-q', picker).value = ''; $('.picker-q', picker).focus();
  }
  function loadPicker(q) {
    var grid = $('.picker-grid', picker);
    grid.innerHTML = '<p class="muted">جارٍ التحميل…</p>';
    fetch('/admin/api/files?kind=' + encodeURIComponent(pickKind) + '&q=' + encodeURIComponent(q), { credentials: 'same-origin' })
      .then(function (r) { return r.json(); }).then(function (j) {
        if (!j.files || !j.files.length) { grid.innerHTML = '<p class="muted">لا توجد ملفات.</p>'; return; }
        grid.innerHTML = j.files.map(function (f, i) {
          return '<button type="button" data-i="' + i + '">' + (f.kind === 'image' ? '<img src="' + esc(f.path) + '" alt="" loading="lazy">' : '<div class="pf">' + esc(f.path.split('.').pop().toUpperCase()) + '</div>') + '<span>' + esc(f.original_name) + '</span></button>';
        }).join('');
        $$('button', grid).forEach(function (b) { b.addEventListener('click', function () { var f = j.files[+b.getAttribute('data-i')]; picker.hidden = true; if (pickCb) pickCb(f); }); });
      }).catch(function () { grid.innerHTML = '<p class="muted">تعذّر التحميل.</p>'; });
  }
  if (picker) {
    var t;
    $('.picker-q', picker).addEventListener('input', function (e) { clearTimeout(t); t = setTimeout(function () { loadPicker(e.target.value); }, 300); });
    $('[data-close-modal]', picker).addEventListener('click', function () { picker.hidden = true; });
    picker.addEventListener('click', function (e) { if (e.target === picker) picker.hidden = true; });
    d.addEventListener('keydown', function (e) { if (e.key === 'Escape') picker.hidden = true; });
    $('.picker-up', picker).addEventListener('change', function (e) {
      var f = e.target.files[0]; if (!f) return;
      var fd = new FormData(); fd.append('file', f); fd.append('kind', pickKind);
      var grid = $('.picker-grid', picker); grid.innerHTML = '<p class="muted">جارٍ الرفع…</p>';
      fetch('/admin/api/upload', { method: 'POST', body: fd, headers: { 'X-CSRF-Token': csrf }, credentials: 'same-origin' })
        .then(function (r) { return r.json(); }).then(function (j) {
          if (j.error) { alert(j.error); loadPicker(''); return; }
          picker.hidden = true; if (pickCb) pickCb({ path: j.path, original_name: j.original_name });
        }).catch(function () { alert('تعذّر رفع الملف'); });
      e.target.value = '';
    });
  }

  // محرر Markdown
  $$('.md-field').forEach(function (box) {
    var ta = $('textarea', box), pv = $('.md-preview', box);
    function wrap(before, after, ph) {
      var s = ta.selectionStart, e = ta.selectionEnd, sel = ta.value.slice(s, e) || ph || '';
      ta.setRangeText(before + sel + (after || ''), s, e, 'end'); ta.focus(); ta.dispatchEvent(new Event('input', { bubbles: true }));
    }
    function linePrefix(p) {
      var s = ta.selectionStart, e = ta.selectionEnd, v = ta.value;
      var ls = v.lastIndexOf('\n', s - 1) + 1, block = v.slice(ls, e) || 'نص';
      var out = block.split('\n').map(function (l, i) { return (p === '1. ' ? (i + 1) + '. ' : p) + l; }).join('\n');
      ta.setRangeText(out, ls, Math.max(e, ls), 'end'); ta.focus(); ta.dispatchEvent(new Event('input', { bubbles: true }));
    }
    $$('[data-md]', box).forEach(function (b) {
      b.addEventListener('click', function () {
        var a = b.getAttribute('data-md');
        if (a === 'bold') wrap('**', '**', 'نص عريض');
        else if (a === 'h2') linePrefix('## ');
        else if (a === 'ul') linePrefix('- ');
        else if (a === 'ol') linePrefix('1. ');
        else if (a === 'quote') linePrefix('> ');
        else if (a === 'link') { var u = prompt('أدخل الرابط (https://… أو /صفحة):', 'https://'); if (u) wrap('[', '](' + u + ')', 'نص الرابط'); }
        else if (a === 'image') openPicker('image', function (f) { wrap('![' + (f.original_name || 'صورة') + '](' + f.path + ')', '', ''); });
      });
    });
    $$('.md-tab', box).forEach(function (b) {
      b.addEventListener('click', function () {
        var prev = b.getAttribute('data-tab') === 'preview';
        $$('.md-tab', box).forEach(function (x) { x.classList.toggle('on', x === b); });
        ta.hidden = prev; pv.hidden = !prev;
        if (prev) {
          pv.innerHTML = '<p class="muted">جارٍ المعاينة…</p>';
          fetch('/admin/api/preview', { method: 'POST', headers: { 'Content-Type': 'application/json', 'X-CSRF-Token': csrf }, body: JSON.stringify({ text: ta.value }), credentials: 'same-origin' })
            .then(function (r) { return r.json(); }).then(function (j) { pv.innerHTML = j.html || '<p class="muted">لا يوجد محتوى.</p>'; });
        }
      });
    });
  });

  // محرر الجداول
  function syncGrids(scope) {
    $$('.grid-editor', scope).forEach(function (ge) {
      var periods = $$('thead .ge-period', ge).map(function (i) { return i.value; });
      var rows = $$('tbody tr', ge);
      var dayLabels = rows.map(function (r) { return $('.ge-day', r).value; });
      var cells = rows.map(function (r) { return $$('.ge-cell', r).map(function (i) { return i.value; }); });
      $('.ge-value', ge).value = JSON.stringify({ periods: periods, cells: cells, dayLabels: dayLabels });
    });
  }
  $$('.grid-editor').forEach(function (ge) {
    $$('[data-ge]', ge).forEach(function (b) {
      b.addEventListener('click', function () {
        var a = b.getAttribute('data-ge'), headRow = $('thead tr', ge), rows = $$('tbody tr', ge);
        if (a === 'addcol') {
          var th = d.createElement('th'); th.innerHTML = '<input class="ge-period" placeholder="الوقت / العنوان">'; headRow.appendChild(th);
          rows.forEach(function (r) { var td = d.createElement('td'); td.innerHTML = '<input class="ge-cell">'; r.appendChild(td); });
        } else if (a === 'delcol' && headRow.children.length > 2) {
          headRow.lastElementChild.remove(); rows.forEach(function (r) { r.lastElementChild.remove(); });
        } else if (a === 'addrow') {
          var tr = d.createElement('tr'), n = headRow.children.length - 1;
          tr.innerHTML = '<th><input class="ge-day"></th>' + new Array(n + 1).join('<td><input class="ge-cell"></td>');
          $('tbody', ge).appendChild(tr);
        } else if (a === 'delrow' && rows.length > 1) rows[rows.length - 1].remove();
        syncGrids(ge.parentElement);
      });
    });
    ge.addEventListener('input', function () { syncGrids(ge.parentElement); });
  });

  // محرر الأسئلة
  $$('.q-editor').forEach(function (qe) {
    var list = $('.q-list', qe), tpl = $('#q-tpl', qe);
    function bind(row) { $('[data-q=del]', row).addEventListener('click', function () { if (confirm('حذف السؤال؟')) row.remove(); }); }
    $$('.q-row', list).forEach(bind);
    $('[data-q=add]', qe).addEventListener('click', function () {
      var row = tpl.content.firstElementChild.cloneNode(true); list.appendChild(row); bind(row); $('.q-text', row).focus();
    });
  });

  // منع الإرسال المزدوج
  $$('form[method=post]').forEach(function (f) {
    f.addEventListener('submit', function (e) {
      if (e.defaultPrevented) return;
      setTimeout(function () { $$('button', f).forEach(function (b) { b.disabled = true; }); }, 0);
    });
  });
})();
