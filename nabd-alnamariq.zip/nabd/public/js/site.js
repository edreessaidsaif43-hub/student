/* نبض النمارق — تفاعلات الواجهة الأمامية (بدون مكتبات) */
(function () {
  'use strict';
  var d = document, root = d.documentElement;
  root.classList.add('js');
  var $ = function (s, c) { return (c || d).querySelector(s); };
  var $$ = function (s, c) { return Array.prototype.slice.call((c || d).querySelectorAll(s)); };
  var store = {
    get: function (k) { try { return localStorage.getItem(k); } catch (e) { return null; } },
    set: function (k, v) { try { localStorage.setItem(k, v); } catch (e) { /* */ } },
  };
  var nf = new Intl.NumberFormat('ar-OM-u-nu-latn');

  // حجم الخط (سهولة الوصول)
  if (store.get('nabd_big') === '1') root.classList.add('big-text');
  var a11y = $('#a11y-btn');
  if (a11y) a11y.addEventListener('click', function () {
    var on = root.classList.toggle('big-text'); store.set('nabd_big', on ? '1' : '0');
    a11y.setAttribute('aria-pressed', on);
  });

  // ترويسة ثابتة + زر العودة للأعلى
  var hdr = $('.site-header'), top = $('.to-top');
  var onScroll = function () {
    var y = window.scrollY;
    if (hdr) hdr.classList.toggle('scrolled', y > 10);
    if (top) top.hidden = y < 600;
  };
  window.addEventListener('scroll', onScroll, { passive: true }); onScroll();
  if (top) top.addEventListener('click', function () { window.scrollTo({ top: 0, behavior: 'smooth' }); });

  // القائمة على الجوال
  var nav = $('#main-nav'), burger = $('.burger'), backdrop;
  function closeNav() { if (!nav) return; nav.classList.remove('open'); burger.setAttribute('aria-expanded', 'false'); if (backdrop) { backdrop.remove(); backdrop = null; } }
  if (burger) burger.addEventListener('click', function () {
    var open = nav.classList.toggle('open');
    burger.setAttribute('aria-expanded', open);
    if (open) { backdrop = d.createElement('div'); backdrop.className = 'nav-backdrop'; backdrop.addEventListener('click', closeNav); d.body.appendChild(backdrop); }
    else closeNav();
  });
  $$('.menu-btn').forEach(function (b) {
    b.addEventListener('click', function () {
      var li = b.parentElement, open = !li.classList.contains('open');
      $$('.has-menu.open').forEach(function (x) { if (x !== li) { x.classList.remove('open'); $('.menu-btn', x).setAttribute('aria-expanded', 'false'); } });
      li.classList.toggle('open', open); b.setAttribute('aria-expanded', open);
    });
  });
  d.addEventListener('click', function (e) {
    if (!e.target.closest('.has-menu')) $$('.has-menu.open').forEach(function (x) { if (window.innerWidth > 1024) x.classList.remove('open'); });
    if (!e.target.closest('.notif')) { var p = $('#notif-panel'); if (p && !p.hidden) { p.hidden = true; $('#notif-btn').setAttribute('aria-expanded', 'false'); } }
  });

  // البحث المنبثق
  var so = $('#search-overlay');
  function openSearch() { so.hidden = false; setTimeout(function () { $('#sq').focus(); }, 30); }
  function closeSearch() { so.hidden = true; }
  $$('[data-open=search]').forEach(function (b) { b.addEventListener('click', openSearch); });
  $$('[data-close=search]').forEach(function (b) { b.addEventListener('click', closeSearch); });
  if (so) so.addEventListener('click', function (e) { if (e.target === so) closeSearch(); });
  d.addEventListener('keydown', function (e) {
    if (e.key === 'Escape') { if (so && !so.hidden) closeSearch(); closeNav(); closeLb(); }
    if (e.key === '/' && !/input|textarea|select/i.test((d.activeElement || {}).tagName || '') && so) { e.preventDefault(); openSearch(); }
  });

  // التنبيهات العاجلة (قابلة للإخفاء)
  var hidden = (store.get('nabd_alerts') || '').split(',');
  $$('.alert-bar').forEach(function (a) {
    var id = a.getAttribute('data-alert');
    if (hidden.indexOf(id) === -1) a.hidden = false;
    $('.alert-close', a).addEventListener('click', function () { a.hidden = true; hidden.push(id); store.set('nabd_alerts', hidden.slice(-30).join(',')); });
  });

  // مركز الإشعارات
  var nb = $('#notif-btn'), np = $('#notif-panel');
  if (nb) {
    var seen = store.get('nabd_seen') || '';
    var latest = nb.getAttribute('data-latest');
    if (latest && latest > seen) $('.dot', nb).hidden = false;
    $$('.np-item', np).forEach(function (i) { if (i.getAttribute('data-time') > seen) i.classList.add('unread'); });
    nb.addEventListener('click', function (e) {
      e.stopPropagation();
      np.hidden = !np.hidden; nb.setAttribute('aria-expanded', !np.hidden);
      if (!np.hidden && latest) { store.set('nabd_seen', latest); $('.dot', nb).hidden = true; }
    });
  }

  // الظهور التدريجي
  var reveals = $$('.reveal');
  if ('IntersectionObserver' in window) {
    var io = new IntersectionObserver(function (es) {
      es.forEach(function (en) { if (en.isIntersecting) { en.target.classList.add('in'); io.unobserve(en.target); } });
    }, { rootMargin: '0px 0px -40px 0px' });
    reveals.forEach(function (el, i) { el.style.transitionDelay = Math.min(i % 4, 3) * 70 + 'ms'; io.observe(el); });
  } else reveals.forEach(function (el) { el.classList.add('in'); });

  // العدّادات المتحركة
  var counters = $$('[data-count]');
  function animateCount(el) {
    var target = +el.getAttribute('data-count'), t0 = performance.now(), dur = 1600;
    (function step(t) {
      var p = Math.min(1, (t - t0) / dur), e = 1 - Math.pow(1 - p, 3);
      el.textContent = nf.format(Math.round(target * e));
      if (p < 1) requestAnimationFrame(step);
    })(t0);
  }
  if (counters.length && 'IntersectionObserver' in window) {
    var co = new IntersectionObserver(function (es) { es.forEach(function (en) { if (en.isIntersecting) { animateCount(en.target); co.unobserve(en.target); } }); }, { threshold: .4 });
    counters.forEach(function (c) { co.observe(c); });
  } else counters.forEach(function (c) { c.textContent = nf.format(+c.getAttribute('data-count')); });

  // العد التنازلي
  $$('[data-countdown]').forEach(function (cd) {
    var target = new Date(cd.getAttribute('data-countdown')).getTime();
    var u = { d: $('[data-u=d]', cd), h: $('[data-u=h]', cd), m: $('[data-u=m]', cd), s: $('[data-u=s]', cd) };
    function tick() {
      var diff = Math.max(0, target - Date.now());
      u.d.textContent = nf.format(Math.floor(diff / 864e5));
      u.h.textContent = nf.format(Math.floor(diff / 36e5) % 24);
      u.m.textContent = nf.format(Math.floor(diff / 6e4) % 60);
      u.s.textContent = nf.format(Math.floor(diff / 1e3) % 60);
      if (diff <= 0) { cd.innerHTML = '<span style="grid-column:1/-1">الفعالية جارية الآن 🎉</span>'; return; }
      setTimeout(tick, 1000);
    }
    tick();
  });

  // نسخ الرابط والطباعة
  $$('[data-copy]').forEach(function (b) {
    b.addEventListener('click', function () {
      var t = b.getAttribute('data-copy'), old = b.innerHTML;
      var done = function () { b.textContent = '✓ تم النسخ'; setTimeout(function () { b.innerHTML = old; }, 1800); };
      if (navigator.clipboard) navigator.clipboard.writeText(t).then(done, function () { prompt('انسخ الرابط:', t); });
      else { prompt('انسخ الرابط:', t); }
    });
  });
  $$('[data-print]').forEach(function (b) { b.addEventListener('click', function () { window.print(); }); });

  // عارض الصور
  var lb = $('#lightbox'), lbItems = [], lbIdx = 0, lastFocus;
  function showLb(i) {
    lbIdx = (i + lbItems.length) % lbItems.length;
    var it = lbItems[lbIdx];
    $('.lb-media', lb).innerHTML = '';
    var img = d.createElement('img'); img.src = it.getAttribute('data-src'); img.alt = it.getAttribute('data-caption') || '';
    $('.lb-media', lb).appendChild(img);
    $('figcaption', lb).textContent = (it.getAttribute('data-caption') || '') + '  (' + (lbIdx + 1) + ' / ' + lbItems.length + ')';
  }
  function closeLb() { if (lb && !lb.hidden) { lb.hidden = true; d.body.style.overflow = ''; if (lastFocus) lastFocus.focus(); } }
  $$('[data-lb]').forEach(function (b) {
    b.addEventListener('click', function () {
      lbItems = $$('[data-lb="' + b.getAttribute('data-lb') + '"]');
      lastFocus = b; lb.hidden = false; d.body.style.overflow = 'hidden';
      showLb(lbItems.indexOf(b)); $('.lb-close', lb).focus();
    });
  });
  if (lb) {
    $('.lb-close', lb).addEventListener('click', closeLb);
    $('.lb-prev', lb).addEventListener('click', function () { showLb(lbIdx - 1); });
    $('.lb-next', lb).addEventListener('click', function () { showLb(lbIdx + 1); });
    lb.addEventListener('click', function (e) { if (e.target === lb) closeLb(); });
    d.addEventListener('keydown', function (e) {
      if (lb.hidden) return;
      if (e.key === 'ArrowLeft') showLb(lbIdx + 1);
      if (e.key === 'ArrowRight') showLb(lbIdx - 1);
    });
    var sx = 0;
    lb.addEventListener('touchstart', function (e) { sx = e.touches[0].clientX; }, { passive: true });
    lb.addEventListener('touchend', function (e) { var dx = e.changedTouches[0].clientX - sx; if (Math.abs(dx) > 50) showLb(lbIdx + (dx > 0 ? 1 : -1)); });
  }

  // الإحصائيات التفاعلية
  var hc = $('#home-chart');
  if (hc) {
    var area = $('.chart-area', hc), data = null, view = 'types';
    var esc = function (s) { return String(s).replace(/[&<>"]/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]; }); };
    var render = function () {
      if (!data) return;
      if (view === 'types') {
        var mx = Math.max.apply(null, data.types.map(function (t) { return t.n; }).concat(1));
        area.innerHTML = '<ul class="hbars">' + data.types.map(function (t) { return '<li><a href="' + t.href + '">' + esc(t.label) + '</a><span class="track"><span class="fill" data-w="' + (t.n / mx * 100) + '"></span></span><b>' + nf.format(t.n) + '</b></li>'; }).join('') + '</ul>';
        requestAnimationFrame(function () { $$('.fill', area).forEach(function (f) { f.style.width = f.getAttribute('data-w') + '%'; }); });
      } else {
        var m = Math.max.apply(null, data.months.map(function (x) { return x.n; }).concat(1));
        area.innerHTML = '<div class="vchart-wrap"><div class="vchart">' + data.months.map(function (x) { return '<div class="col"><span class="bar" tabindex="0" data-h="' + (x.n / m * 100) + '" aria-label="' + esc(x.label) + ': ' + x.n + '"><em>' + (x.n || '') + '</em></span><small>' + esc(x.label) + '</small></div>'; }).join('') + '</div></div>';
        requestAnimationFrame(function () { $$('.bar', area).forEach(function (b) { b.style.height = Math.max(2, +b.getAttribute('data-h')) + '%'; }); });
      }
    };
    $$('.chart-tabs button', hc).forEach(function (b) {
      b.addEventListener('click', function () {
        $$('.chart-tabs button', hc).forEach(function (x) { x.setAttribute('aria-selected', x === b); });
        view = b.getAttribute('data-view'); render();
      });
    });
    var load = function () { fetch(hc.getAttribute('data-src')).then(function (r) { return r.json(); }).then(function (j) { data = j; render(); }).catch(function () { area.innerHTML = '<p class="muted">تعذّر تحميل الإحصائيات.</p>'; }); };
    if ('IntersectionObserver' in window) { var ho = new IntersectionObserver(function (es) { if (es[0].isIntersecting) { load(); ho.disconnect(); } }); ho.observe(hc); } else load();
  }

  // التقويم التفاعلي
  var cal = $('#calendar');
  if (cal) {
    var now = new Date(), cur = new Date(now.getFullYear(), now.getMonth(), 1), events = [], selected = null;
    var grid = $('.cal-grid', cal), title = $('.cal-title', cal), dayBox = $('.cal-day', cal);
    var dows = ['الأحد', 'الاثنين', 'الثلاثاء', 'الأربعاء', 'الخميس', 'الجمعة', 'السبت'];
    var fmtMonth = new Intl.DateTimeFormat('ar-OM-u-nu-latn', { month: 'long', year: 'numeric' });
    var fmtDay = new Intl.DateTimeFormat('ar-OM-u-nu-latn', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' });
    var iso = function (dt) { return dt.getFullYear() + '-' + String(dt.getMonth() + 1).padStart(2, '0') + '-' + String(dt.getDate()).padStart(2, '0'); };
    var enabled = function () { return $$('.cal-legend input:checked', cal).map(function (i) { return i.getAttribute('data-kind'); }); };
    var escH = function (s) { return String(s || '').replace(/[&<>"]/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]; }); };
    var on = function (day) { var k = enabled(); return events.filter(function (e) { return k.indexOf(e.kind) > -1 && e.start <= day && e.end >= day; }); };
    function drawDay(day) {
      selected = day;
      $$('.cal-cell', grid).forEach(function (c) { c.classList.toggle('sel', c.getAttribute('data-day') === day); });
      var list = on(day);
      var dt = new Date(day + 'T12:00:00');
      dayBox.innerHTML = '<h3>' + fmtDay.format(dt) + '</h3>' + (list.length ? '<ul>' + list.map(function (e) {
        return '<li><i class="k-' + e.color + '"></i><div><b>' + (e.url ? '<a href="' + e.url + '">' + escH(e.title) + '</a>' : escH(e.title)) + '</b><small>' + escH(e.label) + (e.time ? ' · ' + e.time : '') + (e.location ? ' · ' + escH(e.location) : '') + (e.start !== e.end ? ' · من ' + e.start + ' إلى ' + e.end : '') + (e.demo ? ' · تجريبي' : '') + '</small>' + (e.description ? '<small>' + escH(e.description) + '</small>' : '') + '</div></li>';
      }).join('') + '</ul>' : '<p class="muted">لا توجد مواعيد في هذا اليوم.</p>');
    }
    function draw() {
      title.textContent = fmtMonth.format(cur);
      var first = new Date(cur), start = new Date(first); start.setDate(1 - first.getDay());
      var html = dows.map(function (w) { return '<div class="cal-dow" role="columnheader">' + w + '</div>'; }).join('');
      var today = iso(new Date());
      for (var i = 0; i < 42; i++) {
        var dt = new Date(start); dt.setDate(start.getDate() + i);
        var day = iso(dt), list = on(day);
        if (i >= 35 && dt.getMonth() !== cur.getMonth()) break;
        html += '<button type="button" role="gridcell" class="cal-cell' + (dt.getMonth() !== cur.getMonth() ? ' out' : '') + (day === today ? ' today' : '') + (dt.getDay() === 5 ? ' fri' : '') + (dt.getDay() === 6 ? ' sat' : '') + '" data-day="' + day + '" aria-label="' + fmtDay.format(dt) + (list.length ? '، ' + list.length + ' موعد' : '') + '"><span class="dn">' + nf.format(dt.getDate()) + '</span>' +
          list.slice(0, 3).map(function (e) { return '<span class="ev-pill k-' + e.color + '" title="' + escH(e.title) + '">' + escH(e.title) + '</span>'; }).join('') + (list.length > 3 ? '<span class="ev-pill k-navy">+' + (list.length - 3) + '</span>' : '') + '</button>';
      }
      grid.innerHTML = html;
      $$('.cal-cell', grid).forEach(function (c) { c.addEventListener('click', function () { drawDay(c.getAttribute('data-day')); }); });
      var inMonth = selected && selected.slice(0, 7) === iso(cur).slice(0, 7);
      drawDay(inMonth ? selected : (iso(new Date()).slice(0, 7) === iso(cur).slice(0, 7) ? today : iso(cur)));
    }
    function load() {
      var key = iso(cur).slice(0, 7);
      grid.setAttribute('aria-busy', 'true');
      fetch(cal.getAttribute('data-src') + '?month=' + key).then(function (r) { return r.json(); }).then(function (j) { events = j.items || []; draw(); grid.removeAttribute('aria-busy'); })
        .catch(function () { events = []; draw(); });
    }
    $$('[data-cal]', cal).forEach(function (b) {
      b.addEventListener('click', function () {
        var a = b.getAttribute('data-cal');
        if (a === 'prev') cur.setMonth(cur.getMonth() - 1);
        else if (a === 'next') cur.setMonth(cur.getMonth() + 1);
        else { cur = new Date(now.getFullYear(), now.getMonth(), 1); selected = null; }
        load();
      });
    });
    $$('.cal-legend input', cal).forEach(function (i) { i.addEventListener('change', draw); });
    load();
  }

  // منع الإرسال المزدوج للنماذج
  $$('form[method=post]').forEach(function (f) {
    f.addEventListener('submit', function () {
      var b = $('button[type=submit],button:not([type])', f);
      if (b) setTimeout(function () { b.disabled = true; b.style.opacity = .7; }, 0);
    });
  });
})();
