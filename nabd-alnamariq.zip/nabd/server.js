'use strict';
// تشغيل الخادم محليًا أو على أي خادم Node.js:  npm start
const http = require('node:http');
const config = require('./src/config');
const { handle, init } = require('./src/app');

const server = http.createServer((req, res) => { handle(req, res); });
server.keepAliveTimeout = 65000;

init().then(() => {
  server.listen(config.port, config.host, () => {
    console.log(`«نبض النمارق» يعمل على ${config.siteUrl}  (قاعدة البيانات: ${require('./src/db').engine()})`);
    console.log(`لوحة التحكم: ${config.siteUrl}/admin`);
  });
}).catch((e) => { console.error('تعذّر تهيئة قاعدة البيانات:', e); process.exit(1); });

const stop = () => server.close(() => process.exit(0));
process.on('SIGTERM', stop);
process.on('SIGINT', stop);
