'use strict';
// اختبارات تكامل شاملة: تشغيل الخادم بقاعدة بيانات مؤقتة واختبار الوظائف الفعلية
// التشغيل: npm test
const { test, before, after } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const http = require('node:http');

const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'nabd-test-'));
process.env.DB_PATH = path.join(tmp, 'test.db');
process.env.ADMIN_EMAIL = 'admin@test.om';
process.env.ADMIN_PASSWORD = 'TestAdmin123';
process.env.SESSION_SECRET = 'test-secret';
process.env.SEED_DEMO = '1';
delete process.env.TURSO_DATABASE_URL;

const { handle, init } = require('../src/app');
const db = require('../src/db');
let server, base;

before(async () => {
  await init();
  server = http.createServer(handle);
  await new Promise((r) => server.listen(0, '127.0.0.1', r));
  base = 'http://127.0.0.1:' + server.address().port;
});
after(async () => { server.close(); await db.close(); fs.rmSync(tmp, { recursive: true, force: true }); });

// عميل بسيط يحفظ الكوكيز
function client() {
  const jar = {};
  return {
    jar,
    async req(method, url, { form, multipart, headers = {} } = {}) {
      const h = { ...headers, cookie: Object.entries(jar).map(([k, v]) => `${k}=${v}`).join('; ') };
      let body;
      if (form) { body = new URLSearchParams(form).toString(); h['content-type'] = 'application/x-www-form-urlencoded'; }
      if (multipart) { body = multipart; }
      const res = await fetch(base + url, { method, headers: h, body, redirect: 'manual' });
      for (const c of res.headers.getSetCookie()) { const [kv] = c.split(';'); const i = kv.indexOf('='); jar[kv.slice(0, i)] = kv.slice(i + 1); }
      return { status: res.status, location: res.headers.get('location'), text: await res.text(), headers: res.headers };
    },
    get(u) { return this.req('GET', u); },
    post(u, form) { return this.req('POST', u, { form }); },
  };
}
const csrfOf = (html) => (html.match(/name="_csrf" value="([^"]+)"/) || html.match(/<meta name="csrf" content="([^"]+)"/) || [])[1];
const ftOf = (html) => (html.match(/name="_ft" value="([^"]+)"/) || [])[1];

async function login(c, email = 'admin@test.om', password = 'TestAdmin123') {
  const page = await c.get('/admin/login');
  const r = await c.post('/admin/login', { email, password, _ft: ftOf(page.text), next: '/admin' });
  return r;
}

test('كل الصفحات العامة تعمل', async () => {
  const c = client();
  for (const u of ['/', '/about', '/news', '/news?kind=announcement', '/initiatives', '/events', '/events?tab=past', '/achievements', '/library', '/parents', '/calendar', '/media', '/partnerships', '/contact', '/archive', '/schedules', '/search?q=' + encodeURIComponent('المدرسة'), '/sitemap.xml', '/robots.txt', '/feed.xml', '/manifest.webmanifest', '/api/stats', '/api/calendar?month=2026-11', '/healthz']) {
    const r = await c.get(u);
    assert.equal(r.status, 200, u);
  }
  assert.equal((await c.get('/does-not-exist')).status, 404);
});

test('بيانات المدرسة الرسمية (الرؤية والرسالة) تظهر في صفحة عن المدرسة', async () => {
  db.clearSettingsCache();
  const r = await client().get('/about');
  assert.match(r.text, /إعداد جيل مبدع من خلال تعليم عالي الجودة/);
  assert.match(r.text, /انسجامًا مع رؤية عُمان 2040/);
  assert.match(r.text, /ولاية السويق/);
});

test('الصفحة الرئيسية تعرض الشعار والمحتوى التجريبي مُعلَّمًا', async () => {
  const r = await client().get('/');
  assert.match(r.text, /مدرستنا تنبض بالعلم والإبداع/);
  assert.match(r.text, /<html lang="ar" dir="rtl">/);
  assert.match(r.text, /تجريبي/);
  assert.match(r.text, /data-countdown/);
  assert.match(r.headers.get('content-security-policy'), /default-src 'self'/);
});

test('صفحة الخبر: مشاركة واتساب وعداد المشاهدات', async () => {
  const p = await db.get("SELECT * FROM posts WHERE type = 'news' AND status = 'published' LIMIT 1");
  const r = await client().get('/news/' + encodeURIComponent(p.slug));
  assert.equal(r.status, 200);
  assert.match(r.text, /https:\/\/wa\.me\/\?text=/);
  const after2 = await db.get('SELECT views FROM posts WHERE id = ?', p.id);
  assert.equal(after2.views, p.views + 1);
});

test('ملف ICS للفعالية', async () => {
  const e = await db.get("SELECT slug FROM posts WHERE type = 'event' LIMIT 1");
  const r = await client().get('/events/' + encodeURIComponent(e.slug) + '/ics');
  assert.equal(r.status, 200);
  assert.match(r.text, /BEGIN:VCALENDAR/);
});

test('البحث يطبّع الحروف العربية (أ/ا، ة/ه)', async () => {
  const r = await client().get('/search?q=' + encodeURIComponent('الروبوت'));
  assert.match(r.text, /مسابقة <mark>الروبوت<\/mark>/);
  const r2 = await client().get('/search?q=' + encodeURIComponent('اسبوع القراءه'));
  assert.match(r2.text, /أسبوع القراءة/);
});

test('نموذج التواصل يحفظ الرسالة ويرفض بدون رمز', async () => {
  const c = client();
  const page = await c.get('/contact');
  const bad = await c.post('/contact', { name: 'اختبار', message: 'رسالة اختبار طويلة بما يكفي' });
  assert.equal(bad.status, 400);
  const ok = await c.post('/contact', { _ft: ftOf(page.text), name: 'ولي أمر', email: 'p@example.com', subject: 'استفسار عام', message: 'هذه رسالة اختبار من نموذج التواصل' });
  assert.equal(ok.status, 303);
  assert.ok(await db.get("SELECT id FROM messages WHERE message = 'هذه رسالة اختبار من نموذج التواصل'"));
});

test('مصيدة الروبوتات ترفض الإرسال', async () => {
  const c = client();
  const page = await c.get('/contact');
  const r = await c.post('/contact', { _ft: ftOf(page.text), website: 'spam', name: 'x', message: 'spam spam spam spam' });
  assert.equal(r.status, 400);
});

test('مقترحات أولياء الأمور والاستبانة (رد واحد لكل زائر)', async () => {
  const c = client();
  const page = await c.get('/parents');
  const r = await c.post('/parents/suggest', { _ft: ftOf(page.text), category: 'اقتراح', message: 'اقتراح اختباري لتحسين الخدمات' });
  assert.equal(r.status, 303);
  const sv = await db.get("SELECT id FROM surveys WHERE status = 'open'");
  const qs = await db.all('SELECT * FROM survey_questions WHERE survey_id = ? ORDER BY sort', sv.id);
  const before2 = (await db.get('SELECT COUNT(*) n FROM survey_responses WHERE survey_id = ?', sv.id)).n;
  const sp = await c.get('/surveys/' + sv.id);
  const form = new URLSearchParams({ _ft: ftOf(sp.text) });
  for (const q of qs) {
    const opts = JSON.parse(q.options || '[]');
    if (q.qtype === 'rating') form.append('q' + q.id, '5');
    else if (q.qtype === 'single') form.append('q' + q.id, opts[0]);
    else if (q.qtype === 'multi') { form.append('q' + q.id, opts[0]); form.append('q' + q.id, opts[1]); }
    else form.append('q' + q.id, 'ملاحظة');
  }
  const res = await c.req('POST', '/surveys/' + sv.id, { form: Object.fromEntries(form) });
  assert.equal(res.status, 303);
  const multiForm = form.toString();
  await fetch(base + '/surveys/' + sv.id, { method: 'POST', headers: { 'content-type': 'application/x-www-form-urlencoded' }, body: multiForm, redirect: 'manual' });
  const after2 = (await db.get('SELECT COUNT(*) n FROM survey_responses WHERE survey_id = ?', sv.id)).n;
  assert.equal(after2, before2 + 1, 'يُقبل رد واحد فقط من نفس الزائر');
});

test('لوحة التحكم تتطلب تسجيل الدخول', async () => {
  const r = await client().get('/admin');
  assert.equal(r.status, 303);
  assert.match(r.location, /\/admin\/login/);
});

test('تسجيل الدخول: كلمة مرور خاطئة ثم صحيحة', async () => {
  const c = client();
  const bad = await login(c, 'admin@test.om', 'wrong-password');
  assert.match(bad.location, /err=1/);
  const ok = await login(c);
  assert.equal(ok.location, '/admin');
  const dash = await c.get('/admin');
  assert.equal(dash.status, 200);
  assert.match(dash.text, /لوحة المعلومات/);
  assert.ok(await db.get("SELECT id FROM audit_log WHERE action = 'login_failed'"));
});

test('CSRF: رفض طلبات الإدارة بدون رمز', async () => {
  const c = client();
  await login(c);
  const r = await c.post('/admin/content/save', { type: 'news', title: 'x', do: 'draft' });
  assert.equal(r.status, 403);
});

test('دورة حياة المحتوى: إنشاء مسودة ← نشر ← ظهور في الموقع ← نسخ ← حذف', async () => {
  const c = client();
  await login(c);
  const form = await c.get('/admin/content/new?type=news');
  const csrf = csrfOf(form.text);
  const fd = new FormData();
  fd.append('_csrf', csrf); fd.append('type', 'news'); fd.append('title', 'خبر اختبار الأتمتة'); fd.append('excerpt', 'ملخص');
  fd.append('body', '## عنوان\n\n**نص عريض** و [رابط](https://example.com)\n\n<script>alert(1)</script>'); fd.append('category', 'أكاديمي'); fd.append('do', 'draft');
  const r1 = await c.req('POST', '/admin/content/save', { multipart: fd });
  assert.equal(r1.status, 303);
  const p = await db.get("SELECT * FROM posts WHERE title = 'خبر اختبار الأتمتة'");
  assert.equal(p.status, 'draft');
  assert.equal((await client().get('/news/' + encodeURIComponent(p.slug))).status, 404, 'المسودة لا تظهر للعامة');

  const fd2 = new FormData();
  fd2.append('_csrf', csrf); fd2.append('id', String(p.id)); fd2.append('title', 'خبر اختبار الأتمتة'); fd2.append('excerpt', 'ملخص محدث');
  fd2.append('body', p.body); fd2.append('do', 'publish');
  await c.req('POST', '/admin/content/save', { multipart: fd2 });
  const pub = await client().get('/news/' + encodeURIComponent(p.slug));
  assert.equal(pub.status, 200);
  assert.match(pub.text, /<strong>نص عريض<\/strong>/);
  assert.doesNotMatch(pub.text, /<script>alert/, 'يجب تهريب HTML الخام');
  assert.ok((await db.get('SELECT COUNT(*) n FROM post_revisions WHERE post_id = ?', p.id)).n >= 1, 'تُحفظ نسخة سابقة');

  const del = await c.post(`/admin/content/${p.id}/delete`, { _csrf: csrf });
  assert.equal(del.status, 303);
  assert.equal(await db.get('SELECT id FROM posts WHERE id = ?', p.id), undefined);
});

test('الصلاحيات: الكاتب لا ينشر مباشرة بل يرسل للمراجعة، ولا يدخل الإعدادات', async () => {
  const admin = client();
  await login(admin);
  const page = await admin.get('/admin/r/users/new');
  const csrf = csrfOf(page.text);
  const authorRole = await db.get("SELECT id FROM roles WHERE name = 'author'");
  const r = await admin.post('/admin/r/users/save', { _csrf: csrf, name: 'كاتب اختبار', email: 'author@test.om', role_id: String(authorRole.id), active: '1', password: 'AuthorPass123' });
  assert.equal(r.status, 303);

  const au = client();
  assert.equal((await login(au, 'author@test.om', 'AuthorPass123')).location, '/admin');
  assert.equal((await au.get('/admin/settings')).status, 403);
  assert.equal((await au.get('/admin/r/users')).status, 403);
  const f = await au.get('/admin/content/new?type=news');
  const fd = new FormData();
  fd.append('_csrf', csrfOf(f.text)); fd.append('type', 'news'); fd.append('title', 'خبر من الكاتب'); fd.append('do', 'publish');
  await au.req('POST', '/admin/content/save', { multipart: fd });
  const p = await db.get("SELECT status FROM posts WHERE title = 'خبر من الكاتب'");
  assert.equal(p.status, 'review', 'محتوى الكاتب يذهب للمراجعة');
});

test('رفع الملفات: قبول صورة PNG حقيقية ورفض ملف مزيف', async () => {
  const c = client();
  await login(c);
  const page = await c.get('/admin/media');
  const csrf = csrfOf(page.text);
  const png = fs.readFileSync(path.join(__dirname, '..', 'public', 'img', 'og-image.png'));
  const fd = new FormData();
  fd.append('_csrf', csrf); fd.append('files', new Blob([png], { type: 'image/png' }), 'صورة.png');
  const ok = await c.req('POST', '/admin/media/upload', { multipart: fd });
  assert.equal(ok.status, 303);
  const f = await db.get("SELECT * FROM files WHERE original_name = 'صورة.png'");
  assert.ok(f);
  const served = await client().get(f.path);
  assert.equal(served.status, 200);
  assert.equal(served.headers.get('content-type'), 'image/png');

  const fd2 = new FormData();
  fd2.append('_csrf', csrf); fd2.append('files', new Blob(['<?php echo 1; ?>'], { type: 'image/png' }), 'evil.png');
  const bad = await c.req('POST', '/admin/media/upload', { multipart: fd2 });
  assert.equal(bad.status, 400);
  const fd3 = new FormData();
  fd3.append('_csrf', csrf); fd3.append('files', new Blob(['<svg onload=alert(1)>']), 'x.svg');
  assert.equal((await c.req('POST', '/admin/media/upload', { multipart: fd3 })).status, 400);
});

test('الموارد: إضافة موعد تقويم يظهر في واجهة التقويم', async () => {
  const c = client();
  await login(c);
  const page = await c.get('/admin/r/calendar/new');
  const r = await c.post('/admin/r/calendar/save', { _csrf: csrfOf(page.text), title: 'يوم اختبار التقويم', kind: 'event', starts_on: '2026-12-05', status: 'published' });
  assert.equal(r.status, 303);
  const api = JSON.parse((await client().get('/api/calendar?month=2026-12')).text);
  assert.ok(api.items.some((i) => i.title === 'يوم اختبار التقويم'));
});

test('الإعدادات تُحفظ وتنعكس على الموقع', async () => {
  const c = client();
  await login(c);
  const page = await c.get('/admin/settings');
  const fd = new FormData();
  fd.append('_csrf', csrfOf(page.text));
  for (const [k, v] of Object.entries({ site_name: 'نبض النمارق', school_name: 'مدرسة النمارق للتعليم الأساسي', slogan: 'مدرستنا تنبض بالعلم والإبداع', contact_phone: '+968 0000 0000', demo_banner: '1' })) fd.append(k, v);
  const r = await c.req('POST', '/admin/settings', { multipart: fd });
  assert.equal(r.status, 303);
  db.clearSettingsCache();
  const home = await client().get('/contact');
  assert.match(home.text, /\+968 0000 0000/);
  assert.match(home.text, /src="\/img\/logo\.svg"/, 'الشعار الافتراضي');
});

test('تغيير شعار المدرسة من الإعدادات', async () => {
  const c = client();
  await login(c);
  const page = await c.get('/admin/settings');
  const fd = new FormData();
  fd.append('_csrf', csrfOf(page.text));
  for (const [k, v] of Object.entries({ site_name: 'نبض النمارق', school_name: 'مدرسة النمارق للتعليم الأساسي', slogan: 'مدرستنا تنبض بالعلم والإبداع' })) fd.append(k, v);
  fd.append('logo__upload', new Blob([fs.readFileSync(path.join(__dirname, '..', 'public', 'img', 'og-image.png'))], { type: 'image/png' }), 'logo.png');
  assert.equal((await c.req('POST', '/admin/settings', { multipart: fd })).status, 303);
  db.clearSettingsCache();
  const logo = (await db.settings()).logo;
  assert.match(logo, /^\/uploads\/.+\.png$/);
  const home = await client().get('/');
  assert.ok(home.text.includes(`<img src="${logo}"`), 'الشعار الجديد في الترويسة');
  assert.ok(home.text.includes(`<link rel="icon" href="${logo}">`), 'الشعار الجديد كأيقونة');
  assert.ok((await c.get('/admin')).text.includes(logo), 'الشعار في لوحة التحكم');
  assert.equal((await client().get(logo)).status, 200);
});

test('حذف المحتوى التجريبي', async () => {
  const c = client();
  await login(c);
  const page = await c.get('/admin');
  const r = await c.post('/admin/demo/remove', { _csrf: csrfOf(page.text) });
  assert.equal(r.status, 303);
  assert.equal((await db.get('SELECT COUNT(*) n FROM posts WHERE is_demo = 1')).n, 0);
  assert.equal((await client().get('/')).status, 200, 'الرئيسية تعمل بدون محتوى');
});

test('سجل العمليات يسجّل الإجراءات', async () => {
  const c = client();
  await login(c);
  const r = await c.get('/admin/logs');
  assert.equal(r.status, 200);
  assert.ok((await db.get('SELECT COUNT(*) n FROM audit_log')).n > 5);
});

test('أخبار حساب المدرسة على X مستوردة مرة واحدة', async () => {
  const n = (await db.get("SELECT COUNT(*) n FROM posts WHERE body LIKE '%x.com/EduGovNBT2362/status/%'")).n;
  assert.equal(n, 4);
  await require('../src/imports').runImports();
  assert.equal((await db.get("SELECT COUNT(*) n FROM posts WHERE body LIKE '%x.com/EduGovNBT2362/status/%'")).n, 4, 'لا تكرار');
  const p = await db.get("SELECT slug FROM posts WHERE title LIKE '%Viva Engage%'");
  const r = await client().get('/news/' + encodeURIComponent(p.slug));
  assert.equal(r.status, 200);
  assert.match(r.text, /pbs\.twimg\.com\/media\/HXRchYQbEAAbrxm/);
  assert.match(r.headers.get('content-security-policy'), /https:\/\/pbs\.twimg\.com/);
});

test('مزامنة X عبر واجهة الإدارة: إضافة مع منع التكرار', async () => {
  const c = client();
  await login(c);
  const page = await c.get('/admin');
  const csrf = csrfOf(page.text);
  const posts = [
    { id: '2130000000000000001', text: '#فعاليات_تعليمية_شمال_الباطنة\n@EduGovNBT\n\nتكريم الطلبة المجيدين في الفصل الدراسي الأول بحضور أولياء الأمور.', imgs: ['https://pbs.twimg.com/media/ABCdef123?format=webp&name=small'], video: false },
    { id: '2130000000000000002', text: '#وسم', imgs: [], video: true },
    { id: '2122423061861564478', text: 'منشور موجود مسبقًا يجب تجاهله لأنه مستورد', imgs: [] },
  ];
  const send = () => c.req('POST', '/admin/api/x-import', { form: undefined, headers: { 'content-type': 'application/json', 'x-csrf-token': csrf }, multipart: JSON.stringify({ posts }) });
  const r1 = JSON.parse((await send()).text);
  assert.equal(r1.added.length, 1);
  assert.equal(r1.skipped, 2);
  const r2 = JSON.parse((await send()).text);
  assert.equal(r2.added.length, 0, 'لا تكرار في المزامنة الثانية');
  const p = await db.get("SELECT * FROM posts WHERE body LIKE '%2130000000000000001%'");
  assert.match(p.title, /^تكريم الطلبة المجيدين/);
  assert.equal(p.cover, 'https://pbs.twimg.com/media/ABCdef123?format=jpg&name=large');
  assert.equal((await client().req('POST', '/admin/api/x-import', { headers: { 'content-type': 'application/json' }, multipart: '{}' })).status, 401);
});
