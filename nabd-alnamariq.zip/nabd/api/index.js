'use strict';
// نقطة الدخول على Vercel: كل الطلبات (عدا الملفات الثابتة في public/) تصل إلى هنا
const { handle } = require('../src/app');

module.exports = (req, res) => handle(req, res);
